# -*- coding: utf-8 -*-


import os
import warnings
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}

optimal_rhos = {
    160: 0.4,
    400: 0.8,
    800: 0.1,
    2800: 0.4,
}


# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
        tol=1e-3,
    )


# =========================================================================

# =========================================================================
def compute_gra_importance(X_mat, y_vec, rho):
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()
    n_features = X_mat.shape[1]
    gamma = np.zeros(n_features)
    for i in range(n_features):
        gamma[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )
    return gamma


def shadow_set_objective(alpha, beta, gamma_vals):
    significant = gamma_vals[gamma_vals >= alpha]
    insignificant = gamma_vals[gamma_vals <= beta]
    shadow = gamma_vals[(gamma_vals > beta) & (gamma_vals < alpha)]
    v1 = np.sum(1 - significant)
    v2 = np.sum(insignificant)
    v3 = len(shadow)
    return abs(v1 + v2 - v3)


def optimize_thresholds_shadow_gra(gamma_vals, step=0.005):
    min_objective = float("inf")
    best_alpha, best_beta = 0.0, 0.0
    gamma_min = np.min(gamma_vals)
    gamma_max = np.max(gamma_vals)
    thresholds = np.arange(gamma_min + step, gamma_max, step)

    if len(thresholds) < 2:
        return (gamma_min + 0.67 * (gamma_max - gamma_min),
                gamma_min + 0.33 * (gamma_max - gamma_min))

    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1:]:
            objective = shadow_set_objective(alpha_cand, beta_cand, gamma_vals)
            if objective < min_objective:
                min_objective = objective
                best_alpha = alpha_cand
                best_beta = beta_cand
    return best_alpha, best_beta


def compute_relieff_weights(X_mat, y_vec, feature_names, r=100, k=5, seed=42):
    m, n = X_mat.shape
    classes, class_counts = np.unique(y_vec, return_counts=True)
    p_c = {c: count / m for c, count in zip(classes, class_counts)}

    feat_min = np.min(X_mat, axis=0)
    feat_max = np.max(X_mat, axis=0)
    feat_span = feat_max - feat_min
    feat_span[feat_span == 0] = 1e-8

    W = np.zeros(n)
    np.random.seed(seed)
    actual_r = min(r, m)

    for _ in range(actual_r):
        idx_s = np.random.randint(0, m)
        s = X_mat[idx_s]
        cls_s = y_vec[idx_s]

        norm_diff = np.abs(X_mat - s) / feat_span
        dist_all = np.sum(norm_diff, axis=1)

        same_class_mask = (y_vec == cls_s)
        same_class_indices = np.where(same_class_mask)[0]
        same_class_indices = same_class_indices[same_class_indices != idx_s]
        k_hit = min(k, len(same_class_indices))
        if k_hit == 0:
            continue
        hit_k_indices = same_class_indices[np.argsort(dist_all[same_class_indices])[:k_hit]]
        diff_hits = np.sum(np.abs(X_mat[hit_k_indices] - s) / feat_span, axis=0)

        diff_misses_weighted = np.zeros(n)
        for c in classes:
            if c == cls_s:
                continue
            diff_class_indices = np.where(y_vec == c)[0]
            k_miss = min(k, len(diff_class_indices))
            if k_miss == 0:
                continue
            miss_k_indices = diff_class_indices[np.argsort(dist_all[diff_class_indices])[:k_miss]]
            diff_m_c = np.sum(np.abs(X_mat[miss_k_indices] - s) / feat_span, axis=0)
            diff_misses_weighted += (p_c[c] / (1.0 - p_c[cls_s])) * (diff_m_c / k_miss)

        W = W - (diff_hits / (actual_r * k_hit)) + (diff_misses_weighted / actual_r)

    return dict(zip(feature_names, W))


def optimize_thresholds_shadow_relieff(weights_dict, step=0.005):
    weights_arr = np.array(list(weights_dict.values()))
    w_min = np.min(weights_arr)
    w_max = np.max(weights_arr)
    w_span = w_max - w_min
    if w_span == 0:
        return w_max, w_min

    w_norm = (weights_arr - w_min) / w_span
    min_objective = float('inf')
    best_a_norm, best_b_norm = 1.0, 0.0
    cand_thresholds = np.arange(step, 1.0, step)

    if len(cand_thresholds) < 2:
        return w_min + 0.67 * w_span, w_min + 0.33 * w_span

    for i, b_cand in enumerate(cand_thresholds):
        for a_cand in cand_thresholds[i + 1:]:
            obj = shadow_set_objective(a_cand, b_cand, w_norm)
            if obj < min_objective:
                min_objective = obj
                best_a_norm = a_cand
                best_b_norm = b_cand

    alpha_real = w_min + best_a_norm * w_span
    beta_real = w_min + best_b_norm * w_span
    return alpha_real, beta_real


def run_greedy_refinement(X_curr, y_curr, pos_feats, bdr_feats, f_dict):
    if len(pos_feats) == 0:
        top_f = max(f_dict, key=f_dict.get)
        pos_feats = [top_f]
        if top_f in bdr_feats:
            bdr_feats.remove(top_f)

    X_p = X_curr[pos_feats].copy()
    clf = create_svm()
    clf.fit(X_p, y_curr)
    acc0 = accuracy_score(y_curr, clf.predict(X_p))

    for feature in sorted(bdr_feats, key=f_dict.get, reverse=True):
        X_p[feature] = X_curr[feature]
        clf = create_svm()
        clf.fit(X_p, y_curr)
        acc_new = accuracy_score(y_curr, clf.predict(X_p))
        if acc_new > acc0:
            acc0 = acc_new
            pos_feats.append(feature)
        else:
            X_p.drop(columns=[feature], inplace=True)
    return pos_feats


# =========================================================================

# =========================================================================
def execute_ablation_variants(X_df, y_ser, gamma_arr, f_dict_gra, feature_names, run_seed):
    variants_selected = {}
    g_min, g_max = np.min(gamma_arr), np.max(gamma_arr)

    # ★ V5: TwGrey 
    alpha_v5, beta_v5 = optimize_thresholds_shadow_gra(gamma_arr, step=0.005)
    pos_v5 = [f for f, s in f_dict_gra.items() if s >= alpha_v5]
    bdr_v5 = [f for f, s in f_dict_gra.items() if beta_v5 < s < alpha_v5]
    v5_feats = run_greedy_refinement(X_df, y_ser, pos_v5, bdr_v5, f_dict_gra)
    variants_selected["V5"] = v5_feats

    # V1: GRA-only，
    sorted_by_gra = sorted(f_dict_gra.keys(), key=f_dict_gra.get, reverse=True)
    variants_selected["V1"] = sorted_by_gra[:14]

    # V2: Fixed-TWD
    alpha_v2 = g_min + 0.67 * (g_max - g_min)
    v2_feats = [f for f, s in f_dict_gra.items() if s >= alpha_v2]
    if len(v2_feats) == 0:
        v2_feats = [sorted_by_gra[0]]
    variants_selected["V2"] = v2_feats

    # V3: Shadowed-TWD 
    v3_feats = [f for f, s in f_dict_gra.items() if s >= alpha_v5]
    if len(v3_feats) == 0:
        v3_feats = [sorted_by_gra[0]]
    variants_selected["V3"] = v3_feats

    # V4: W/o Boundary Refinement
    if len(bdr_v5) > 0:
        bdr_scores = [f_dict_gra[f] for f in bdr_v5]
        median_score = np.median(bdr_scores)
        bdr_accepted = [f for f in bdr_v5 if f_dict_gra[f] >= median_score]
    else:
        bdr_accepted = []
    v4_feats = list(set(v3_feats + bdr_accepted))
    variants_selected["V4"] = v4_feats

    # ★ V6: TwReliefF 
    relieff_seed = 42 if run_seed == 42 else run_seed
    f_dict_relieff = compute_relieff_weights(
        X_df.values, y_ser.values, feature_names, r=100, k=5, seed=relieff_seed
    )
    alpha_v6, beta_v6 = optimize_thresholds_shadow_relieff(f_dict_relieff, step=0.005)
    pos_v6 = [f for f, w in f_dict_relieff.items() if w >= alpha_v6]
    bdr_v6 = [f for f, w in f_dict_relieff.items() if beta_v6 < w < alpha_v6]
    v6_feats = run_greedy_refinement(X_df, y_ser, pos_v6, bdr_v6, f_dict_relieff)
    variants_selected["V6"] = v6_feats

    return variants_selected


# =========================================================================

# =========================================================================
def plot_ablation_single_run(final_summary, sample_scales):
    print("\n" + "=" * 65)
    print("📊 (image_ablation_single6.png)...")
    print("=" * 65)

    variant_keys = ["V1", "V2", "V3", "V4", "V5", "V6"]

    fig, ax = plt.subplots(figsize=(10, 5.2))
    x = np.arange(len(variant_keys))
    width = 0.2
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

    for i, scale in enumerate(sample_scales):
        means = [np.mean([item["acc"] for item in final_summary[scale][v]])
                 for v in variant_keys]
        ax.bar(x + (i - 1.5) * width, means, width,
               label=f'$n = {scale:,}$', color=colors[i], alpha=0.85)

    ax.set_xticks(x)
    ax.set_xticklabels(variant_keys, fontsize=10.5)
    ax.set_xlabel('Ablation variant', fontsize=12, fontweight='bold', labelpad=8)
    ax.set_ylabel('Classification accuracy (%)', fontsize=12, fontweight='bold', labelpad=8)
    ax.set_ylim(70, 98)
    ax.grid(True, linestyle='--', alpha=0.35, axis='y')
    ax.legend(loc='lower right', frameon=True, facecolor='white',
              framealpha=0.9, fontsize=10)
    plt.tight_layout()

    save_png = "image_ablation_single6.png"
    save_pdf = "image_ablation_single6.pdf"
    plt.savefig(save_png, dpi=FIG_DPI, bbox_inches='tight')
    plt.savefig(save_pdf, format='pdf', bbox_inches='tight')
    print(f"✅ : {os.path.abspath(save_png)}")
    plt.show()


# =========================================================================

# =========================================================================
def run_real_data_ablation():
    print("=" * 85)
    
    print("=" * 85)

    sample_scales = [160, 400, 800, 2800]
    k_runs = 1
    variant_keys = ["V1", "V2", "V3", "V4", "V5", "V6"]
    final_summary = {scale: {v: [] for v in variant_keys} for scale in sample_scales}

    for scale in sample_scales:
        file_path = data_paths[scale]
        current_rho = optimal_rhos[scale]
        print(f"\n📁  n = {scale} (rho* = {current_rho})")
        df = pd.read_excel(file_path)
        X_all = df.iloc[:, :-1].values
        y_all = df.iloc[:, -1].values
        feature_names = df.columns[:-1].tolist()

        for k in range(k_runs):
            run_seed = 42
            np.random.seed(run_seed)

            X_train, X_test, y_train, y_test = train_test_split(
                X_all, y_all, test_size=0.30,
                random_state=run_seed, stratify=y_all
            )
            X_train_df = pd.DataFrame(X_train, columns=feature_names)
            y_train_ser = pd.Series(y_train)
            X_test_df = pd.DataFrame(X_test, columns=feature_names)

            gamma_train = compute_gra_importance(
                X_train_df.values, y_train_ser.values, rho=current_rho
            )
            f_dict_gra = dict(zip(feature_names, gamma_train))

            variants_feats = execute_ablation_variants(
                X_train_df, y_train_ser, gamma_train,
                f_dict_gra, feature_names, run_seed
            )

            for v_key in variant_keys:
                selected = variants_feats[v_key]
                if len(selected) == 0:
                    acc = 0.0
                else:
                    clf = create_svm()
                    clf.fit(X_train_df[selected].values, y_train_ser.values)
                    y_pred = clf.predict(X_test_df[selected].values)
                    acc = accuracy_score(y_test, y_pred) * 100.0

                final_summary[scale][v_key].append(
                    {"acc": acc, "num_feats": len(selected)}
                )

    # =========================================================================
    
    # =========================================================================
    print("\n" + "=" * 95)
    
    print("=" * 95)

    table_rows = []
    for v_key in variant_keys:
        row_data = {"Variant": v_key}
        for scale in sample_scales:
            acc_list = [item["acc"] for item in final_summary[scale][v_key]]
            feats_list = [item["num_feats"] for item in final_summary[scale][v_key]]
            mean_acc = np.mean(acc_list)
            avg_feats = int(np.round(np.mean(feats_list)))
            row_data[f"acc_{scale}"] = f"{mean_acc:.2f}"
            row_data[f"feat_{scale}"] = avg_feats
        table_rows.append(row_data)

    df_out = pd.DataFrame(table_rows)
    print(df_out.to_string(index=False))

    # =========================================================================
    # =========================================================================
    print("\n" + "=" * 80)
    print("=" * 80)
    print(r"\begin{table}[htbp]")
    print(r"    \centering")
    print(r"    \small")
    print(r"    \caption{Classification accuracy (\%) and selected feature count across ablation variants on a single stratified split ($\text{random\_state}=42$).}")
    print(r"    \label{tab:ablation_results}")
    print(r"    \resizebox{\textwidth}{!}{%")
    print(r"       \begin{tabular}{@{}lcccccccc@{}}")
    print(r"          \toprule")
    print(r"          \multirow{2}{*}{\textbf{Variant}} & \multicolumn{2}{c}{\textbf{$n = 160$}} & \multicolumn{2}{c}{\textbf{$n = 400$}} & \multicolumn{2}{c}{\textbf{$n = 800$}} & \multicolumn{2}{c}{\textbf{$n = 2{,}800$}} \\")
    print(r"          \cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7} \cmidrule(lr){8-9}")
    print(r"          & \textbf{Accuracy (\%)} & \textbf{\# Feat.} & \textbf{Accuracy (\%)} & \textbf{\# Feat.} & \textbf{Accuracy (\%)} & \textbf{\# Feat.} & \textbf{Accuracy (\%)} & \textbf{\# Feat.} \\")
    print(r"          \midrule")

    for row in table_rows:
        v = row["Variant"]
        if v == "V5":
            print(
                f"        \\textbf{{{v} (TwGrey full)}} & \\textbf{{{row['acc_160']}}} & \\textbf{{{row['feat_160']}}} & "
                f"\\textbf{{{row['acc_400']}}} & \\textbf{{{row['feat_400']}}} & "
                f"\\textbf{{{row['acc_800']}}} & \\textbf{{{row['feat_800']}}} & "
                f"\\textbf{{{row['acc_2800']}}} & \\textbf{{{row['feat_2800']}}} \\\\"
            )
        elif v == "V6":
            print(
                f"        {v} (TwReliefF)       & {row['acc_160']} & {row['feat_160']} & "
                f"{row['acc_400']} & {row['feat_400']} & "
                f"{row['acc_800']} & {row['feat_800']} & "
                f"{row['acc_2800']} & {row['feat_2800']} \\\\"
            )
        else:
            print(
                f"        {v:<21} & {row['acc_160']} & {row['feat_160']} & "
                f"{row['acc_400']} & {row['feat_400']} & "
                f"{row['acc_800']} & {row['feat_800']} & "
                f"{row['acc_2800']} & {row['feat_2800']} \\\\"
            )

    print(r"          \bottomrule")
    print(r"       \end{tabular}%")
    print(r"    }")
    print(r"    \vspace{1.2ex}")
    print(r"    \noindent\parbox{\textwidth}{%")
    print(r"       \fontsize{8pt}{11pt}\selectfont")
    print(r"       \emergencystretch=1.5em")
    print(r"       \textit{Note:} All feature weights (GRA or ReliefF), shadowed-set thresholds, and greedy boundary refinement are computed exclusively on the 70\% training partition. Accuracy is evaluated on the mutually exclusive 30\% test partition. Results are reported for a single stratified split ($\text{random\_state} = 42$), consistent with the main experiments in Table~\ref{Table 3}. \# Feat. denotes the cardinality of the selected feature subset. \par")
    print(r"    }")
    print(r"\end{table}")

    plot_ablation_single_run(final_summary, sample_scales)


if __name__ == "__main__":
    run_real_data_ablation()