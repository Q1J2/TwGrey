import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import (
    accuracy_score, auc, confusion_matrix,
    f1_score, precision_score, recall_score, roc_curve,
)
from sklearn.preprocessing import label_binarize
from sklearn.svm import SVC

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

bridge_export_dir = r"D:\NWPU_Experiment\BridgeFeature_256"

# =========================================================================

# =========================================================================
bridge_paths = {
    160:  (os.path.join(bridge_export_dir, "TripletFeat256_N160_train.xlsx"),
           os.path.join(bridge_export_dir, "TripletFeat256_N160_val.xlsx")),
    400:  (os.path.join(bridge_export_dir, "TripletFeat256_N400_train.xlsx"),
           os.path.join(bridge_export_dir, "TripletFeat256_N400_val.xlsx")),
    800:  (os.path.join(bridge_export_dir, "TripletFeat256_N800_train.xlsx"),
           os.path.join(bridge_export_dir, "TripletFeat256_N800_val.xlsx")),
    2800: (os.path.join(bridge_export_dir, "TripletFeat256_N2800_train.xlsx"),
           os.path.join(bridge_export_dir, "TripletFeat256_N2800_val.xlsx")),
    "UCM_2000": (os.path.join(bridge_export_dir, "TripletFeat256_NUCM_2000_train.xlsx"),
                 os.path.join(bridge_export_dir, "TripletFeat256_NUCM_2000_val.xlsx")),
}

export_dir = r"D:\NWPU_Experiment\GRA_Shadow_Multi"
export_dir_cmp = r"D:\NWPU_Experiment\Comparison_Multi"
os.makedirs(export_dir, exist_ok=True)
os.makedirs(export_dir_cmp, exist_ok=True)


def compute_gra_weights(X_mat, y_vec, feature_names, rho):
    X_mat = np.asarray(X_mat, dtype=np.float64)
    y_vec = np.asarray(y_vec)
    diffs = np.abs(X_mat - y_vec.reshape(-1, 1))
    dmin = diffs.min(); dmax = diffs.max()
    grd = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        grd[i] = np.mean((dmin + rho * dmax) / (diffs[:, i] + rho * dmax))
    return grd, dict(zip(feature_names, grd))


def shadow_obj(a, b, g):
    sig = g[g >= a]; ins = g[g <= b]; sh = g[(g > b) & (g < a)]
    return abs(np.sum(1.0 - sig) + np.sum(ins) - len(sh))


def optimize_thresholds(g, step=0.005):
    g = np.asarray(g, dtype=np.float64)
    gmin, gmax = g.min(), g.max()
    cand = np.arange(gmin + step, gmax, step)
    if len(cand) < 2:
        return gmin + 0.67 * (gmax - gmin), gmin + 0.33 * (gmax - gmin)
    best_obj, best_a, best_b = float("inf"), 0.0, 0.0
    for i, b in enumerate(cand):
        for a in cand[i + 1:]:
            o = shadow_obj(a, b, g)
            if o < best_obj:
                best_obj, best_a, best_b = o, a, b
    return best_a, best_b


def create_svm():
    return SVC(C=1.0, kernel='rbf', gamma='scale',
               decision_function_shape='ovr', probability=True, random_state=42)


def evaluate(m, X, y):
    yp = m.predict(X)
    return (accuracy_score(y, yp),
            precision_score(y, yp, average='macro', zero_division=0),
            recall_score(y, yp, average='macro', zero_division=0),
            f1_score(y, yp, average='macro', zero_division=0))


def compute_maf1_ci(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes); n = len(y_true)
    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)
    p = cm / n
    pr = np.sum(p, axis=1); pc = np.sum(p, axis=0); pd_ = np.diag(p)
    denom = pr + pc; valid = denom > 0
    F1 = np.zeros(r); F1[valid] = 2.0 * pd_[valid] / denom[valid]
    maf1 = np.mean(F1)
    diff_p = denom - 2.0 * pd_
    A = 0.0
    for i in range(r):
        if denom[i] > 0:
            A += ((F1[i]*diff_p[i])/(denom[i]**2)) * ((diff_p[i]/denom[i]) + F1[i]/2.0)
    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p[i,j]*F1[i]*F1[j])/(denom[i]*denom[j])
    var = (2.0/(n*(r**2)))*(A+B); se = np.sqrt(max(0, var))
    z = norm.ppf(1.0 - alpha/2.0)
    return maf1, se, (max(0.0, maf1 - z*se), min(1.0, maf1 + z*se))


benchmark_summary = []
roc_plot_data = {}
candidate_rhos = np.round(np.arange(0.1, 1.0, 0.1), 1)

for n_samples, (train_xlsx, val_xlsx) in bridge_paths.items():
    print("\n" + "=" * 80)
    print(f"🚀 N={n_samples} | GRA-Shadow on Triplet-256")
    print("=" * 80)

    if not os.path.exists(train_xlsx):
        print(f"⚠️ {train_xlsx}。")
        continue

    df_train = pd.read_excel(train_xlsx)
    df_val = pd.read_excel(val_xlsx)

    feature_names = df_train.columns[:-1].tolist()
    X_train = df_train.iloc[:, :-1]; y_train = df_train.iloc[:, -1]
    X_val = df_val.iloc[:, :-1]; y_val = df_val.iloc[:, -1]

    print(f"📊 train={len(y_train)}, val={len(y_val)}, D={X_train.shape[1]}")

    records = []
    for rho in candidate_rhos:
        gamma_tr, f_imp = compute_gra_weights(X_train.values, y_train.values, feature_names, rho=rho)
        alpha, beta = optimize_thresholds(gamma_tr, step=0.005)

        pos = [f for f, s in f_imp.items() if s >= alpha]
        bdr = [f for f, s in f_imp.items() if beta < s < alpha]

        if len(pos) == 0:
            top = max(f_imp, key=f_imp.get); pos.append(top)
            if top in bdr: bdr.remove(top)

        X_tr_pos = X_train[pos].copy()
        svm_t = create_svm(); svm_t.fit(X_tr_pos, y_train)
        acc0, _, _, _ = evaluate(svm_t, X_tr_pos, y_train)

        for f in sorted(bdr, key=f_imp.get, reverse=True):
            X_tr_pos[f] = X_train[f]
            cand = create_svm(); cand.fit(X_tr_pos, y_train)
            acc_c, _, _, _ = evaluate(cand, X_tr_pos, y_train)
            if acc_c > acc0:
                acc0 = acc_c; pos.append(f)
            else:
                X_tr_pos.drop(columns=[f], inplace=True)

        final = create_svm(); final.fit(X_train[pos], y_train)
        va, vp, vr, vf1 = evaluate(final, X_val[pos], y_val)

        records.append({
            "rho": rho, "alpha": alpha, "beta": beta,
            "pos": pos, "model": final,
            "Accuracy": va, "maP": vp, "maR": vr, "Macro_F1": vf1, "Features": len(pos),
        })

    sens = pd.DataFrame(records)
    best_idx = sens.sort_values(by=["Macro_F1", "Accuracy", "Features"],
                                ascending=[False, False, True]).index[0]
    best = records[best_idx]

    best_rho = best["rho"]; alpha_b = best["alpha"]; beta_b = best["beta"]
    sel = best["pos"]; final_svm = best["model"]
    va, vp, vr, vf1 = best["Accuracy"], best["maP"], best["maR"], best["Macro_F1"]

    X_val_sub = X_val[sel]
    y_pred = final_svm.predict(X_val_sub)
    y_proba = final_svm.predict_proba(X_val_sub)

    y_bin = label_binarize(y_val, classes=final_svm.classes_)
    n_cls = len(final_svm.classes_)
    all_fpr = np.unique(np.concatenate([roc_curve(y_bin[:, i], y_proba[:, i])[0] for i in range(n_cls)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_cls):
        fpr_i, tpr_i, _ = roc_curve(y_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_cls
    macro_auc = auc(all_fpr, mean_tpr)

    _, se_val, (ci_low, ci_high) = compute_maf1_ci(y_val.values, y_pred, alpha=0.05)

    np.savez(os.path.join(export_dir_cmp, f"roc_data_{n_samples}_GRA_Shadow_Triplet256.npz"),
             y_true=y_val.values, y_proba=y_proba, classes=final_svm.classes_)

    roc_plot_data[n_samples] = {'y_true': y_val.values, 'y_proba': y_proba, 'classes': final_svm.classes_}

    print(f"🎯 rho*={best_rho:.1f} | (α,β)=({alpha_b:.4f},{beta_b:.4f})")
    print(f"🏆 N={n_samples} | K={len(sel)}/{X_train.shape[1]} | Acc={va*100:.2f}% | "
          f"F1={vf1*100:.2f}% (SE={se_val:.4f}) | AUC={macro_auc:.4f}")
    print(f"🔒 CI: [{ci_low*100:.2f}%, {ci_high*100:.2f}%]")

    benchmark_summary.append({
        "Dataset": "UCM" if n_samples == "UCM_2000" else "NWPU",
        "Sample Size (N)": n_samples,
        "Num Classes": len(np.unique(y_train)),
        "rho": f"{best_rho:.1f}",
        "Threshold (alpha, beta)": f"({alpha_b:.4f}, {beta_b:.4f})",
        "Total Features": X_train.shape[1],
        "Selected Features": len(sel),
        "Accuracy (%)": f"{va*100:.2f}",
        "Macro Precision (%)": f"{vp*100:.2f}",
        "Macro Recall (%)": f"{vr*100:.2f}",
        "Macro F1 (%)": f"{vf1*100:.2f}",
        "Macro F1 (95% CI)": f"{vf1*100:.2f} [{ci_low*100:.2f}, {ci_high*100:.2f}]",
        "Macro-AUC": f"{macro_auc:.4f}",
        "raw_f1": vf1*100, "raw_ci_low": ci_low*100,
        "raw_ci_high": ci_high*100, "raw_se": se_val*100,
    })


# =========================================================================

# =========================================================================
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']

fig, ax = plt.subplots(figsize=(6.5, 4.2))
scales = [row["Sample Size (N)"] for row in benchmark_summary]
f1_vals = [row["raw_f1"] for row in benchmark_summary]
yerr_low = [row["raw_f1"] - row["raw_ci_low"] for row in benchmark_summary]
yerr_high = [row["raw_ci_high"] - row["raw_f1"] for row in benchmark_summary]
ax.errorbar(range(len(scales)), f1_vals, yerr=[yerr_low, yerr_high],
            fmt='-o', color='#2ca02c', ecolor='#d62728',
            elinewidth=2, capsize=5, capthick=1.5, markersize=6)
ax.set_xticks(range(len(scales)))
ax.set_xticklabels([str(s) for s in scales])
ax.set_xlabel('Sample scale / Dataset')
ax.set_ylabel('Macro-F1 score (%)')
ax.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(export_dir, "GRA_Shadow_Triplet256_MacroF1_CI.pdf"), bbox_inches='tight')
plt.close()

fig, ax = plt.subplots(figsize=(6.5, 5))
for idx, (n_samples, data) in enumerate(roc_plot_data.items()):
    y_true_bin = label_binarize(data['y_true'], classes=data['classes'])
    y_proba = data['y_proba']
    n_classes = len(data['classes'])
    all_fpr = np.unique(np.concatenate([roc_curve(y_true_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_true_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)
    ax.plot(all_fpr, mean_tpr, color=colors[idx % len(colors)], lw=2,
            label=f'{n_samples} (AUC = {macro_auc:.4f})')
ax.plot([0, 1], [0, 1], 'k--', lw=1.2)
ax.set_xlim([0, 1]); ax.set_ylim([0, 1.05])
ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
ax.grid(True, linestyle='--', alpha=0.5)
ax.legend(loc='lower right', fontsize=10)
plt.tight_layout()
plt.savefig(os.path.join(export_dir, "GRA_Shadow_Triplet256_ROC.pdf"), bbox_inches='tight')
plt.close()

print(f"\n📊 : {export_dir}")

# =========================================================================

# =========================================================================
df_summary = pd.DataFrame(benchmark_summary)
print("\n" + "=" * 130)
print(df_summary[["Dataset", "Sample Size (N)", "Num Classes", "rho",
                  "Total Features", "Selected Features", "Accuracy (%)",
                  "Macro F1 (95% CI)", "Macro-AUC"]].to_string(index=False))