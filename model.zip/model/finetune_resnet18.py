# -*- coding: utf-8 -*-


import os
import copy
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from PIL import Image
from tqdm import tqdm
import random


DATASET_ROOT = "/root/autodl-tmp/NWPU-RESISC45_dataset"
OUTPUT_DIR = "/root/autodl-tmp/NWPU_ResNet18_Finetuned"
os.makedirs(OUTPUT_DIR, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

SEED = 42
random.seed(SEED); np.random.seed(SEED)
torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)


IMG_SIZE = 224
BATCH_SIZE = 64
EPOCHS = 20                    
LR = 1e-4
NUM_WORKERS = 4
VAL_RATIO = 0.3                


# =========================================================================

# =========================================================================
class NWPUDataset(Dataset):
    def __init__(self, root_dir, paths, labels, transform):
        self.root_dir = root_dir
        self.paths = paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        p = self.paths[idx]
        y = self.labels[idx]
        img = Image.open(p).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, y


def build_stratified_split(root_dir, val_ratio=0.3, seed=42):
  
    rng = random.Random(seed)
    class_names = sorted([d for d in os.listdir(root_dir)
                          if os.path.isdir(os.path.join(root_dir, d))])
    tr_p, tr_l, va_p, va_l = [], [], [], []
    for ci, name in enumerate(class_names):
        d = os.path.join(root_dir, name)
        files = sorted([f for f in os.listdir(d)
                        if os.path.isfile(os.path.join(d, f))
                        and f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'))])
        rng.shuffle(files)
        sp = int((1.0 - val_ratio) * len(files))
        for f in files[:sp]:
            tr_p.append(os.path.join(d, f)); tr_l.append(ci)
        for f in files[sp:]:
            va_p.append(os.path.join(d, f)); va_l.append(ci)
    return tr_p, tr_l, va_p, va_l, class_names


# =========================================================================

# =========================================================================
def build_model(num_classes):
    model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
    model.fc = nn.Linear(model.fc.in_features, num_classes)   # 512 → 45
    return model.to(DEVICE)


# =========================================================================

# =========================================================================
def train_one_epoch(model, loader, criterion, optimizer, epoch):
    model.train()
    total_loss, correct, total = 0.0, 0, 0
    pbar = tqdm(loader, desc=f"Epoch {epoch+1} [train]")
    for imgs, labels in pbar:
        imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
        optimizer.zero_grad()
        out = model(imgs)
        loss = criterion(out, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * imgs.size(0)
        _, pred = out.max(1)
        correct += pred.eq(labels).sum().item()
        total += imgs.size(0)
        pbar.set_postfix(loss=f"{total_loss/total:.4f}", acc=f"{correct/total:.4f}")
    return total_loss / total, correct / total


@torch.no_grad()
def eval_model(model, loader):
    model.eval()
    correct, total = 0, 0
    for imgs, labels in loader:
        imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
        out = model(imgs)
        _, pred = out.max(1)
        correct += pred.eq(labels).sum().item()
        total += imgs.size(0)
    return correct / total


# =========================================================================

# =========================================================================
@torch.no_grad()
def extract_features(model, loader):
    model.eval()
    feats_all, labels_all = [], []
    for imgs, labels in tqdm(loader, desc="Extracting"):
        imgs = imgs.to(DEVICE)
        feats = model(imgs)             # 512 维
        feats_all.append(feats.cpu().numpy())
        labels_all.append(labels.numpy())
    feats = np.vstack(feats_all).astype(np.float32)
    labels = np.concatenate(labels_all).astype(np.int32)

    feats = feats / np.clip(np.linalg.norm(feats, axis=1, keepdims=True), 1e-12, None)
    return feats, labels


# =========================================================================

# =========================================================================
def main():
    print("=" * 80)
    print("🚀 ResNet18 in NWPU-RESISC45")
    print("=" * 80)

   
    tr_p, tr_l, va_p, va_l, class_names = build_stratified_split(
        DATASET_ROOT, val_ratio=VAL_RATIO, seed=SEED)
    num_classes = len(class_names)
    print(f"📊 ={num_classes}, train={len(tr_p)}, val={len(va_p)}")

    
    train_transform = transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    
    eval_transform = transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    train_ds = NWPUDataset(DATASET_ROOT, tr_p, tr_l, train_transform)
    val_ds = NWPUDataset(DATASET_ROOT, va_p, va_l, eval_transform)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=NUM_WORKERS, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False,
                            num_workers=NUM_WORKERS, pin_memory=True)


    model = build_model(num_classes)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LR)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)


    print("\n" + "=" * 80)
    print(f"({EPOCHS} epochs, batch={BATCH_SIZE}, lr={LR})")
    print("=" * 80)
    best_acc = 0.0
    best_state = None
    for epoch in range(EPOCHS):
        t0 = time.time()
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, epoch)
        val_acc = eval_model(model, val_loader)
        scheduler.step()
        dt = time.time() - t0
        print(f"✅ Epoch {epoch+1:2d}/{EPOCHS} | loss={train_loss:.4f} | "
              f"train_acc={train_acc*100:.2f}% | val_acc={val_acc*100:.2f}% | {dt:.1f}s")
        if val_acc > best_acc:
            best_acc = val_acc
            best_state = copy.deepcopy(model.state_dict())

    
    model.load_state_dict(best_state)
    print(f"\n🏆 Best Val Acc = {best_acc*100:.2f}%")

 
    model_path = os.path.join(OUTPUT_DIR, "resnet18_nwpu_best.pth")
    torch.save(best_state, model_path)
    print(f"💾 {model_path}")

    
    print("\n" + "=" * 80)
    
    print("=" * 80)
    model.fc = nn.Identity()   
    model.eval()

    feat_extractor_train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE,
                                              shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)
    feat_extractor_val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE,
                                            shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)

    print(" train Feature ...")
    F_train, y_train = extract_features(model, feat_extractor_train_loader)
    print(" val Feature...")
    F_val, y_val = extract_features(model, feat_extractor_val_loader)

    print(f"✅ F_train: {F_train.shape}, F_val: {F_val.shape}")


    np.save(os.path.join(OUTPUT_DIR, "NWPU_resnet18_finetuned_512d_train.npy"), F_train)
    np.save(os.path.join(OUTPUT_DIR, "NWPU_resnet18_finetuned_512d_val.npy"), F_val)
    np.save(os.path.join(OUTPUT_DIR, "NWPU_resnet18_finetuned_train_labels.npy"), y_train)
    np.save(os.path.join(OUTPUT_DIR, "NWPU_resnet18_finetuned_val_labels.npy"), y_val)

    
    F_full = np.vstack([F_train, F_val])
    y_full = np.concatenate([y_train, y_val])
    np.save(os.path.join(OUTPUT_DIR, "NWPU_resnet18_finetuned_512d_features.npy"), F_full)
    np.save(os.path.join(OUTPUT_DIR, "NWPU_resnet18_finetuned_labels.npy"), y_full)

    print(f"💾 {OUTPUT_DIR}")
    print(f"   - NWPU_resnet18_finetuned_512d_features.npy: {F_full.shape}")
    print(f"   - NWPU_resnet18_finetuned_labels.npy: {y_full.shape}")
    print("\n✅ ")


if __name__ == "__main__":
    main()