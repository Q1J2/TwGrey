import os
import random
import math
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from PIL import Image
from scipy.stats import norm
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    auc,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_curve,
)
from sklearn.preprocessing import label_binarize, normalize
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed(42)

# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )

# =========================================================================

# =========================================================================
def build_stratified_split(root_dir, val_ratio=0.3, seed=42):
    
    rng = random.Random(seed)

    class_names = sorted([d for d in os.listdir(root_dir)
                          if os.path.isdir(os.path.join(root_dir, d))])

    train_paths, train_labels, val_paths, val_labels = [], [], [], []
    for cls_idx, name in enumerate(class_names):
        cls_dir = os.path.join(root_dir, name)
        files = sorted([
            f for f in os.listdir(cls_dir)
            if os.path.isfile(os.path.join(cls_dir, f))
            and f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'))
        ])
        rng.shuffle(files)
        split_pt = int((1.0 - val_ratio) * len(files))
        for f in files[:split_pt]:
            train_paths.append(os.path.join(cls_dir, f))
            train_labels.append(cls_idx)
        for f in files[split_pt:]:
            val_paths.append(os.path.join(cls_dir, f))
            val_labels.append(cls_idx)

    return train_paths, train_labels, val_paths, val_labels, class_names

# =========================================================================

# =========================================================================
data_paths = {
   400: r"D:\e\UCM\UCM100\Triplet",
   240: r"D:\e\NWPU\NWPU240\NWPU240Triplet",
}

export_dir = r"D:\e\NWPU\Experiment_Plots_Siamese_RBF4"
os.makedirs(export_dir, exist_ok=True)

# =========================================================================

# =========================================================================
class SiameseDataset(Dataset):
    def __init__(self, image_paths, labels, transform=None):
        self.image_paths = image_paths
        self.labels = labels
        self.transform = transform
        self.label_to_indices = {l: np.where(np.array(labels) == l)[0] for l in set(labels)}

    def __getitem__(self, index):
        img1_path = self.image_paths[index]
        label1 = self.labels[index]

        is_same = random.randint(0, 1)
        if is_same:
            idx2 = random.choice(self.label_to_indices[label1])
        else:
            diff_labels = list(set(self.labels) - {label1})
            label2 = random.choice(diff_labels)
            idx2 = random.choice(self.label_to_indices[label2])

        img2_path = self.image_paths[idx2]
        target = torch.tensor(0 if label1 == self.labels[idx2] else 1, dtype=torch.float)

        img1 = Image.open(img1_path).convert('RGB')
        img2 = Image.open(img2_path).convert('RGB')

        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        return img1, img2, target

    def __len__(self):
        return len(self.image_paths)

class SimpleEvalDataset(Dataset):
    def __init__(self, image_paths, labels, transform=None):
        self.image_paths = image_paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img = Image.open(self.image_paths[idx]).convert('RGB')
        if self.transform:
            img = self.transform(img)
        return img, self.labels[idx]

# =========================================================================

# =========================================================================
class ContrastiveLoss(nn.Module):
    def __init__(self, margin=2.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, out1, out2, target):
        euclidean_dist = F.pairwise_distance(out1, out2)
        loss = torch.mean(
            (1.0 - target) * torch.pow(euclidean_dist, 2) +
            target * torch.pow(torch.clamp(self.margin - euclidean_dist, min=0.0), 2)
        )
        return loss

class SiameseNet(nn.Module):
    def __init__(self, embedding_dim=256):
        super(SiameseNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.AdaptiveAvgPool2d((1, 1))
        )
        self.fc = nn.Linear(128, embedding_dim)

    def forward_once(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        x = F.normalize(x, p=2, dim=1)
        return x

    def forward(self, input1, input2):
        return self.forward_once(input1), self.forward_once(input2)

def extract_features(model, dataloader, device):
    model.eval()
    feats, lbls = [], []
    with torch.no_grad():
        for imgs, targets in dataloader:
            imgs = imgs.to(device)
            out = model.forward_once(imgs)
            feats.append(out.cpu().numpy())
            lbls.append(targets.numpy())
    return np.concatenate(feats), np.concatenate(lbls)

# =========================================================================

# =========================================================================
def compute_maf1_confidence_interval(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes)
    n = len(y_true)

    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)
    p_hat = cm / n
    p_row = np.sum(p_hat, axis=1)
    p_col = np.sum(p_hat, axis=0)
    p_diag = np.diag(p_hat)

    denom = p_row + p_col
    valid_mask = denom > 0

    F1_i = np.zeros(r)
    F1_i[valid_mask] = 2.0 * p_diag[valid_mask] / denom[valid_mask]
    maF1 = np.mean(F1_i)

    diff_p = denom - 2.0 * p_diag
    A_terms = np.zeros(r)
    for i in range(r):
        if denom[i] > 0:
            term1 = (F1_i[i] * diff_p[i]) / (denom[i] ** 2)
            term2 = (diff_p[i] / denom[i]) + (F1_i[i] / 2.0)
            A_terms[i] = term1 * term2
    A = np.sum(A_terms)

    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p_hat[i, j] * F1_i[i] * F1_i[j]) / (denom[i] * denom[j])

    var_maF1 = (2.0 / (n * (r ** 2))) * (A + B)
    se_maF1 = np.sqrt(max(0.0, var_maF1))

    z = norm.ppf(1.0 - alpha / 2.0)
    ci_lower = max(0.0, maF1 - z * se_maF1)
    ci_upper = min(1.0, maF1 + z * se_maF1)
    return maF1, se_maF1, (ci_lower, ci_upper)

# =========================================================================

# =========================================================================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
])

benchmark_summary = []
roc_plot_data = {}
all_losses_history = {}
BATCH_SIZE = 32
EPOCHS = 50

for n_samples, path in data_paths.items():
    set_seed(42)
    print("\n" + "=" * 80)
    print(f"🚀 : N = {n_samples} | 路径: {path}")
    print("=" * 80)

  
    train_paths, train_labels, val_paths, val_labels, class_names = build_stratified_split(
        path, val_ratio=0.3, seed=42
    )

    
    train_ds = SiameseDataset(train_paths, train_labels, transform=transform)
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True)

    model = SiameseNet(embedding_dim=256).to(device)
    criterion = ContrastiveLoss(margin=2.0)
    optimizer = optim.Adam(model.parameters(), lr=1e-4)

    print(f"⏳ (Epochs={EPOCHS}, Steps={len(train_loader)})...")
    epoch_losses = []
    for epoch in range(EPOCHS):
        model.train()
        running_loss = 0.0
        for img1, img2, target in train_loader:
            img1, img2, target = img1.to(device), img2.to(device), target.to(device)
            optimizer.zero_grad()
            out1, out2 = model(img1, img2)
            loss = criterion(out1, out2, target)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        epoch_losses.append(running_loss / len(train_loader))

    all_losses_history[n_samples] = epoch_losses
    
    fig_single, ax_single = plt.subplots(figsize=(6.5, 4.2))
    ax_single.plot(range(1, EPOCHS + 1), epoch_losses, color='#1f77b4', lw=2.0, marker='o', markersize=3,
                   label=f'N = {n_samples} (Final loss: {epoch_losses[-1]:.4f})'
                   )
    ax_single.set_xlabel('Epochs', fontsize=12)
    ax_single.set_ylabel('Siamese loss', fontsize=12)
    # ax_single.set_title(f'Triplet Loss Convergence Curve (N={n_samples})', fontsize=12, fontweight='bold')
    ax_single.grid(True, linestyle='--', alpha=0.5)
    ax_single.legend(loc='upper right')
    plt.tight_layout()

    single_loss_pdf = os.path.join(export_dir, f"Siamese_loss_convergence_N{n_samples}.pdf")
    single_loss_png = os.path.join(export_dir, f"Siamese_loss_convergence_N{n_samples}.png")
    plt.savefig(single_loss_pdf, format='pdf', bbox_inches='tight')
    plt.savefig(single_loss_png, dpi=FIG_DPI, bbox_inches='tight')
    plt.close()

    
    eval_train_loader = DataLoader(SimpleEvalDataset(train_paths, train_labels, transform), batch_size=BATCH_SIZE, shuffle=False)
    eval_val_loader = DataLoader(SimpleEvalDataset(val_paths, val_labels, transform), batch_size=BATCH_SIZE, shuffle=False)

    X_train_feats, y_train_arr = extract_features(model, eval_train_loader, device)
    X_val_feats, y_val_arr = extract_features(model, eval_val_loader, device)

    X_train_feats = normalize(X_train_feats)
    X_val_feats = normalize(X_val_feats)

    
    clf = create_svm()
    clf.fit(X_train_feats, y_train_arr)

    y_pred = clf.predict(X_val_feats)
    y_proba = clf.predict_proba(X_val_feats)

    acc = accuracy_score(y_val_arr, y_pred)
    prec = precision_score(y_val_arr, y_pred, average='macro', zero_division=0)
    rec = recall_score(y_val_arr, y_pred, average='macro', zero_division=0)
    f1 = f1_score(y_val_arr, y_pred, average='macro', zero_division=0)
    maf1_val, se_val, (ci_low, ci_high) = compute_maf1_confidence_interval(y_val_arr, y_pred, alpha=0.05)

    roc_plot_data[n_samples] = {
        'y_true': y_val_arr,
        'y_proba': y_proba,
        'classes': clf.classes_
    }

    # =========================================================================
   
    # =========================================================================
    export_dir_cmp = r"D:\e\Experiment_Plots_Comparison_RBF4"
    os.makedirs(export_dir_cmp, exist_ok=True)
    npz_save_path = os.path.join(export_dir_cmp, f"roc_data_{n_samples}_Siamese.npz")
    np.savez(
        npz_save_path,
        y_true=y_val_arr,
        y_proba=y_proba,
        classes=clf.classes_
    )
    print(f"📦  N={n_samples} Siamese: {npz_save_path}")

    print(f"🏆 : Features={X_train_feats.shape[1]} | Acc={acc*100:.2f}% | Macro-F1={f1*100:.2f}% (SE={se_val:.4f})")
    print(f"🔒 Macro-F1 95% : [{ci_low*100:.2f}%, {ci_high*100:.2f}%]")

    benchmark_summary.append({
        "Sample Size (N)": n_samples,
        "Penalty C": 1.0,
        "Selected Features": X_train_feats.shape[1],
        "Accuracy (%)": f"{acc * 100:.2f}",
        "Macro Precision (%)": f"{prec * 100:.2f}",
        "Macro Recall (%)": f"{rec * 100:.2f}",
        "Macro F1 (%)": f"{f1 * 100:.2f}",
        "Macro F1 (95% CI)": f"{f1 * 100:.2f} [{ci_low * 100:.2f}, {ci_high * 100:.2f}]",
        "raw_f1": f1 * 100,
        "raw_ci_low": ci_low * 100,
        "raw_ci_high": ci_high * 100,
        "raw_se": se_val * 100
    })

# =========================================================================

# =========================================================================
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']


fig_loss, ax_loss = plt.subplots(figsize=(6.5, 4.5))
for idx, (n_samples, loss_curve_vals) in enumerate(all_losses_history.items()):
    ax_loss.plot(
        range(1, EPOCHS + 1), loss_curve_vals,
        color=colors[idx % len(colors)], lw=2.0,
        label=f'N = {n_samples} (Final loss: {loss_curve_vals[-1]:.4f})'
    )
ax_loss.set_xlabel('Epochs', fontsize=12)
ax_loss.set_ylabel('Contrastive loss', fontsize=12)
ax_loss.grid(True, linestyle='--', alpha=0.5)
ax_loss.legend(loc='upper right', fontsize=10)
plt.tight_layout()

multi_loss_pdf = os.path.join(export_dir, "siamese_loss_convergence_all_scales.pdf")
multi_loss_png = os.path.join(export_dir, "siamese_loss_convergence_all_scales.png")
plt.savefig(multi_loss_pdf, format='pdf', bbox_inches='tight')
plt.savefig(multi_loss_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig_ci, ax_ci = plt.subplots(figsize=(6.5, 4.2))
scales = [row["Sample Size (N)"] for row in benchmark_summary]
f1_vals = [row["raw_f1"] for row in benchmark_summary]
yerr_low = [row["raw_f1"] - row["raw_ci_low"] for row in benchmark_summary]
yerr_high = [row["raw_ci_high"] - row["raw_f1"] for row in benchmark_summary]

ax_ci.errorbar(
    range(len(scales)), f1_vals, yerr=[yerr_low, yerr_high],
    fmt='-D', color='#ff7f0e', ecolor='#d62728', elinewidth=2, capsize=5, capthick=1.5,
    markersize=6, label='Macro-F1 with 95% CI (Siamese baseline)'
)
ax_ci.set_xticks(range(len(scales)))
ax_ci.set_xticklabels([f"N={s}" for s in scales])
ax_ci.set_xlabel('Sample scale (N)', fontsize=12)
ax_ci.set_ylabel('Macro-F1 score (%)', fontsize=12)
ax_ci.grid(True, linestyle='--', alpha=0.5)
ax_ci.legend(loc='lower right')
plt.tight_layout()

ci_plot_pdf = os.path.join(export_dir, "Siamese_MacroF1_Confidence_Interval.pdf")
ci_plot_png = os.path.join(export_dir, "Siamese_MacroF1_Confidence_Interval.png")
plt.savefig(ci_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(ci_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig_roc, ax_roc = plt.subplots(figsize=(6.5, 5))
for idx, (n_samples, data) in enumerate(roc_plot_data.items()):
    y_true_bin = label_binarize(data['y_true'], classes=data['classes'])
    y_proba = data['y_proba']
    n_classes = len(data['classes'])

    all_fpr = np.unique(np.concatenate([roc_curve(y_true_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_true_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

    ax_roc.plot(all_fpr, mean_tpr, color=colors[idx % len(colors)], lw=2,
            label=f'N = {n_samples} (Macro-AUC = {macro_auc:.4f})')

ax_roc.plot([0, 1], [0, 1], 'k--', lw=1.2, label='Random chance')
ax_roc.set_xlim([0.0, 1.0])
ax_roc.set_ylim([0.0, 1.05])
ax_roc.set_xlabel('False positive rate', fontsize=12)
ax_roc.set_ylabel('True positive rate', fontsize=12)
ax_roc.legend(loc='lower right', fontsize=10)
ax_roc.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()

roc_plot_pdf = os.path.join(export_dir, "Siamese_ROC_Curves.pdf")
roc_plot_png = os.path.join(export_dir, "Siamese_ROC_Curves.png")
plt.savefig(roc_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(roc_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()



# =========================================================================

# =========================================================================
df_summary = pd.DataFrame(benchmark_summary)
print("\n" + "=" * 110)

print("=" * 110)
print(df_summary[["Sample Size (N)", "Penalty C", "Selected Features", "Accuracy (%)", "Macro Precision (%)", "Macro Recall (%)", "Macro F1 (95% CI)"]].to_string(index=False))


print(r"\begin{table}[htbp]")
print(r"  \centering")
print(r"  \small")
print(r"  \caption{Performance of deep Siamese metric learning across different sample scales ($C=1.0$) on NWPU-RESISC45}")
print(r"  \label{tab:siamese_scale_results}")
print(r"  \begin{tabular}{ccccccc}")
print(r"    \toprule")
print(r"    \textbf{Sample Size ($N$)} & \textbf{Penalty $C$} & \textbf{\# Features} & \textbf{Accuracy (\%)} & \textbf{Precision (\%)} & \textbf{Recall (\%)} & \textbf{Macro F1 (95\% CI) (\%)} \\")
print(r"    \midrule")
for row in benchmark_summary:
    print(f"    {row['Sample Size (N)']} & {row['Penalty C']} & {row['Selected Features']} & {row['Accuracy (%)']} & {row['Macro Precision (%)']} & {row['Macro Recall (%)']} & {row['Macro F1 (95% CI)']} \\\\")
print(r"    \bottomrule")
print(r"  \end{tabular}")
print(r"\end{table}")