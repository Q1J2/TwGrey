import os
import matplotlib.pyplot as plt
import numpy as np

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

x_labels = [
    "NWPU\n$N=160$",
    "NWPU\n$N=400$",
    "NWPU\n$N=800$",
    "NWPU\n$N=2800$",
    "NWPU\n$N=31500$",
    "UCM\n$N=2000$"
]

data = {
    "Triplet-256": {
        "acc":     [0.8750, 0.8500, 0.9125, 0.9479, 0.6880, 0.7067],
        "f1":      [0.8778, 0.8485, 0.9119, 0.9478, 0.6843, 0.7013],
        "ci_low":  [0.7876, 0.7859, 0.8767, 0.9329, 0.6754, 0.6678],
        "ci_high": [0.9681, 0.9112, 0.9472, 0.9628, 0.6931, 0.7347],
        "color": "#1f77b4",   
        "marker": "s",
        "linestyle": "--",
    },
    "Triplet-256 + TwGrey": {
        "acc":     [0.8958, 0.8583, 0.9208, 0.9526, 0.6925, 0.7367],
        "f1":      [0.8971, 0.8573, 0.9207, 0.9526, 0.6887, 0.7345],
        "ci_low":  [0.8133, 0.7961, 0.8869, 0.9383, 0.6799, 0.7025],
        "ci_high": [0.9809, 0.9186, 0.9544, 0.9669, 0.6975, 0.7665],
        "color": "#d62728",   
        "marker": "o",
        "linestyle": "-",
    },
}

save_dir = r"D:\e\NWPU\Experiment_Plots_Comparison_Triplet256"
os.makedirs(save_dir, exist_ok=True)

# =========================================================================

# =========================================================================
fig1, ax1 = plt.subplots(figsize=(8.0, 4.6))

x_base = np.arange(len(x_labels))

offsets = [-0.08, 0.08]

for (method_name, cfg), offset in zip(data.items(), offsets):
    f1_vals = np.array(cfg["f1"])
    low_err = f1_vals - np.array(cfg["ci_low"])
    high_err = np.array(cfg["ci_high"]) - f1_vals
    yerr = [low_err, high_err]

    is_proposed = "TwGrey" in method_name
    lw = 2.2 if is_proposed else 1.5
    capsize = 4.5 if is_proposed else 3.5
    markersize = 7.0 if is_proposed else 6.0
    zorder = 10 if is_proposed else 5

    ax1.errorbar(
        x_base + offset,
        f1_vals,
        yerr=yerr,
        fmt=cfg["marker"] + cfg["linestyle"],
        color=cfg["color"],
        ecolor=cfg["color"],
        elinewidth=lw,
        capsize=capsize,
        capthick=lw,
        linewidth=lw,
        markersize=markersize,
        label=method_name,
        zorder=zorder,
    )


ax1.axvline(4.5, color="#999999", linestyle=":", linewidth=1.2, alpha=0.8)

ax1.set_xticks(x_base)
ax1.set_xticklabels(x_labels, fontsize=10.5)
ax1.set_xlabel("Evaluation setting and sample scale ($N$)", fontsize=11.5, fontweight="bold")
ax1.set_ylabel("$maF1$", fontsize=11.5, fontweight="bold")
ax1.grid(True, linestyle="--", alpha=0.45)
ax1.legend(
    loc="lower left",
    frameon=True,
    facecolor="#ffffff",
    framealpha=0.92,
    edgecolor="#d9d9d9",
    fontsize=10,
)
ax1.set_ylim([0.60, 1.02])
plt.tight_layout()

ci_pdf_path = os.path.join(save_dir, "Triplet256_MacroF1_CI_Comparison.pdf")
ci_png_path = os.path.join(save_dir, "Triplet256_MacroF1_CI_Comparison.png")
plt.savefig(ci_pdf_path, format="pdf", bbox_inches="tight")
plt.savefig(ci_png_path, dpi=FIG_DPI, bbox_inches="tight")
plt.close(fig1)

# =========================================================================

# =========================================================================
fig2, ax2 = plt.subplots(figsize=(8.0, 4.6))

for method_name, cfg in data.items():
    is_proposed = "TwGrey" in method_name
    lw = 2.2 if is_proposed else 1.5
    markersize = 7.5 if is_proposed else 6.5
    zorder = 10 if is_proposed else 5

    ax2.plot(
        x_base,
        cfg["acc"],
        cfg["marker"] + cfg["linestyle"],
        color=cfg["color"],
        linewidth=lw,
        markersize=markersize,
        label=method_name,
        zorder=zorder,
    )


ax2.axvline(4.5, color="#999999", linestyle=":", linewidth=1.2, alpha=0.8)

ax2.set_xticks(x_base)
ax2.set_xticklabels(x_labels, fontsize=10.5)
ax2.set_xlabel("Evaluation setting and sample scale ($N$)", fontsize=11.5, fontweight="bold")
ax2.set_ylabel("Accuracy", fontsize=11.5, fontweight="bold")
ax2.grid(True, linestyle="--", alpha=0.45)
ax2.legend(
    loc="lower left",
    frameon=True,
    facecolor="#ffffff",
    framealpha=0.92,
    edgecolor="#d9d9d9",
    fontsize=10,
)
ax2.set_ylim([0.62, 1.00])
plt.tight_layout()

acc_pdf_path = os.path.join(save_dir, "Triplet256_Accuracy_Comparison.pdf")
acc_png_path = os.path.join(save_dir, "Triplet256_Accuracy_Comparison.png")
plt.savefig(acc_pdf_path, format="pdf", bbox_inches="tight")
plt.savefig(acc_png_path, dpi=FIG_DPI, bbox_inches="tight")
plt.close(fig2)

print("✅ :")
print(f"1.  (PDF/PNG): {ci_pdf_path}")
print(f"2. Accuracy (PDF/PNG): {acc_pdf_path}")