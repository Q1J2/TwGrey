# -*- coding: utf-8 -*-


import os
import time
import warnings
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
feat_path   = r"/root/autodl-tmp/NWPU_ResNet18_Finetuned/NWPU_resnet18_finetuned_512d_features.npy"
label_path  = r"/root/autodl-tmp/NWPU_ResNet18_Finetuned/NWPU_resnet18_finetuned_labels.npy"
output_dir  = r"/root/autodl-tmp/results_resnet18_finetuned_v11" 
os.makedirs(output_dir, exist_ok=True)

print("📂 ...")
X_full = np.load(feat_path)
y_full = np.load(label_path)
print(f"✅  N = {X_full.shape[0]}, D = {X_full.shape[1]}, C = {len(np.unique(y_full))}")

# =========================================================================

# =========================================================================
TARGET_FEATURES_FIXED = 128
GREEDY_TOL = 0.0
GRA_RHO = 0.4
RELIEF_TOP_K = 128
TWRELIEF_POS_Q = 0.8
TWRELIEF_NEG_Q = 0.2   
# =========================================================================

# =========================================================================
def compute_gra_weights(X_mat, y_vec, feature_names=None, rho=GRA_RHO):
    
    X_mat = np.asarray(X_mat, dtype=np.float64)
    y_vec = np.asarray(y_vec)

    diffs = np.abs(X_mat - y_vec.reshape(-1, 1))
    dmin = diffs.min()
    dmax = diffs.max()

    grd = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        grd[i] = np.mean((dmin + rho * dmax) / (diffs[:, i] + rho * dmax))

    if feature_names is None:
        feature_names = [f"f{i}" for i in range(X_mat.shape[1])]
    return grd, dict(zip(feature_names, grd))


# =========================================================================

# =========================================================================
def shadow_set_objective(alpha, beta, gamma_vals):
    significant = gamma_vals[gamma_vals >= alpha]
    insignificant = gamma_vals[gamma_vals <= beta]
    shadow = gamma_vals[(gamma_vals > beta) & (gamma_vals < alpha)]
    return abs(np.sum(1.0 - significant) + np.sum(insignificant) - len(shadow))


def optimize_thresholds_shadow(gamma_vals, step=0.005):
    
    g = np.asarray(gamma_vals, dtype=np.float64)
    gmin, gmax = g.min(), g.max()
    cand = np.arange(gmin + step, gmax, step)
    if len(cand) < 2:
        return gmin + 0.67 * (gmax - gmin), gmin + 0.33 * (gmax - gmin)
    best_obj, best_a, best_b = float("inf"), 0.0, 0.0
    for i, b in enumerate(cand):
        for a in cand[i + 1:]:
            o = shadow_set_objective(a, b, g)
            if o < best_obj:
                best_obj, best_a, best_b = o, a, b
    return best_a, best_b


def shadow_set_partition(gamma_vals, alpha, beta):
    pos = np.where(gamma_vals >= alpha)[0].tolist()
    neg = np.where(gamma_vals <= beta)[0].tolist()
    shd = np.where((gamma_vals > beta) & (gamma_vals < alpha))[0].tolist()
    return pos, shd, neg


# =========================================================================

# =========================================================================
def select_from_boundary(X_train, y_train, pos_feats, shd_feats,
                         target_features=None, max_iters=None,
                         tol=GREEDY_TOL):
    selected = list(pos_feats)
    if target_features is not None and len(selected) >= target_features:
        return selected[:target_features]
    if len(shd_feats) == 0:
        return selected

    if max_iters is None:
        if target_features is None:
            max_iters = len(shd_feats)
        else:
            max_iters = max(35, target_features - len(selected) + 10)

    proxy_n = min(600, X_train.shape[0])
    X_proxy, _, y_proxy, _ = train_test_split(
        X_train, y_train, train_size=proxy_n, stratify=y_train, random_state=42
    )
    X_fit, X_val, y_fit, y_val = train_test_split(
        X_proxy, y_proxy, test_size=0.3, stratify=y_proxy, random_state=0
    )

    def make_clf():
        return SVC(C=1.0, kernel='rbf', gamma='scale',
                   decision_function_shape='ovr', random_state=42)

    clf = make_clf()
    clf.fit(X_fit[:, selected], y_fit)
    acc0 = accuracy_score(y_val, clf.predict(X_val[:, selected]))

    for it, f in enumerate(shd_feats):
        if it >= max_iters:
            break
        if target_features is not None and len(selected) >= target_features:
            break
        cand = selected + [f]
        clf = make_clf()
        clf.fit(X_fit[:, cand], y_fit)
        acc_cand = accuracy_score(y_val, clf.predict(X_val[:, cand]))
        if acc_cand > acc0 + tol:
            acc0 = acc_cand
            selected.append(f)

    return selected


# =========================================================================

# =========================================================================
def selector_twgrey_adaptive(X_train, y_train, verbose=False):
    
    start_t = time.time()

    y_train_arr = np.asarray(y_train)
    feature_names = [f"f{i}" for i in range(X_train.shape[1])]

    candidate_rhos = np.round(np.arange(0.1, 1.0, 0.1), 1)
    records = []

    for rho in candidate_rhos:
        gamma_tr, f_imp = compute_gra_weights(X_train, y_train_arr, feature_names, rho=rho)
        alpha, beta = optimize_thresholds_shadow(gamma_tr, step=0.005)

        pos = [f for f, s in f_imp.items() if s >= alpha]
        bdr = [f for f, s in f_imp.items() if beta < s < alpha]

        if len(pos) == 0:
            top = max(f_imp, key=f_imp.get)
            pos.append(top)
            if top in bdr:
                bdr.remove(top)

        pos_idx = [int(f[1:]) for f in pos]
        bdr_idx = sorted([int(f[1:]) for f in bdr],
                          key=lambda i: f_imp[f"f{i}"], reverse=True)

        selected_idx = select_from_boundary(
            X_train, y_train_arr, pos_idx, bdr_idx,
            target_features=None, tol=GREEDY_TOL
        )

        records.append({
            "rho": rho, "alpha": alpha, "beta": beta,
            "selected": selected_idx, "n_features": len(selected_idx),
        })

    best = min(records, key=lambda r: (r["n_features"], r["rho"]))
    selected = best["selected"]

    if verbose:
        print(f"    [TwGrey] rho*={best['rho']:.1f}, α={best['alpha']:.4f}, "
              f"β={best['beta']:.4f}, |S|={len(selected)}")

    return selected, time.time() - start_t


# =========================================================================

# =========================================================================
def selector_variance(X, top_k=TARGET_FEATURES_FIXED):
    start_t = time.time()
    var_scores = np.var(X, axis=0)
    feats = np.argsort(var_scores)[::-1][:top_k].tolist()
    return feats, time.time() - start_t


def compute_relieff_weights(X_mat, y_vec, r=100, k=5):
    m, n = X_mat.shape
    classes, class_counts = np.unique(y_vec, return_counts=True)
    p_c = {c: count / m for c, count in zip(classes, class_counts)}

    feat_min = np.min(X_mat, axis=0)
    feat_max = np.max(X_mat, axis=0)
    feat_span = feat_max - feat_min
    feat_span[feat_span == 0] = 1e-8
    X_norm = (X_mat - feat_min) / feat_span

    W = np.zeros(n)
    rng = np.random.RandomState(42)
    class_indices = {c: np.where(y_vec == c)[0] for c in classes}

    for _ in range(r):
        idx_s = rng.randint(0, m)
        s = X_norm[idx_s]
        cls_s = y_vec[idx_s]

        same_idx = class_indices[cls_s]
        same_idx = same_idx[same_idx != idx_s]
        if len(same_idx) == 0:
            continue
        dist_hits = np.sum(np.abs(X_norm[same_idx] - s), axis=1)
        hit_k_idx = same_idx[np.argpartition(dist_hits, min(k, len(dist_hits) - 1))[:k]]
        diff_hits = np.sum(np.abs(X_norm[hit_k_idx] - s), axis=0)

        diff_misses_weighted = np.zeros(n)
        for c in classes:
            if c == cls_s:
                continue
            diff_idx = class_indices[c]
            dist_miss = np.sum(np.abs(X_norm[diff_idx] - s), axis=1)
            miss_k_idx = diff_idx[np.argpartition(dist_miss, min(k, len(dist_miss) - 1))[:k]]
            diff_m_c = np.sum(np.abs(X_norm[miss_k_idx] - s), axis=0)
            diff_misses_weighted += (p_c[c] / (1.0 - p_c[cls_s] + 1e-8)) * diff_m_c

        W = W - (diff_hits / (r * k)) + (diff_misses_weighted / (r * k))

    return W


def selector_relieff_adaptive(X_train, y_train, top_k=RELIEF_TOP_K, r=100, k=5, verbose=False):
    start_t = time.time()
    W = compute_relieff_weights(X_train, y_train, r=r, k=k)

    if verbose:
        print(f"    [ReliefF] W range: [{W.min():.4f}, {W.max():.4f}], "
              f"mean={W.mean():.4f}, top_k={top_k}")

    
    feats = np.argsort(W)[::-1][:top_k].tolist()
    return feats, time.time() - start_t


def selector_relieff_topk(X, y, top_k=TARGET_FEATURES_FIXED, r=100, k=5):
    start_t = time.time()
    weights = compute_relieff_weights(X, y, r=r, k=k)
    feats = np.argsort(weights)[::-1][:top_k].tolist()
    return feats, time.time() - start_t


def selector_twrelieff_adaptive(X_train, y_train,
                                 pos_quantile=TWRELIEF_POS_Q,
                                 neg_quantile=TWRELIEF_NEG_Q,
                                 r=100, k=5, verbose=False):
  
    start_t = time.time()
    W = compute_relieff_weights(X_train, y_train, r=r, k=k)

    alpha = float(np.quantile(W, pos_quantile))
    beta = float(np.quantile(W, neg_quantile))

    if verbose:
        print(f"    [TwReliefF] W range: [{W.min():.4f}, {W.max():.4f}], "
              f"mean={W.mean():.4f}, (α, β)=({alpha:.4f}, {beta:.4f}) [固定分位]")

    pos_feats, shd_feats, neg_feats = shadow_set_partition(W, alpha, beta)

    if verbose:
        print(f"    [TwReliefF] Pos={len(pos_feats)}, Shd={len(shd_feats)}, Neg={len(neg_feats)}")

    shd_feats_sorted = sorted(shd_feats, key=lambda f: W[f], reverse=True)
    selected = select_from_boundary(
        X_train, y_train, pos_feats, shd_feats_sorted,
        target_features=None, tol=GREEDY_TOL
    )

    if verbose:
        print(f"    [TwReliefF] Final |S|={len(selected)}")

    return selected, time.time() - start_t

# =========================================================================

# =========================================================================
def run_full_benchmark_evaluation(n_splits=5):
    print("\n" + "=" * 95)
    print(f"🚀NWPU-RESISC45 ({n_splits}  CV)")
    print(f"   GRA  | Classifier: RBF-SVC")
    print("=" * 95)

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

    adaptive_methods = ["TwGrey (adaptive)", "TwReliefF (adaptive)", "ReliefF (adaptive)"]
    fixed_methods = ["Full Features (512-D)", "Variance (128)", "ReliefF (Top-128)"]

    method_metrics = {m: {"acc": [], "prec": [], "rec": [], "f1": [],
                          "time": [], "feats": []}
                      for m in adaptive_methods + fixed_methods}

    for fold, (train_idx, test_idx) in enumerate(skf.split(X_full, y_full)):
        print(f"\n--- 第 [{fold + 1}/{n_splits}] 折 ---")
        X_tr, y_tr = X_full[train_idx], y_full[train_idx]
        X_te, y_te = X_full[test_idx], y_full[test_idx]

        for m in adaptive_methods + fixed_methods:
            if m == "Full Features (512-D)":
                selected = list(range(X_full.shape[1]))
                t_cost = 0.0
            elif m == "Variance (128)":
                selected, t_cost = selector_variance(X_tr, top_k=TARGET_FEATURES_FIXED)
            elif m == "ReliefF (Top-128)":
                selected, t_cost = selector_relieff_topk(X_tr, y_tr, top_k=TARGET_FEATURES_FIXED, r=100, k=5)
            elif m == "ReliefF (adaptive)":
                selected, t_cost = selector_relieff_adaptive(
                    X_tr, y_tr, top_k=RELIEF_TOP_K, r=100, k=5, verbose=(fold == 0)
                )
            elif m == "TwReliefF (adaptive)":
                selected, t_cost = selector_twrelieff_adaptive(
                    X_tr, y_tr, pos_quantile=TWRELIEF_POS_Q, neg_quantile=TWRELIEF_NEG_Q,
                    r=100, k=5, verbose=(fold == 0)
                )

            elif m == "TwGrey (adaptive)":
                selected, t_cost = selector_twgrey_adaptive(
                    X_tr, y_tr, verbose=(fold == 0)
                )

            clf = SVC(C=1.0, kernel='rbf', gamma='scale',
                      decision_function_shape='ovr', random_state=42)
            clf.fit(X_tr[:, selected], y_tr)
            y_pred = clf.predict(X_te[:, selected])

            method_metrics[m]["acc"].append(accuracy_score(y_te, y_pred) * 100.0)
            method_metrics[m]["prec"].append(precision_score(y_te, y_pred, average='macro') * 100.0)
            method_metrics[m]["rec"].append(recall_score(y_te, y_pred, average='macro') * 100.0)
            method_metrics[m]["f1"].append(f1_score(y_te, y_pred, average='macro') * 100.0)
            method_metrics[m]["time"].append(t_cost)
            method_metrics[m]["feats"].append(len(selected))

            print(f"   [{m}] Acc={method_metrics[m]['acc'][-1]:.2f}%, "
                  f"F1={method_metrics[m]['f1'][-1]:.2f}%, "
                  f"|S|={len(selected)}, Time={t_cost:.2f}s")

    all_methods = adaptive_methods + fixed_methods
    summary_rows = []
    for m in all_methods:
        acc_m, acc_s = np.mean(method_metrics[m]["acc"]), np.std(method_metrics[m]["acc"])
        f1_m, f1_s = np.mean(method_metrics[m]["f1"]), np.std(method_metrics[m]["f1"])
        t_m = np.mean(method_metrics[m]["time"])
        f_len = int(np.round(np.mean(method_metrics[m]["feats"])))

        summary_rows.append({
            "Method": m,
            "Feat.": f_len,
            "Comp.(%)": f"{(1.0 - f_len / 512) * 100.0:.2f}",
            "Acc.(%)": f"{acc_m:.2f} ± {acc_s:.2f}",
            "F1(%)": f"{f1_m:.2f} ± {f1_s:.2f}",
            "Time(s)": f"{t_m:.2f}",
        })

    df_res = pd.DataFrame(summary_rows)
    print("\n" + "=" * 95)
    print(f"📊 :")
    print("=" * 95)
    print(df_res.to_string(index=False))
    out_xlsx = os.path.join(output_dir, "table_adaptive_and_fixed128.xlsx")
    df_res.to_excel(out_xlsx, index=False)
    print(f"\n✅: {out_xlsx}")

# =========================================================================

# =========================================================================
def run_scalability_analysis():
    print("\n" + "=" * 85)
    print("📈  (test TwGrey )...")
    print("=" * 85)

    rng = np.random.RandomState(42)
    perm = rng.permutation(X_full.shape[0])
    X_shuf, y_shuf = X_full[perm], y_full[perm]

    sample_sizes = [2000, 5000, 10000, 18000, 25200]
    time_vs_n = []
    print("  [1/2]  (N in [2,000, 25,200])...")
    for n in sample_sizes:
        sub_X, sub_y = X_shuf[:n, :], y_shuf[:n]
        t_list = []
        for _ in range(3):
            t0 = time.time()
            # ★ V11: compute_gra_weights 返回 (grd, dict)
            gamma, _ = compute_gra_weights(sub_X, sub_y, rho=GRA_RHO)
            # ★ V11: optimize_thresholds_shadow 无 min_bandwidth
            _ = optimize_thresholds_shadow(gamma, step=0.005)
            t_list.append(time.time() - t0)
        cost_t = np.mean(t_list)
        time_vs_n.append(cost_t)
        print(f"       N = {n:<6} | 核心算子耗时: {cost_t:.4f} s")

    dimensions = [64, 128, 256, 384, 512]
    time_vs_d = []
    print("  [2/2]  (D in [64, 512])...")
    sub_X_fixed = X_shuf[:10000, :]
    sub_y_fixed = y_shuf[:10000]
    for d in dimensions:
        sub_X = sub_X_fixed[:, :d]
        t_list = []
        for _ in range(3):
            t0 = time.time()
            gamma, _ = compute_gra_weights(sub_X, sub_y_fixed, rho=GRA_RHO)
            _ = optimize_thresholds_shadow(gamma, step=0.005)
            t_list.append(time.time() - t0)
        cost_t = np.mean(t_list)
        time_vs_d.append(cost_t)
        print(f"       D = {d:<6} | 核心算子耗时: {cost_t:.4f} s")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.5, 4.2))

    ax1.plot(sample_sizes, time_vs_n, marker='o', color='#1f77b4',
             linewidth=2.0, markersize=7, label='TwGrey runtime')
    z1 = np.polyfit(sample_sizes, time_vs_n, 1)
    p1 = np.poly1d(z1)
    ax1.plot(sample_sizes, p1(sample_sizes), linestyle='--', color='#d62728',
             alpha=0.8, label=r'Linear fit: $\mathcal{O}(N)$')
    ax1.set_xlabel('Sample size ($N$)', fontsize=11, fontweight='bold')
    ax1.set_ylabel('Execution time (Seconds)', fontsize=11, fontweight='bold')
    ax1.grid(True, linestyle='--', alpha=0.4)
    ax1.set_ylim(bottom=0)
    ax1.legend(loc='upper left', frameon=True)

    ax2.plot(dimensions, time_vs_d, marker='s', color='#2ca02c',
             linewidth=2.0, markersize=7, label='TwGrey runtime')
    z2 = np.polyfit(dimensions, time_vs_d, 1)
    p2 = np.poly1d(z2)
    ax2.plot(dimensions, p2(dimensions), linestyle='--', color='#d62728',
             alpha=0.8, label=r'Linear fit: $\mathcal{O}(D)$')
    ax2.set_xlabel('Feature dimensionality ($D$)', fontsize=11, fontweight='bold')
    ax2.set_ylabel('Execution time (Seconds)', fontsize=11, fontweight='bold')
    ax2.grid(True, linestyle='--', alpha=0.4)
    ax2.set_ylim(bottom=0)
    ax2.legend(loc='upper left', frameon=True)

    plt.tight_layout()
    out_png = os.path.join(output_dir, "image_scalability_analysis5.png")
    out_pdf = os.path.join(output_dir, "image_scalability_analysis5.pdf")
    plt.savefig(out_png, dpi=FIG_DPI, bbox_inches='tight')
    plt.savefig(out_pdf, format='pdf', bbox_inches='tight')
    print(f"\n✅ : {os.path.abspath(out_png)}")
    plt.close()


# =========================================================================
# =========================================================================
def compute_kuncheva_index(s1, s2, total_dim=512):
    s1_set, s2_set = set(s1), set(s2)
    intersection = len(s1_set & s2_set)
    k1, k2 = len(s1_set), len(s2_set)
    denom = total_dim * min(k1, k2) - k1 * k2
    if denom == 0:
        return 1.0
    return (intersection * total_dim - k1 * k2) / denom


def compute_jaccard_similarity(s1, s2):
    s1_set, s2_set = set(s1), set(s2)
    return len(s1_set & s2_set) / len(s1_set | s2_set)


def run_bootstrap_stability_evaluation(B=20):
    print("\n" + "=" * 85)
    print(f"🔬  (B = {B} 次 Bootstrap )")
    print("=" * 85)

    rng = np.random.RandomState(42)
    n_total = X_full.shape[0]

    pool_idx = rng.choice(n_total, 20000, replace=False)
    X_pool = X_full[pool_idx]
    y_pool = y_full[pool_idx]

    methods = {
        "Variance Threshold": lambda X, y: selector_variance(X, top_k=TARGET_FEATURES_FIXED)[0],
        "ReliefF (Top-128)": lambda X, y: selector_relieff_topk(
            X, y, top_k=TARGET_FEATURES_FIXED, r=100, k=5
        )[0],
        "TwReliefF (adaptive)": lambda X, y: selector_twrelieff_adaptive(
            X, y, pos_quantile=TWRELIEF_POS_Q, neg_quantile=TWRELIEF_NEG_Q,
            r=100, k=5
        )[0],
        "TwGrey (adaptive)": lambda X, y: selector_twgrey_adaptive(X, y)[0],
    }

    subsets_record = {m: [] for m in methods}

    for b in range(B):
        boot_idx = rng.choice(X_pool.shape[0], X_pool.shape[0], replace=True)
        X_b, y_b = X_pool[boot_idx], y_pool[boot_idx]

        for m_name, selector in methods.items():
            sel = selector(X_b, y_b)
            subsets_record[m_name].append(sel)

        if (b + 1) % 5 == 0 or b == B - 1:
            print(f"    [{b + 1}/{B}] 次 Bootstrap ...")

    stability_results = []
    for m_name, subsets in subsets_record.items():
        jaccards = []
        kunchevas = []
        lens = [len(s) for s in subsets]

        for i in range(B - 1):
            for j in range(i + 1, B):
                jaccards.append(compute_jaccard_similarity(subsets[i], subsets[j]))
                kunchevas.append(
                    compute_kuncheva_index(subsets[i], subsets[j], total_dim=X_full.shape[1])
                )

        stability_results.append({
            "Method": m_name,
            "Jaccard ($J_{stab}$)": f"{np.mean(jaccards):.3f} ± {np.std(jaccards):.3f}",
            "Kuncheva ($K_{stab}$)": f"{np.mean(kunchevas):.3f} ± {np.std(kunchevas):.3f}",
            "Subset Size (|S|)": f"{np.mean(lens):.1f} ± {np.std(lens):.1f}",
        })

    df_stab = pd.DataFrame(stability_results)
    print("\n" + "=" * 85)
    print(f"📊 Table:  (B={B} Bootstrap)")
    print("=" * 85)
    print(df_stab.to_string(index=False))
    out_xlsx = os.path.join(output_dir, "table_bootstrap_stability.xlsx")
    df_stab.to_excel(out_xlsx, index=False)
    print(f"\n✅ : {out_xlsx}")

if __name__ == "__main__":
    
    # run_full_benchmark_evaluation(n_splits=5)

    #  B：
    run_scalability_analysis()

    #  C：
    run_bootstrap_stability_evaluation(B=20)