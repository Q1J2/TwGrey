import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import (
    accuracy_score,
    auc,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.svm import SVC

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}

export_dir = r"D:\e\NWPU\Experiment_Plots_GRA_Shadow"
os.makedirs(export_dir, exist_ok=True)


# =========================================================================

# =========================================================================
def compute_gra_weights(X_mat, y_vec, feature_names, rho):
    X_mat = np.asarray(X_mat, dtype=np.float64)
    y_vec = np.asarray(y_vec)
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()

    grey_relation_degrees = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        grey_relation_degrees[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )

    return grey_relation_degrees, dict(zip(feature_names, grey_relation_degrees))


# =========================================================================

# =========================================================================
def shadow_set_objective(alpha, beta, gamma_vals):
    significant = gamma_vals[gamma_vals >= alpha]
    insignificant = gamma_vals[gamma_vals <= beta]
    shadow = gamma_vals[(gamma_vals > beta) & (gamma_vals < alpha)]

    v1 = np.sum(1.0 - significant)
    v2 = np.sum(insignificant)
    v3 = len(shadow)

    return abs(v1 + v2 - v3)


def optimize_thresholds(gamma_vals, step=0.005):
    gamma_vals = np.asarray(gamma_vals, dtype=np.float64)
    min_objective = float("inf")
    best_alpha, best_beta = 0.0, 0.0

    gamma_min = np.min(gamma_vals)
    gamma_max = np.max(gamma_vals)

    thresholds = np.arange(gamma_min + step, gamma_max, step)

    if len(thresholds) < 2:
        return gamma_min + 0.67 * (gamma_max - gamma_min), gamma_min + 0.33 * (gamma_max - gamma_min)

    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1 :]:
            obj = shadow_set_objective(alpha_cand, beta_cand, gamma_vals)
            if obj < min_objective:
                min_objective = obj
                best_alpha = alpha_cand
                best_beta = beta_cand

    return best_alpha, best_beta


# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )


def evaluate_model(model, x_curr, y_true):
    y_pred = model.predict(x_curr)
    acc = accuracy_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred, average="macro", zero_division=0)
    precision = precision_score(y_true, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    return acc, precision, recall, f1


def compute_maf1_confidence_interval(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes)
    n = len(y_true)

    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)

    p_hat = cm / n
    p_row = np.sum(p_hat, axis=1)
    p_col = np.sum(p_hat, axis=0)
    p_diag = np.diag(p_hat)

    denom = p_row + p_col
    valid_mask = denom > 0

    F1_i = np.zeros(r)
    F1_i[valid_mask] = 2.0 * p_diag[valid_mask] / denom[valid_mask]
    maF1 = np.mean(F1_i)

    diff_p = denom - 2.0 * p_diag

    A_terms = np.zeros(r)
    for i in range(r):
        if denom[i] > 0:
            term1 = (F1_i[i] * diff_p[i]) / (denom[i] ** 2)
            term2 = (diff_p[i] / denom[i]) + (F1_i[i] / 2.0)
            A_terms[i] = term1 * term2
    A = np.sum(A_terms)

    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p_hat[i, j] * F1_i[i] * F1_i[j]) / (denom[i] * denom[j])

    var_maF1 = (2.0 / (n * (r ** 2))) * (A + B)
    se_maF1 = np.sqrt(max(0.0, var_maF1))

    z = norm.ppf(1.0 - alpha / 2.0)
    ci_lower = max(0.0, maF1 - z * se_maF1)
    ci_upper = min(1.0, maF1 + z * se_maF1)

    return maF1, se_maF1, (ci_lower, ci_upper)


# =========================================================================

# =========================================================================
benchmark_summary = []
roc_plot_data = {}
candidate_rhos = np.round(np.arange(0.1, 1.0, 0.1), 1)

for n_samples, path in data_paths.items():
    print("\n" + "=" * 80)
    print(f"🚀 : N = {n_samples} | : {path}")
    print("=" * 80)

    df = pd.read_excel(path)
    feature_names = df.columns[:-1].tolist()
    X_raw = df.iloc[:, :-1]
    y_raw = df.iloc[:, -1]


    X_train, X_val, y_train, y_val = train_test_split(
        X_raw, y_raw, test_size=0.30, random_state=42, stratify=y_raw
    )
    print(f"📊 :  = {len(y_train)},  = {len(y_val)}")

    
    scale_sensitivity_records = []

    for rho in candidate_rhos:
        # A)
        gamma_tr, f_imp_tr = compute_gra_weights(X_train.values, y_train.values, feature_names, rho=rho)
        alpha, beta = optimize_thresholds(gamma_tr, step=0.005)

        # B) 
        pos_region = [f for f, s in f_imp_tr.items() if s >= alpha]
        bdr_region = [f for f, s in f_imp_tr.items() if beta < s < alpha]

        if len(pos_region) == 0:
            top_f = max(f_imp_tr, key=f_imp_tr.get)
            pos_region.append(top_f)
            if top_f in bdr_region:
                bdr_region.remove(top_f)

        # C) 
        X_tr_pos = X_train[pos_region].copy()
        svm_temp = create_svm()
        svm_temp.fit(X_tr_pos, y_train)
        acc0, _, _, _ = evaluate_model(svm_temp, X_tr_pos, y_train)

        for feature in sorted(bdr_region, key=f_imp_tr.get, reverse=True):
            X_tr_pos[feature] = X_train[feature]
            cand_svm = create_svm()
            cand_svm.fit(X_tr_pos, y_train)
            acc_cand, _, _, _ = evaluate_model(cand_svm, X_tr_pos, y_train)

            if acc_cand > acc0:
                acc0 = acc_cand
                pos_region.append(feature)
            else:
                X_tr_pos.drop(columns=[feature], inplace=True)

        # D) 
        final_svm_cand = create_svm()
        final_svm_cand.fit(X_train[pos_region], y_train)
        val_acc, val_prec, val_rec, val_f1 = evaluate_model(final_svm_cand, X_val[pos_region], y_val)

        scale_sensitivity_records.append({
            "rho": rho,
            "alpha": alpha,
            "beta": beta,
            "pos_region": pos_region,
            "model": final_svm_cand,
            "Accuracy": val_acc,
            "maP": val_prec,
            "maR": val_rec,
            "Macro_F1": val_f1,
            "Features": len(pos_region)
        })

    
    sens_df = pd.DataFrame(scale_sensitivity_records)
    best_idx = sens_df.sort_values(
        by=["Macro_F1", "Accuracy", "Features"], ascending=[False, False, True]
    ).index[0]

    best_record = scale_sensitivity_records[best_idx]
    best_rho = best_record["rho"]
    alpha_best = best_record["alpha"]
    beta_best = best_record["beta"]
    selected_features = best_record["pos_region"]
    final_svm = best_record["model"]

    val_acc = best_record["Accuracy"]
    val_prec = best_record["maP"]
    val_rec = best_record["maR"]
    val_f1 = best_record["Macro_F1"]

    
    X_val_sub = X_val[selected_features]
    y_pred_val = final_svm.predict(X_val_sub)
    y_proba_val = final_svm.predict_proba(X_val_sub)

    y_val_bin = label_binarize(y_val, classes=final_svm.classes_)
    n_classes = len(final_svm.classes_)
    all_fpr = np.unique(np.concatenate([roc_curve(y_val_bin[:, i], y_proba_val[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_val_bin[:, i], y_proba_val[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

    maf1_val, se_val, (ci_low, ci_high) = compute_maf1_confidence_interval(y_val.values, y_pred_val, alpha=0.05)

   
    if n_samples == 160:
        export_dir_cmp = r"D:\e\NWPU\Experiment_Plots_Comparison"
        os.makedirs(export_dir_cmp, exist_ok=True)
        np.savez(
            os.path.join(export_dir_cmp, "roc_data_160_TwGrey.npz"),
            y_true=y_val.values,
            y_proba=y_proba_val,
            classes=final_svm.classes_,
        )
        

    roc_plot_data[n_samples] = {
        'y_true': y_val.values,
        'y_proba': y_proba_val,
        'classes': final_svm.classes_
    }

    print(f"🎯 : rho* = {best_rho:.1f} |  (alpha, beta) = ({alpha_best:.4f}, {beta_best:.4f})")
    print(f"🏆 : Features={len(selected_features)} | Acc={val_acc*100:.2f}% | Macro-F1={val_f1*100:.2f}% (SE={se_val:.4f}) | Macro-AUC={macro_auc:.4f}")
    print(f"🔒  Macro-F1 95% : [{ci_low*100:.2f}%, {ci_high*100:.2f}%]")

    benchmark_summary.append({
        "Sample Size (N)": n_samples,
        "rho": f"{best_rho:.1f}",
        "Threshold (alpha, beta)": f"({alpha_best:.4f}, {beta_best:.4f})",
        "Penalty C": 1.0,
        "Selected Features": len(selected_features),
        "Accuracy (%)": f"{val_acc * 100:.2f}",
        "Macro Precision (%)": f"{val_prec * 100:.2f}",
        "Macro Recall (%)": f"{val_rec * 100:.2f}",
        "Macro F1 (%)": f"{val_f1 * 100:.2f}",
        "Macro F1 (95% CI)": f"{val_f1 * 100:.2f} [{ci_low * 100:.2f}, {ci_high * 100:.2f}]",
        "Macro-AUC": f"{macro_auc:.4f}",
        "raw_f1": val_f1 * 100,
        "raw_ci_low": ci_low * 100,
        "raw_ci_high": ci_high * 100,
        "raw_se": se_val * 100
    })


# =========================================================================

# =========================================================================
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']


fig_ci, ax_ci = plt.subplots(figsize=(6.5, 4.2))
scales = [row["Sample Size (N)"] for row in benchmark_summary]
f1_vals = [row["raw_f1"] for row in benchmark_summary]
yerr_low = [row["raw_f1"] - row["raw_ci_low"] for row in benchmark_summary]
yerr_high = [row["raw_ci_high"] - row["raw_f1"] for row in benchmark_summary]

ax_ci.errorbar(
    range(len(scales)), f1_vals, yerr=[yerr_low, yerr_high],
    fmt='-o', color='#2ca02c', ecolor='#d62728', elinewidth=2, capsize=5, capthick=1.5,
    markersize=6, label='Macro-F1 with 95% CI (Independent Test Set)'
)
ax_ci.set_xticks(range(len(scales)))
ax_ci.set_xticklabels([f"N={s}" for s in scales])
ax_ci.set_xlabel('Sample scale (N)', fontsize=12)
ax_ci.set_ylabel('Macro-F1 score (%)', fontsize=12)
ax_ci.grid(True, linestyle='--', alpha=0.5)
ax_ci.legend(loc='lower right')
plt.tight_layout()

ci_plot_pdf = os.path.join(export_dir, "GRA_Shadow_MacroF1_Confidence_Interval.pdf")
ci_plot_png = os.path.join(export_dir, "GRA_Shadow_MacroF1_Confidence_Interval.png")
plt.savefig(ci_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(ci_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig_roc, ax_roc = plt.subplots(figsize=(6.5, 5))
for idx, (n_samples, data) in enumerate(roc_plot_data.items()):
    y_true_bin = label_binarize(data['y_true'], classes=data['classes'])
    y_proba = data['y_proba']
    n_classes = len(data['classes'])

    all_fpr = np.unique(np.concatenate([roc_curve(y_true_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_true_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

    ax_roc.plot(all_fpr, mean_tpr, color=colors[idx % len(colors)], lw=2,
                label=f'N = {n_samples} (Macro-AUC = {macro_auc:.4f})')

ax_roc.plot([0, 1], [0, 1], 'k--', lw=1.2, label='Random Chance')
ax_roc.set_xlim([0.0, 1.0])
ax_roc.set_ylim([0.0, 1.05])
ax_roc.set_xlabel('False positive rate', fontsize=12)
ax_roc.set_ylabel('True positive rate', fontsize=12)
ax_roc.legend(loc='lower right', fontsize=10)
ax_roc.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()

roc_plot_pdf = os.path.join(export_dir, "GRA_Shadow_ROC_Curves.pdf")
roc_plot_png = os.path.join(export_dir, "GRA_Shadow_ROC_Curves.png")
plt.savefig(roc_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(roc_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


# =========================================================================
df_summary = pd.DataFrame(benchmark_summary)
print("\n" + "=" * 120)

print("=" * 120)
print(df_summary[["Sample Size (N)", "rho", "Threshold (alpha, beta)", "Selected Features", "Accuracy (%)", "Macro Precision (%)", "Macro Recall (%)", "Macro F1 (95% CI)", "Macro-AUC"]].to_string(index=False))


print(r"\begin{table}[htbp]")
print(r"  \centering")
print(r"  \small")
print(r"  \caption{Performance of the proposed GRA-Shadow three-way feature selection framework across different sample scales on independent test partition ($70\%/30\%$ split) on NWPU-RESISC45}")
print(r"  \label{tab:gra_shadow_scale_results}")
print(r"  \begin{tabular}{cccccccc}")
print(r"    \toprule")
print(r"    \textbf{Sample Size ($N$)} & $\rho^*$ & \textbf{Thresholds $(\alpha, \beta)$} & \textbf{\# Features} & \textbf{Accuracy (\%)} & \textbf{Precision (\%)} & \textbf{Recall (\%)} & \textbf{Macro F1 (95\% CI) (\%)} \\")
print(r"    \midrule")
for row in benchmark_summary:
    print(f"    {row['Sample Size (N)']} & {row['rho']} & {row['Threshold (alpha, beta)']} & {row['Selected Features']} & {row['Accuracy (%)']} & {row['Macro Precision (%)']} & {row['Macro Recall (%)']} & {row['Macro F1 (95% CI)']} \\\\")
print(r"    \bottomrule")
print(r"  \end{tabular}")
print(r"  \vspace{1.0ex}")
print(r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont \textit{Note:} For each sample scale, the optimal distinguishing coefficient $\rho^*$ is determined via parameter sensitivity analysis on the $70\%$ training partition. All reported metrics, 95\% confidence intervals, and Macro-AUC values are evaluated on mutually exclusive $30\%$ test sets using RBF-kernel SVM.}")
print(r"\end{table}")