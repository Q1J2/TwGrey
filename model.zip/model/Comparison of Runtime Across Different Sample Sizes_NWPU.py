# -*- coding: utf-8 -*-


import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
import gc
import time
import platform
import threading
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import psutil
import sklearn
from sklearn.metrics import accuracy_score, r2_score
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.feature_selection import SelectKBest, chi2, mutual_info_classif
from sklearn.preprocessing import MinMaxScaler

warnings.filterwarnings("ignore")

# =========================================================================
# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}

output_dir = r"D:\e\Feature\Feature (2)"
os.makedirs(output_dir, exist_ok=True)


RHO_STAR = {
    160:  0.4,
    400:  0.8,
    800:  0.1,
    2800: 0.4,
}


TWRELIEF_FIXED_ALPHA = 0.0900
TWRELIEF_FIXED_BETA  = 0.0300

N_REPEATS_BREAKDOWN   = 10
N_REPEATS_RUNTIME     = 30
N_REPEATS_SCALABILITY = 200


# =========================================================================

# =========================================================================
def compute_gra_weights(X_mat, y_vec, feature_names, rho):
    X_mat = np.asarray(X_mat, dtype=np.float64)
    y_vec = np.asarray(y_vec)
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()
    grey_relation_degrees = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        grey_relation_degrees[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )
    return grey_relation_degrees, dict(zip(feature_names, grey_relation_degrees))


def shadow_set_objective(alpha, beta, gamma_vals):
    significant = gamma_vals[gamma_vals >= alpha]
    insignificant = gamma_vals[gamma_vals <= beta]
    shadow = gamma_vals[(gamma_vals > beta) & (gamma_vals < alpha)]
    v1 = np.sum(1.0 - significant)
    v2 = np.sum(insignificant)
    v3 = len(shadow)
    return abs(v1 + v2 - v3)


def optimize_thresholds(gamma_vals, step=0.005):
    gamma_vals = np.asarray(gamma_vals, dtype=np.float64)
    min_objective = float("inf")
    best_alpha, best_beta = 0.0, 0.0
    gamma_min = np.min(gamma_vals)
    gamma_max = np.max(gamma_vals)
    thresholds = np.arange(gamma_min + step, gamma_max, step)
    if len(thresholds) < 2:
        return (gamma_min + 0.67 * (gamma_max - gamma_min),
                gamma_min + 0.33 * (gamma_max - gamma_min))
    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1:]:
            obj = shadow_set_objective(alpha_cand, beta_cand, gamma_vals)
            if obj < min_objective:
                min_objective = obj
                best_alpha = alpha_cand
                best_beta = beta_cand
    return best_alpha, best_beta


def create_svm():
    
    return SVC(C=1.0, kernel='rbf', gamma='scale',
               decision_function_shape='ovr', probability=True, random_state=42)


def twgrey_single_rho_with_timing(X_train, y_train, rho, feature_names):
    
    t_start = time.perf_counter()

    # Stage 1: GRA
    t0 = time.perf_counter()
    gamma_tr, f_imp_tr = compute_gra_weights(
        X_train.values, y_train.values, feature_names, rho=rho
    )
    t_gra = time.perf_counter() - t0

    # Stage 2
    t0 = time.perf_counter()
    alpha, beta = optimize_thresholds(gamma_tr, step=0.005)
    t_thresh = time.perf_counter() - t0

    # Stage 3
    t0 = time.perf_counter()
    pos_region = [f for f, s in f_imp_tr.items() if s >= alpha]
    bdr_region = [f for f, s in f_imp_tr.items() if beta < s < alpha]
    if len(pos_region) == 0:
        top_f = max(f_imp_tr, key=f_imp_tr.get)
        pos_region.append(top_f)
        if top_f in bdr_region:
            bdr_region.remove(top_f)
    t_part = time.perf_counter() - t0

    
    print(f"    |POS|={len(pos_region)}, |BND|={len(bdr_region)}")

    # Stage 4
    t0 = time.perf_counter()
    X_tr_pos = X_train[pos_region].copy()
    svm_temp = create_svm()
    svm_temp.fit(X_tr_pos, y_train)
    acc0 = accuracy_score(y_train, svm_temp.predict(X_tr_pos))

    for feature in sorted(bdr_region, key=f_imp_tr.get, reverse=True):
        X_tr_pos[feature] = X_train[feature]
        cand_svm = create_svm()
        cand_svm.fit(X_tr_pos, y_train)
        acc_cand = accuracy_score(y_train, cand_svm.predict(X_tr_pos))
        if acc_cand > acc0:
            acc0 = acc_cand
            pos_region.append(feature)
        else:
            X_tr_pos.drop(columns=[feature], inplace=True)
    t_refine = time.perf_counter() - t0

    total = time.perf_counter() - t_start

    return pos_region, {
        "Stage 1 (GRA)": t_gra,
        "Stage 2 (Threshold)": t_thresh,
        "Stage 3 (Partition)": t_part,
        "Stage 4 (Refinement)": t_refine,
        "Total": total,
    }


# =========================================================================

# =========================================================================
def compute_relieff_weights(X_mat, y_vec, feature_names, r=100, k=5):
    
    m, n = X_mat.shape
    classes, class_counts = np.unique(y_vec, return_counts=True)
    p_c = {c: count / m for c, count in zip(classes, class_counts)}

    feat_min = np.min(X_mat, axis=0)
    feat_max = np.max(X_mat, axis=0)
    feat_span = feat_max - feat_min
    feat_span[feat_span == 0] = 1e-8

    W = np.zeros(n)
    np.random.seed(42)
    actual_r = min(r, m)

    for _ in range(actual_r):
        idx_s = np.random.randint(0, m)
        s = X_mat[idx_s]
        cls_s = y_vec[idx_s]

        norm_diff = np.abs(X_mat - s) / feat_span
        dist_all = np.sum(norm_diff, axis=1)

        # 1. k-Near Hits
        same_class_indices = np.where(y_vec == cls_s)[0]
        same_class_indices = same_class_indices[same_class_indices != idx_s]
        k_hit = min(k, len(same_class_indices))
        if k_hit > 0:
            hit_k_indices = same_class_indices[np.argsort(dist_all[same_class_indices])[:k_hit]]
            diff_hits = np.sum(np.abs(X_mat[hit_k_indices] - s) / feat_span, axis=0)
        else:
            diff_hits = np.zeros(n)

        # 2. k-Near Misses
        diff_misses_weighted = np.zeros(n)
        for c in classes:
            if c == cls_s:
                continue
            diff_class_indices = np.where(y_vec == c)[0]
            k_miss = min(k, len(diff_class_indices))
            if k_miss == 0:
                continue
            miss_k_indices = diff_class_indices[np.argsort(dist_all[diff_class_indices])[:k_miss]]
            diff_m_c = np.sum(np.abs(X_mat[miss_k_indices] - s) / feat_span, axis=0)
            diff_misses_weighted += (p_c[c] / (1.0 - p_c[cls_s])) * (diff_m_c / k_miss)

        W = W - (diff_hits / (actual_r * max(1, k_hit))) + (diff_misses_weighted / actual_r)

    return dict(zip(feature_names, W))


def twrelieff_with_timing(X_train, y_train, feature_names):
    
    t0 = time.perf_counter()

    w_dict = compute_relieff_weights(X_train.values, y_train.values, feature_names, r=100, k=5)

    alpha = TWRELIEF_FIXED_ALPHA
    beta  = TWRELIEF_FIXED_BETA

    pos_region = [f for f, w in w_dict.items() if w >= alpha]
    bdr_region = [f for f, w in w_dict.items() if beta < w < alpha]

    if len(pos_region) == 0:
        top_f = max(w_dict, key=w_dict.get)
        pos_region.append(top_f)
        if top_f in bdr_region:
            bdr_region.remove(top_f)

    X_tr_pos = X_train[pos_region].copy()
    svm = create_svm()
    svm.fit(X_tr_pos, y_train)
    acc0 = accuracy_score(y_train, svm.predict(X_tr_pos))

    for feature in sorted(bdr_region, key=w_dict.get, reverse=True):
        X_tr_pos[feature] = X_train[feature]
        temp_svm = create_svm()
        temp_svm.fit(X_tr_pos, y_train)
        acc_cand = accuracy_score(y_train, temp_svm.predict(X_tr_pos))
        if acc_cand > acc0:
            acc0 = acc_cand
            pos_region.append(feature)
        else:
            X_tr_pos.drop(columns=[feature], inplace=True)

    t_total = time.perf_counter() - t0
    return pos_region, t_total


# =========================================================================

# =========================================================================
def measure_peak_memory(func, *args, **kwargs):
    process = psutil.Process(os.getpid())
    gc.collect()
    mem_before = process.memory_info().rss
    peak = {"value": mem_before}
    stop_flag = {"stop": False}

    def sampler():
        while not stop_flag["stop"]:
            cur = process.memory_info().rss
            if cur > peak["value"]:
                peak["value"] = cur
            time.sleep(0.001)

    t = threading.Thread(target=sampler, daemon=True)
    t.start()
    result = func(*args, **kwargs)
    stop_flag["stop"] = True
    t.join()
    gc.collect()
    return result, (peak["value"] - mem_before) / (1024 * 1024)


# =========================================================================

# =========================================================================
def run_stage_breakdown():
    print("\n" + "=" * 115)
    print(f"         RHO_STAR = {RHO_STAR}")
    print("=" * 115)

    records = []

    for n_samples, path in data_paths.items():
        df = pd.read_excel(path)
        feature_names = df.columns[:-1].tolist()
        X_raw = df.iloc[:, :-1]
        y_raw = df.iloc[:, -1]
        rho_star = RHO_STAR[n_samples]

        X_train, _, y_train, _ = train_test_split(
            X_raw, y_raw, test_size=0.30, random_state=42, stratify=y_raw
        )

        _ = twgrey_single_rho_with_timing(X_train, y_train, rho_star, feature_names)

        runs = []
        peak_mems = []
        k_selected = None
        for _ in range(N_REPEATS_BREAKDOWN):
            (result, mem_mb) = measure_peak_memory(
                twgrey_single_rho_with_timing,
                X_train, y_train, rho_star, feature_names
            )
            features, timing = result
            runs.append(timing)
            peak_mems.append(mem_mb)
            k_selected = len(features)

        avg_gra    = np.mean([r["Stage 1 (GRA)"]        for r in runs])
        avg_thresh = np.mean([r["Stage 2 (Threshold)"]  for r in runs])
        avg_part   = np.mean([r["Stage 3 (Partition)"]  for r in runs])
        avg_refine = np.mean([r["Stage 4 (Refinement)"] for r in runs])
        std_refine = np.std ([r["Stage 4 (Refinement)"] for r in runs])
        avg_total  = np.mean([r["Total"]                for r in runs])
        std_total  = np.std ([r["Total"]                for r in runs])

        records.append({
            "N": n_samples,
            "rho*": rho_star,
            "k": k_selected,
            "Stage 1 (GRA)": f"{avg_gra:.4f}s",
            "Stage 2 (Threshold)": f"{avg_thresh:.4f}s",
            "Stage 3 (Partition)": f"{avg_part:.4f}s",
            "Stage 4 (Refinement)": f"{avg_refine:.4f}s (±{std_refine:.4f})",
            "Total Time": f"{avg_total:.4f}s (±{std_total:.4f})",
            "Peak RSS": f"{np.max(peak_mems):.2f} MB",
        })

    df_out = pd.DataFrame(records)
    print(df_out.to_string(index=False))
    df_out.to_excel(os.path.join(output_dir, "table_stage_breakdown.xlsx"), index=False)


# =========================================================================

# =========================================================================
def run_runtime_comparison():
    print("\n" + "=" * 165)
    print("[实验 2] 运行时间与加速比对比 (严格下游测试集推断口径: Fit on Train + Predict on Test)")
    print("         口径 1: 特征选择独立耗时 (Selection Time, s)")
    print("         口径 2: 端到端部署总耗时 (End-to-End Latency, s = Selection + Downstream Fit & Predict)")
    print("=" * 165)

    records = []

    for n_samples, path in data_paths.items():
        df = pd.read_excel(path)
        feature_names = df.columns[:-1].tolist()
        X_raw = df.iloc[:, :-1]
        y_raw = df.iloc[:, -1]
        D = X_raw.shape[1]
        rho_star = RHO_STAR[n_samples]

        X_train, X_val, y_train, y_val = train_test_split(
            X_raw, y_raw, test_size=0.30, random_state=42, stratify=y_raw
        )

        twgrey_feats, _ = twgrey_single_rho_with_timing(X_train, y_train, rho_star, feature_names)
        k = len(twgrey_feats)

        def downstream_svm_pipeline(X_tr_sub, y_tr, X_val_sub):
            clf = create_svm()
            clf.fit(X_tr_sub, y_tr)
            _ = clf.predict(X_val_sub)

        
        _ = twgrey_single_rho_with_timing(X_train, y_train, rho_star, feature_names)
        _ = twrelieff_with_timing(X_train, y_train, feature_names)
        _ = create_svm().fit(X_train.values, y_train.values)
        _X_pos = MinMaxScaler().fit_transform(X_train.values)
        _ = SelectKBest(chi2, k=k).fit(_X_pos, y_train)
        _ = mutual_info_classif(X_train.values, y_train, random_state=42)
        _ = compute_relieff_weights(X_train.values, y_train.values, feature_names, r=100, k=5)

        
        # (a) Chi2
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            X_pos = MinMaxScaler().fit_transform(X_train.values)
            _ = SelectKBest(chi2, k=k).fit(X_pos, y_train)
            t_list.append(time.perf_counter() - t0)
        t_chi2_sel = float(np.mean(t_list))

        # (b) MI
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            _ = mutual_info_classif(X_train.values, y_train, random_state=42)
            t_list.append(time.perf_counter() - t0)
        t_mi_sel = float(np.mean(t_list))

        # (c) ReliefF
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            _ = compute_relieff_weights(X_train.values, y_train.values, feature_names, r=100, k=5)
            t_list.append(time.perf_counter() - t0)
        t_relieff_sel = float(np.mean(t_list))

        # (d) TwReliefF
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            _ = twrelieff_with_timing(X_train, y_train, feature_names)
            t_list.append(time.perf_counter() - t0)
        t_twrelieff_sel = float(np.mean(t_list))

        # (e) TwGrey (Ours)
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            _ = twgrey_single_rho_with_timing(X_train, y_train, rho_star, feature_names)
            t_list.append(time.perf_counter() - t0)
        t_twgrey_sel = float(np.mean(t_list))
        std_twgrey_sel = float(np.std(t_list))

        
        # (a) Full-SVM
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            downstream_svm_pipeline(X_train.values, y_train.values, X_val.values)
            t_list.append(time.perf_counter() - t0)
        t_full_svm = float(np.mean(t_list))

        # (b) Chi2 + SVM
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            scaler = MinMaxScaler()
            X_tr_scaled = scaler.fit_transform(X_train.values)
            X_val_scaled = scaler.transform(X_val.values)
            sel = SelectKBest(chi2, k=k).fit(X_tr_scaled, y_train)
            downstream_svm_pipeline(sel.transform(X_tr_scaled), y_train.values, sel.transform(X_val_scaled))
            t_list.append(time.perf_counter() - t0)
        t_chi2_e2e = float(np.mean(t_list))

        # (c) MI + SVM
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            mi = mutual_info_classif(X_train.values, y_train, random_state=42)
            idx = np.argsort(mi)[::-1][:k]
            downstream_svm_pipeline(X_train.values[:, idx], y_train.values, X_val.values[:, idx])
            t_list.append(time.perf_counter() - t0)
        t_mi_e2e = float(np.mean(t_list))

        # (d) TwReliefF + SVM
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            feats, _ = twrelieff_with_timing(X_train, y_train, feature_names)
            downstream_svm_pipeline(X_train[feats].values, y_train.values, X_val[feats].values)
            t_list.append(time.perf_counter() - t0)
        t_twrelieff_e2e = float(np.mean(t_list))

        # (e) TwGrey + SVM (Ours)
        t_list = []
        for _ in range(N_REPEATS_RUNTIME):
            t0 = time.perf_counter()
            feats, _ = twgrey_single_rho_with_timing(X_train, y_train, rho_star, feature_names)
            downstream_svm_pipeline(X_train[feats].values, y_train.values, X_val[feats].values)
            t_list.append(time.perf_counter() - t0)
        t_twgrey_e2e = float(np.mean(t_list))
        std_twgrey_e2e = float(np.std(t_list))

        spd_sel_vs_twrelieff = round(t_twrelieff_sel / t_twgrey_sel, 2)
        spd_sel_vs_mi        = round(t_mi_sel / t_twgrey_sel, 2)
        spd_e2e_vs_full      = round(t_full_svm / t_twgrey_e2e, 2)
        spd_e2e_vs_twrelieff = round(t_twrelieff_e2e / t_twgrey_e2e, 2)

        records.append({
            "N": n_samples, "D": D, "k": k, "rho*": rho_star,
            "Chi2-sel": round(t_chi2_sel, 4),
            "MI-sel": round(t_mi_sel, 4),
            "ReliefF-sel": round(t_relieff_sel, 4),
            "TwReliefF-sel": round(t_twrelieff_sel, 4),
            "TwGrey-sel": round(t_twgrey_sel, 4),
            "Full-SVM": round(t_full_svm, 4),
            "Chi2+SVM": round(t_chi2_e2e, 4),
            "MI+SVM": round(t_mi_e2e, 4),
            "TwReliefF-e2e": round(t_twrelieff_e2e, 4),
            "TwGrey-e2e": round(t_twgrey_e2e, 4),
            "Spd(sel) vs TwReliefF": spd_sel_vs_twrelieff,
            "Spd(sel) vs MI": spd_sel_vs_mi,
            "Spd(e2e) vs Full": spd_e2e_vs_full,
            "Spd(e2e) vs TwReliefF": spd_e2e_vs_twrelieff,
            "std(TwGrey-sel)": round(std_twgrey_sel, 4),
            "std(TwGrey-e2e)": round(std_twgrey_e2e, 4),
        })

    df_out = pd.DataFrame(records)
    print(df_out.to_string(index=False))
    df_out.to_excel(os.path.join(output_dir, "table_runtime_comparison.xlsx"), index=False)

    print("\n" + "=" * 110)
    
    for r in records:
        print(f"  ▶ N={r['N']:<5} (k={r['k']}, D={r['D']}) | "
              f"Selection: TwGrey={r['TwGrey-sel']:.4f}s vs TwReliefF={r['TwReliefF-sel']:.4f}s "
              f"({r['Spd(sel) vs TwReliefF']:.1f}x faster) | vs MI: {r['Spd(sel) vs MI']:.1f}x | "
              f"E2E: TwGrey={r['TwGrey-e2e']:.4f}s vs TwReliefF={r['TwReliefF-e2e']:.4f}s "
              f"({r['Spd(e2e) vs TwReliefF']:.2f}x faster)")
    print("=" * 110)

    
    print(r"\begin{table*}[htbp]")
    print(r"  \centering")
    print(r"  \small")
    print(r"  \caption{Runtime comparison (in seconds) and speedup factors across different sample scales ($N$) on NWPU-RESISC45}")
    print(r"  \label{tab:runtime_comparison}")
    print(r"  \begin{tabular}{cccccccccccc}")
    print(r"    \toprule")
    print(r"    \multirow{2}{*}{\textbf{Scale ($N$)}} & \multirow{2}{*}{\textbf{$k$}} & \multicolumn{5}{c}{\textbf{Feature Selection Latency (s)}} & \multicolumn{5}{c}{\textbf{End-to-End Latency (s)}} \\")
    print(r"    \cmidrule(lr){3-7} \cmidrule(lr){8-12}")
    print(r"    & & \textbf{Chi2} & \textbf{MI} & \textbf{ReliefF} & \textbf{TwReliefF} & \textbf{TwGrey (Ours)} & \textbf{Full-SVM} & \textbf{Chi2+SVM} & \textbf{MI+SVM} & \textbf{TwReliefF+SVM} & \textbf{TwGrey+SVM (Ours)} \\")
    print(r"    \midrule")
    for r in records:
        print(f"    {r['N']} & {r['k']} & {r['Chi2-sel']:.4f} & {r['MI-sel']:.4f} & {r['ReliefF-sel']:.4f} & {r['TwReliefF-sel']:.4f} & \\textbf{{{r['TwGrey-sel']:.4f}}} & {r['Full-SVM']:.4f} & {r['Chi2+SVM']:.4f} & {r['MI+SVM']:.4f} & {r['TwReliefF-e2e']:.4f} & \\textbf{{{r['TwGrey-e2e']:.4f}}} \\\\")
    print(r"    \bottomrule")
    print(r"  \end{tabular}")
    print(r"  \vspace{1.0ex}")
    print(r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont \textit{Note:} All times are averaged over 10 independent executions under single-thread constraints. Chi2 and MI serve as baseline references for linear and nonlinear filtering complexity, respectively. End-to-end latency reflects the complete pipeline: feature selection on the 70\% training partition, model fitting on selected features, and inference on the held-out 30\% test partition.}")
    print(r"\end{table*}")


# =========================================================================

# =========================================================================
def run_scalability_analysis():
    print("\n" + "=" * 100)
    print("[实验 3] Stage 1 GRA 核心算子可扩展性 (O(N) 与 O(D) 理论线性验证)")
    print("=" * 100)

    sample_sizes = [160, 400, 800, 2800]
    dimensions_test = [5, 10, 15, 20, 25]

    df = pd.read_excel(data_paths[2800])
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values

    for _ in range(10):
        _ = compute_gra_weights(X[:400], y[:400],
                                [f"f{i}" for i in range(X.shape[1])], rho=0.4)

    print("  [1/2]  (N) ...")
    time_vs_n, std_vs_n = [], []
    for n in sample_sizes:
        sub_X, sub_y = X[:n], y[:n]
        fnames = [f"f{i}" for i in range(sub_X.shape[1])]
        for _ in range(5):
            _ = compute_gra_weights(sub_X, sub_y, fnames, rho=0.4)
        t_list = []
        for _ in range(N_REPEATS_SCALABILITY):
            t0 = time.perf_counter()
            _ = compute_gra_weights(sub_X, sub_y, fnames, rho=0.4)
            t_list.append(time.perf_counter() - t0)
        time_vs_n.append(float(np.mean(t_list)))
        std_vs_n.append(float(np.std(t_list)))
        print(f"       N = {n:<6} | {time_vs_n[-1]*1000:.3f} ms (±{std_vs_n[-1]*1000:.3f})")

    print("  [2/2]  (D) ...")
    time_vs_d, std_vs_d = [], []
    sub_X_fixed, sub_y_fixed = X[:800], y[:800]
    for d in dimensions_test:
        sub_X = sub_X_fixed[:, :d]
        fnames = [f"f{i}" for i in range(d)]
        for _ in range(5):
            _ = compute_gra_weights(sub_X, sub_y_fixed, fnames, rho=0.4)
        t_list = []
        for _ in range(N_REPEATS_SCALABILITY):
            t0 = time.perf_counter()
            _ = compute_gra_weights(sub_X, sub_y_fixed, fnames, rho=0.4)
            t_list.append(time.perf_counter() - t0)
        time_vs_d.append(float(np.mean(t_list)))
        std_vs_d.append(float(np.std(t_list)))
        print(f"       D = {d:<6} | {time_vs_d[-1]*1000:.3f} ms (±{std_vs_d[-1]*1000:.3f})")

    time_vs_n_ms = [t * 1000 for t in time_vs_n]
    time_vs_d_ms = [t * 1000 for t in time_vs_d]
    std_vs_n_ms  = [s * 1000 for s in std_vs_n]
    std_vs_d_ms  = [s * 1000 for s in std_vs_d]

    z1 = np.polyfit(sample_sizes, time_vs_n_ms, 1)
    p1 = np.poly1d(z1)
    r2_n = r2_score(time_vs_n_ms, p1(sample_sizes))
    z2 = np.polyfit(dimensions_test, time_vs_d_ms, 1)
    p2 = np.poly1d(z2)
    r2_d = r2_score(time_vs_d_ms, p2(dimensions_test))

    print(f"\n  N-fit: slope={z1[0]:.5f} ms/sample, R²={r2_n:.4f}")
    print(f"  D-fit: slope={z2[0]:.5f} ms/feature, R²={r2_d:.4f}")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.5, 4.2))
    ax1.errorbar(sample_sizes, time_vs_n_ms, yerr=std_vs_n_ms, marker='o',
                 color='#1f77b4', linewidth=2.0, markersize=7, capsize=4,
                 label='TwGrey Stage 1 runtime')
    ax1.plot(sample_sizes, p1(sample_sizes), linestyle='--', color='#d62728',
             alpha=0.8, label=fr'Linear fit: $\mathcal{{O}}(N)$, $R^2$={r2_n:.3f}')
    ax1.set_xlabel('Sample size ($N$)', fontsize=11, fontweight='bold')
    ax1.set_ylabel('Execution time (ms)', fontsize=11, fontweight='bold')
    ax1.grid(True, linestyle='--', alpha=0.4)
    ax1.set_ylim(bottom=0)
    ax1.legend(loc='upper left', frameon=True)

    ax2.errorbar(dimensions_test, time_vs_d_ms, yerr=std_vs_d_ms, marker='s',
                 color='#2ca02c', linewidth=2.0, markersize=7, capsize=4,
                 label='TwGrey Stage 1 runtime')
    ax2.plot(dimensions_test, p2(dimensions_test), linestyle='--', color='#d62728',
             alpha=0.8, label=fr'Linear fit: $\mathcal{{O}}(D)$, $R^2$={r2_d:.3f}')
    ax2.set_xlabel('Feature dimensionality ($D$)', fontsize=11, fontweight='bold')
    ax2.set_ylabel('Execution time (ms)',                  fontsize=11, fontweight='bold')
    ax2.grid(True, linestyle='--', alpha=0.4)
    ax2.set_ylim(bottom=0)
    ax2.legend(loc='upper left', frameon=True)

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "fig_scalability9.png"), dpi=FIG_DPI, bbox_inches='tight')
    plt.savefig(os.path.join(output_dir, "fig_scalability9.pdf"), format='pdf', bbox_inches='tight')
    plt.close()
    


# =========================================================================

# =========================================================================
if __name__ == "__main__":
    print(f"  CPU: {platform.processor()} | Cores: {psutil.cpu_count(logical=False)} 物理 / {psutil.cpu_count(logical=True)} 逻辑")
    print(f"  RAM: {psutil.virtual_memory().total / (1024**3):.2f} GB")
    print(f"  Python: {platform.python_version()} | scikit-learn: {sklearn.__version__}")
    print(f"   RHO_STAR: {RHO_STAR}")

    run_stage_breakdown()
    run_runtime_comparison()
    run_scalability_analysis()