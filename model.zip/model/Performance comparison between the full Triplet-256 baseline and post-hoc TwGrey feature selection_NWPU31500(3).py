import os
import random
import math
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from scipy.stats import norm
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score, auc, confusion_matrix,
    f1_score, precision_score, recall_score, roc_curve,
)
from sklearn.preprocessing import label_binarize, normalize
from tensorflow.keras import Model, layers

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

random.seed(42); np.random.seed(42); tf.random.set_seed(42)


def create_svm():
    return SVC(C=1.0, kernel='rbf', gamma='scale',
               decision_function_shape='ovr', probability=True, random_state=42)


DATASET_ROOT_NWPU = r"D:\e\NWPU\NWPU-RESISC45_dataset"


data_paths = {
    31500: DATASET_ROOT_NWPU,
}


export_dir = r"D:\NWPU_Experiment\Triplet_RBF4"
os.makedirs(export_dir, exist_ok=True)

cache_dir = r"D:\NWPU_Experiment\image_cache"
os.makedirs(cache_dir, exist_ok=True)


def create_base_network(input_shape=(128, 128, 3)):
    inputs = tf.keras.Input(shape=input_shape)
    x = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(inputs)
    x = layers.MaxPooling2D((2, 2))(x)
    x = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(x)
    x = layers.MaxPooling2D((2, 2))(x)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(256, activation=None)(x)
    outputs = layers.Lambda(lambda t: tf.math.l2_normalize(t, axis=1))(x)
    return Model(inputs, outputs, name="base_feature_extractor")


def triplet_loss(y_true, y_pred, alpha=0.4):
    a = y_pred[:, 0:256]; p = y_pred[:, 256:512]; n = y_pred[:, 512:768]
    pos = tf.reduce_sum(tf.square(a - p), axis=-1)
    neg = tf.reduce_sum(tf.square(a - n), axis=-1)
    return tf.reduce_mean(tf.maximum(pos - neg + alpha, 0.0))


def build_triplet_model(base_net, input_shape=(128, 128, 3)):
    ai = tf.keras.Input(input_shape); pi = tf.keras.Input(input_shape); ni = tf.keras.Input(input_shape)
    ea = base_net(ai); ep = base_net(pi); en = base_net(ni)
    merged = layers.concatenate([ea, ep, en], axis=1)
    m = Model(inputs=[ai, pi, ni], outputs=merged)
    m.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4), loss=triplet_loss)
    return m


def triplet_data_generator(X, y, batch_size=32):
    uc = np.unique(y)
    ci = {c: np.where(y == c)[0] for c in uc}
    while True:
        A, P, N = [], [], []
        for _ in range(batch_size):
            c = np.random.choice(uc)
            ia = np.random.choice(ci[c]); A.append(X[ia])
            same = ci[c][ci[c] != ia]
            ip = ia if len(same) == 0 else np.random.choice(same); P.append(X[ip])
            dc = np.random.choice([x for x in uc if x != c])
            ineg = np.random.choice(ci[dc]); N.append(X[ineg])
        yield ([np.array(A), np.array(P), np.array(N)], np.zeros(batch_size))


def build_stratified_split(root_dir, val_ratio=0.3, seed=42):
    rng = random.Random(seed)
    class_names = sorted([d for d in os.listdir(root_dir)
                          if os.path.isdir(os.path.join(root_dir, d))])
    tr_p, tr_l, va_p, va_l = [], [], [], []
    for ci, name in enumerate(class_names):
        d = os.path.join(root_dir, name)
        files = sorted([f for f in os.listdir(d)
                        if os.path.isfile(os.path.join(d, f))
                        and f.lower().endswith(('.jpg','.jpeg','.png','.bmp','.tif','.tiff'))])
        rng.shuffle(files)
        sp = int((1.0 - val_ratio) * len(files))
        for f in files[:sp]:
            tr_p.append(os.path.join(d, f)); tr_l.append(ci)
        for f in files[sp:]:
            va_p.append(os.path.join(d, f)); va_l.append(ci)
    return tr_p, tr_l, va_p, va_l, class_names


def load_or_cache_images(paths, cache_path, target_size=(128, 128)):
    if os.path.exists(cache_path):
        print(f"📂 : {cache_path}")
        return np.load(cache_path)
    print(f"🖼️ : {cache_path}")
    imgs = []
    for i, p in enumerate(paths):
        img = tf.keras.preprocessing.image.load_img(p, target_size=target_size)
        arr = tf.keras.preprocessing.image.img_to_array(img) / 255.0
        imgs.append(arr)
        if (i + 1) % 5000 == 0:
            print(f"   {i+1}/{len(paths)}")
    arr = np.array(imgs, dtype=np.float32)
    np.save(cache_path, arr)
    return arr


def compute_maf1_ci(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes); n = len(y_true)
    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)
    p = cm / n
    pr = np.sum(p, axis=1); pc = np.sum(p, axis=0); pd_ = np.diag(p)
    denom = pr + pc; valid = denom > 0
    F1 = np.zeros(r); F1[valid] = 2.0 * pd_[valid] / denom[valid]
    maf1 = np.mean(F1)
    diff_p = denom - 2.0 * pd_
    A = 0.0
    for i in range(r):
        if denom[i] > 0:
            A += ((F1[i]*diff_p[i])/(denom[i]**2)) * ((diff_p[i]/denom[i]) + F1[i]/2.0)
    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p[i,j]*F1[i]*F1[j])/(denom[i]*denom[j])
    var = (2.0/(n*(r**2)))*(A+B); se = np.sqrt(max(0, var))
    z = norm.ppf(1.0 - alpha/2.0)
    return maf1, se, (max(0.0, maf1 - z*se), min(1.0, maf1 + z*se))


EPOCHS = 50
BATCH_SIZE = 32

for n_samples, path in data_paths.items():
    print("\n" + "=" * 80)
    print(f"🚀 N = {n_samples} | : {path}")
    print("=" * 80)

    tr_p, tr_l, va_p, va_l, class_names = build_stratified_split(path, val_ratio=0.3, seed=42)
    print(f"📊 ={len(class_names)}, train={len(tr_p)}, val={len(va_p)}")

    X_train_raw = load_or_cache_images(tr_p, os.path.join(cache_dir, f"train_N{n_samples}.npy"))
    X_val_raw   = load_or_cache_images(va_p, os.path.join(cache_dir, f"val_N{n_samples}.npy"))
    y_train_raw = np.array(tr_l, dtype=int)
    y_val_raw = np.array(va_l, dtype=int)

    tf.keras.backend.clear_session()
    base_net = create_base_network()
    trip_model = build_triplet_model(base_net)

    steps = max(1, math.ceil(len(X_train_raw) / BATCH_SIZE))
    gen = triplet_data_generator(X_train_raw, y_train_raw, batch_size=BATCH_SIZE)
    print(f"⏳  (Epochs={EPOCHS}, Steps={steps})...")
    history = trip_model.fit(gen, steps_per_epoch=steps, epochs=EPOCHS, verbose=0)
    loss_vals = history.history['loss']

    base_net_path = os.path.join(export_dir, f"base_net_N{n_samples}.h5")
    base_net.save(base_net_path)
    print(f"💾 : {base_net_path}")

    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.plot(range(1, EPOCHS + 1), loss_vals, color='#1f77b4', lw=2.0, marker='o', markersize=3)
    ax.set_xlabel('Epochs'); ax.set_ylabel('Triplet loss')
    ax.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(os.path.join(export_dir, f"triplet_loss_N{n_samples}.pdf"), bbox_inches='tight')
    plt.close()

    X_tr_f = normalize(base_net.predict(X_train_raw, batch_size=32, verbose=0))
    X_va_f = normalize(base_net.predict(X_val_raw, batch_size=32, verbose=0))

    clf = create_svm()
    clf.fit(X_tr_f, y_train_raw)
    y_pred = clf.predict(X_va_f)
    y_proba = clf.predict_proba(X_va_f)

    acc = accuracy_score(y_val_raw, y_pred)
    f1 = f1_score(y_val_raw, y_pred, average='macro', zero_division=0)
    _, se_val, (ci_low, ci_high) = compute_maf1_ci(y_val_raw, y_pred)

    np.savez(os.path.join(export_dir, f"roc_data_{n_samples}_Triplet.npz"),
             y_true=y_val_raw, y_proba=y_proba, classes=clf.classes_)

    print(f"🏆 N={n_samples} | Acc={acc*100:.2f}% | Macro-F1={f1*100:.2f}% (SE={se_val:.4f})")
    print(f"🔒 CI: [{ci_low*100:.2f}%, {ci_high*100:.2f}%]")