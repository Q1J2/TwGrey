import os
import time
import warnings
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.svm import SVC

warnings.filterwarnings('ignore')

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False

FIG_DPI = 300

# ==========================================

# ==========================================
base_dir = r"D:\e\NWPU\NWPU700"
analysis_dir = os.path.join(base_dir, "rho_analysis")
os.makedirs(analysis_dir, exist_ok=True)

excel_file = os.path.join(base_dir, "NWPU700.xlsx")
df = pd.read_excel(excel_file)
X = df.iloc[:, :-1]
y = df.iloc[:, -1]
feature_names = X.columns.tolist()

# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y
)
print(f" N_train = {X_train.shape[0]},  N_val = {X_val.shape[0]}")



# ==========================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )


def compute_gra_importance(X_mat, y_vec, rho):
    
    X_mat = np.asarray(X_mat, dtype=np.float64)
    y_vec = np.asarray(y_vec)
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()
    n_features = X_mat.shape[1]
    gamma = np.zeros(n_features)
    for i in range(n_features):
        gamma[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )
    return gamma


def shadow_set_objective(alpha, beta, gamma_vals):
    significant = gamma_vals[gamma_vals >= alpha]
    insignificant = gamma_vals[gamma_vals <= beta]
    shadow = gamma_vals[(gamma_vals > beta) & (gamma_vals < alpha)]

    v1 = np.sum(1.0 - significant)
    v2 = np.sum(insignificant)
    v3 = len(shadow)

    return abs(v1 + v2 - v3)


def optimize_thresholds(gamma_vals, step=0.005):
    gamma_vals = np.asarray(gamma_vals, dtype=np.float64)
    min_objective = float("inf")
    best_alpha, best_beta = 0.0, 0.0

    gamma_min = np.min(gamma_vals)
    gamma_max = np.max(gamma_vals)
    thresholds = np.arange(gamma_min + step, gamma_max, step)

    if len(thresholds) < 2:
        step = (gamma_max - gamma_min) / 10.0
        thresholds = np.arange(gamma_min + step, gamma_max, step)

    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1 :]:
            objective = shadow_set_objective(alpha_cand, beta_cand, gamma_vals)
            if objective < min_objective:
                min_objective = objective
                best_alpha = alpha_cand
                best_beta = beta_cand

    return best_alpha, best_beta


def evaluate_on_dataset(model, X_subset, y_true):
    
    y_pred = model.predict(X_subset)
    acc = accuracy_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred, average="macro", zero_division=0)
    precision = precision_score(y_true, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    return acc, precision, recall, f1


# ==========================================

# ==========================================
rhos = np.round(np.arange(0.1, 1.0, 0.1), 1)
sensitivity_results = []
phi_results = []

print("\nrho ...")

for rho in rhos:
    rho_str = f"{rho:.1f}"

    # 1
    gamma_train = compute_gra_importance(X_train.values, y_train.values, rho=rho)
    alpha, beta = optimize_thresholds(gamma_train, step=0.005)
    phi_results.append({"rho": rho, "alpha": alpha, "beta": beta})

    feature_importances = dict(zip(feature_names, gamma_train))

    # 2)
    positive_region = [f for f, s in feature_importances.items() if s >= alpha]
    border_region = [f for f, s in feature_importances.items() if beta < s < alpha]

    
    if len(positive_region) == 0:
        top_f = max(feature_importances, key=feature_importances.get)
        positive_region.append(top_f)
        if top_f in border_region:
            border_region.remove(top_f)

    # 3) 
    X_train_pos = X_train[positive_region].copy()
    svm = create_svm()
    svm.fit(X_train_pos, y_train)
    acc0 = accuracy_score(y_train, svm.predict(X_train_pos))

    for feature in sorted(border_region, key=feature_importances.get, reverse=True):
        X_train_pos[feature] = X_train[feature]
        temp_svm = create_svm()
        temp_svm.fit(X_train_pos, y_train)
        acc_cand = accuracy_score(y_train, temp_svm.predict(X_train_pos))

        if acc_cand > acc0:
            acc0 = acc_cand
            positive_region.append(feature)
        else:
            X_train_pos.drop(columns=[feature], inplace=True)

    # 4) 
    final_svm = create_svm()
    final_svm.fit(X_train[positive_region], y_train)
    val_acc, val_prec, val_rec, val_f1 = evaluate_on_dataset(final_svm, X_val[positive_region], y_val)

    # 5) 
    sensitivity_results.append(
        {
            "rho": rho_str,
            "alpha_beta": f"({alpha:.4f}, {beta:.4f})",
            "Accuracy": val_acc,
            "maP": val_prec,
            "maR": val_rec,
            "Macro_F1": val_f1,
            "Features": len(positive_region),
        }
    )

# ==========================================
# 4.
# ==========================================
res_df = pd.DataFrame(sensitivity_results)
csv_out_path = os.path.join(analysis_dir, "rho_sensitivity_results.csv")
res_df.to_csv(csv_out_path, index=False, encoding="utf-8-sig")

print("\n" + "=" * 80)

print(res_df.to_string(index=False))
print("=" * 80)


latex_code = [
    r"\begin{table}[htbp]",
    r"  \centering",
    r"  \small",
    r"  \caption{Parameter sensitivity analysis of the GRA distinguishing coefficient $\rho$ on independent test partition ($70\%/30\%$ split)}",
    r"  \label{tab:rho_sensitivity}",
    r"  \begin{tabular}{@{}lcccccc@{}}",
    r"     \toprule",
    r"     $\rho$ & $(\alpha, \beta)$ & Accuracy & $maP$ & $maR$ & Macro-$F1$ & Features \\",
    r"     \midrule",
]

best_idx = res_df.sort_values(
    by=["Macro_F1", "Accuracy", "Features"], ascending=[False, False, True]
).index[0]

for idx, row in res_df.iterrows():
    if idx == best_idx:
        line = f"      \\bfseries {row['rho']} & \\bfseries {row['alpha_beta']} & \\bfseries {row['Accuracy']:.4f} & \\bfseries {row['maP']:.4f} & \\bfseries {row['maR']:.4f} & \\bfseries {row['Macro_F1']:.4f} & \\bfseries {row['Features']} \\\\"
    else:
        line = f"      {row['rho']} & {row['alpha_beta']} & {row['Accuracy']:.4f} & {row['maP']:.4f} & {row['maR']:.4f} & {row['Macro_F1']:.4f} & {row['Features']} \\\\"
    latex_code.append(line)

latex_code.extend([
    r"     \bottomrule",
    r"  \end{tabular}",
    r"  \vspace{1.0ex}",
    r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont \textit{Note:} All thresholds and features are selected exclusively using the 70\% training split. Metrics are evaluated on the held-out 30\% test set.}",
    r"\end{table}"
])
print("\n".join(latex_code))


# =========================================================================

# =========================================================================
print("\n" + "=" * 65)
print("📊 ")
print("=" * 65)

fig, ax = plt.subplots(1, 1, figsize=(8, 4.8))

rhos_plot = [r["rho"] for r in phi_results]
alpha_values = [r["alpha"] for r in phi_results]
beta_values = [r["beta"] for r in phi_results]

ax.plot(
    rhos_plot,
    alpha_values,
    "o-",
    color="#e74c3c",
    linewidth=2,
    markersize=8,
    label=r"$\alpha$",
)
ax.plot(
    rhos_plot,
    beta_values,
    "s-",
    color="#3498db",
    linewidth=2,
    markersize=8,
    label=r"$\beta$",
)


ax.fill_between(
    rhos_plot,
    beta_values,
    alpha_values,
    color="#f1c40f",
    alpha=0.3,
    label="Boundary region",
)

ax.set_xlabel(r"$\rho$", fontsize=12, fontweight='bold')
ax.set_ylabel("Threshold value", fontsize=12, fontweight='bold')
ax.legend(loc="upper left", fontsize=10.5, frameon=True)
ax.grid(True, linestyle="--", alpha=0.35)
ax.set_xticks(rhos_plot)
ax.set_xticklabels([f"{p:.1f}" for p in rhos_plot])

for p_val, a_val, b_val in zip(rhos_plot, alpha_values, beta_values):
    ax.annotate(
        f"{a_val:.3f}",
        (p_val, a_val),
        textcoords="offset points",
        xytext=(0, 8),
        ha="center",
        fontsize=8.5,
    )
    ax.annotate(
        f"{b_val:.3f}",
        (p_val, b_val),
        textcoords="offset points",
        xytext=(0, -14),
        ha="center",
        fontsize=8.5,
    )

plt.tight_layout()

fig_pdf_path = os.path.join(analysis_dir, "threshold_curve.pdf")
fig_png_path = os.path.join(analysis_dir, "threshold_curve.png")
plt.savefig(fig_pdf_path, format='pdf', bbox_inches='tight')
plt.savefig(fig_png_path, dpi=FIG_DPI, bbox_inches='tight')
print(f"✅ PDF : {fig_pdf_path}")
print(f"✅ PNG: {fig_png_path}")
plt.close()


# =========================================================================

# =========================================================================
target_base_rho = 0.4
print("\n" + "=" * 65)
print(f"⏱️ rho={target_base_rho})...")
print("=" * 65)

delta_steps = [0.001, 0.005, 0.010, 0.015, 0.020]
delta_results = []


gamma_train_base = compute_gra_importance(X_train.values, y_train.values, rho=target_base_rho)
f_imp_train = dict(zip(feature_names, gamma_train_base))

for delta in delta_steps:
    t_start = time.time()

    # 1) 
    t_search_start = time.time()
    a_delta, b_delta = optimize_thresholds(gamma_train_base, step=delta)
    search_time = time.time() - t_search_start

    # 2) 
    pos_region = [f for f, s in f_imp_train.items() if s >= a_delta]
    bdr_region = [f for f, s in f_imp_train.items() if b_delta < s < a_delta]

    if len(pos_region) == 0:
        top_f = max(f_imp_train, key=f_imp_train.get)
        pos_region.append(top_f)
        if top_f in bdr_region:
            bdr_region.remove(top_f)

    X_train_d = X_train[pos_region].copy()
    svm_delta = create_svm()
    svm_delta.fit(X_train_d, y_train)
    acc_delta = accuracy_score(y_train, svm_delta.predict(X_train_d))

    for feature in sorted(bdr_region, key=f_imp_train.get, reverse=True):
        X_train_d[feature] = X_train[feature]
        temp_svm_delta = create_svm()
        temp_svm_delta.fit(X_train_d, y_train)
        acc_cand = accuracy_score(y_train, temp_svm_delta.predict(X_train_d))

        if acc_cand > acc_delta:
            acc_delta = acc_cand
            pos_region.append(feature)
        else:
            X_train_d.drop(columns=[feature], inplace=True)

    # 3) 
    final_svm_delta = create_svm()
    final_svm_delta.fit(X_train[pos_region], y_train)
    val_acc_delta = accuracy_score(y_val, final_svm_delta.predict(X_val[pos_region])) * 100.0

    total_runtime = time.time() - t_start

    delta_results.append(
        {
            "delta": f"{delta:.4f}",
            "alpha_beta": f"({a_delta:.4f}, {b_delta:.4f})",
            "search_time": f"{search_time:.1f}",
            "total_runtime": f"{total_runtime:.1f}",
            "accuracy": f"{val_acc_delta:.2f}",
            "features_count": len(pos_region),
            "selected_features": sorted(pos_region),
        }
    )

# ==========================================
# 7. 
# ==========================================
delta_df = pd.DataFrame(delta_results)
csv_delta_path = os.path.join(analysis_dir, "delta_sensitivity_results.csv")
delta_df.to_csv(csv_delta_path, index=False, encoding="utf-8-sig")

print("\n" + "=" * 85)
print("📊 delta :")
print("=" * 85)
cols_to_show = ["delta", "alpha_beta", "search_time", "total_runtime", "features_count", "accuracy"]
print(delta_df[cols_to_show].to_string(index=False))
print("=" * 85)

print("\n delta LaTeX ：\n")
latex_delta = [
    r"\begin{table}[htbp]",
    r"  \centering",
    r"  \small",
    r"  \caption{Sensitivity of optimization efficiency and classification performance to step size $\delta$ (evaluated on independent test partition)}",
    r"  \label{tab:delta_sensitivity}",
    r"  \begin{tabular}{@{}lccccc@{}}",
    r"     \toprule",
    r"     $\delta$ & $(\alpha, \beta)$ & Search Time (s) & Total Runtime (s) & Features & Accuracy (\%) \\",
    r"     \midrule",
]

for _, row in delta_df.iterrows():
    latex_delta.append(
        f"     {row['delta']}  & {row['alpha_beta']} & {row['search_time']} & {row['total_runtime']} & {row['features_count']} & {row['accuracy']} \\\\"
    )

latex_delta.extend([
    r"     \bottomrule",
    r"  \end{tabular}",
    r"  \vspace{1.0ex}",
    r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont \textit{Note:} Step size search latency is measured on the training partition. Accuracy and selected features are evaluated on the 30\% mutually exclusive test partition.}",
    r"\end{table}"
])
print("\n".join(latex_delta))