import os
import random
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from scipy.stats import norm
from sklearn import svm
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    auc,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_curve,
)
from sklearn.preprocessing import label_binarize, normalize
from tensorflow.keras import Model, layers
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import math
# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300


random.seed(42)
np.random.seed(42)
tf.random.set_seed(42)

# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}

export_dir = r"D:\e\NWPU\Experiment_Plots_Triplet_RBF4"
os.makedirs(export_dir, exist_ok=True)

# =========================================================================

# =========================================================================
def create_base_network(input_shape=(128, 128, 3)):
    inputs = tf.keras.Input(shape=input_shape)
    x = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(inputs)
    x = layers.MaxPooling2D((2, 2))(x)
    x = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(x)
    x = layers.MaxPooling2D((2, 2))(x)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(256, activation=None)(x)
    outputs = layers.Lambda(lambda t: tf.math.l2_normalize(t, axis=1))(x)
    return Model(inputs, outputs, name="base_feature_extractor")

def triplet_loss(y_true, y_pred, alpha=0.4):
    anchor = y_pred[:, 0:256]
    positive = y_pred[:, 256:512]
    negative = y_pred[:, 512:768]
    pos_dist = tf.reduce_sum(tf.square(anchor - positive), axis=-1)
    neg_dist = tf.reduce_sum(tf.square(anchor - negative), axis=-1)
    basic_loss = pos_dist - neg_dist + alpha
    return tf.reduce_mean(tf.maximum(basic_loss, 0.0))

def build_triplet_model(base_network, input_shape=(128, 128, 3)):
    anchor_in = tf.keras.Input(input_shape)
    pos_in = tf.keras.Input(input_shape)
    neg_in = tf.keras.Input(input_shape)

    enc_a = base_network(anchor_in)
    enc_p = base_network(pos_in)
    enc_n = base_network(neg_in)

    merged = layers.concatenate([enc_a, enc_p, enc_n], axis=1)
    model = Model(inputs=[anchor_in, pos_in, neg_in], outputs=merged)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4), loss=triplet_loss)
    return model

def triplet_data_generator(X, y, batch_size=32):
    unique_classes = np.unique(y)
    class_indices = {c: np.where(y == c)[0] for c in unique_classes}

    while True:
        anchors, positives, negatives = [], [], []
        for _ in range(batch_size):
            c = np.random.choice(unique_classes)
            idx_a = np.random.choice(class_indices[c])
            anchor_img = X[idx_a]

            same_cls = class_indices[c][class_indices[c] != idx_a]
            idx_p = idx_a if len(same_cls) == 0 else np.random.choice(same_cls)
            pos_img = X[idx_p]

            diff_cls = np.random.choice([cls for cls in unique_classes if cls != c])
            idx_n = np.random.choice(class_indices[diff_cls])
            neg_img = X[idx_n]

            anchors.append(anchor_img)
            positives.append(pos_img)
            negatives.append(neg_img)

        yield ([np.array(anchors), np.array(positives), np.array(negatives)], np.zeros(batch_size))

def load_generator_data(generator):
    images, labels = [], []
    generator.reset()
    for _ in range(len(generator)):
        imgs, lbls = next(generator)
        images.append(imgs)
        labels.append(lbls)
    return np.vstack(images), np.hstack(labels).astype(int)
def build_stratified_split(root_dir, val_ratio=0.3, seed=42):
    
    rng = random.Random(seed)

    class_names = sorted([d for d in os.listdir(root_dir)
                          if os.path.isdir(os.path.join(root_dir, d))])

    train_paths, train_labels, val_paths, val_labels = [], [], [], []
    for cls_idx, name in enumerate(class_names):
        cls_dir = os.path.join(root_dir, name)
        files = sorted([
            f for f in os.listdir(cls_dir)
            if os.path.isfile(os.path.join(cls_dir, f))
               and f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'))
        ])
        rng.shuffle(files)                      
        split_pt = int((1.0 - val_ratio) * len(files))
        for f in files[:split_pt]:
            train_paths.append(os.path.join(cls_dir, f))
            train_labels.append(cls_idx)
        for f in files[split_pt:]:
            val_paths.append(os.path.join(cls_dir, f))
            val_labels.append(cls_idx)

    return train_paths, train_labels, val_paths, val_labels, class_names
# =========================================================================

# =========================================================================
def compute_maf1_confidence_interval(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes)
    n = len(y_true)

    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)
    p_hat = cm / n
    p_row = np.sum(p_hat, axis=1)
    p_col = np.sum(p_hat, axis=0)
    p_diag = np.diag(p_hat)

    denom = p_row + p_col
    valid_mask = denom > 0

    F1_i = np.zeros(r)
    F1_i[valid_mask] = 2.0 * p_diag[valid_mask] / denom[valid_mask]
    maF1 = np.mean(F1_i)

    diff_p = denom - 2.0 * p_diag
    A_terms = np.zeros(r)
    for i in range(r):
        if denom[i] > 0:
            term1 = (F1_i[i] * diff_p[i]) / (denom[i] ** 2)
            term2 = (diff_p[i] / denom[i]) + (F1_i[i] / 2.0)
            A_terms[i] = term1 * term2
    A = np.sum(A_terms)

    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p_hat[i, j] * F1_i[i] * F1_i[j]) / (denom[i] * denom[j])

    var_maF1 = (2.0 / (n * (r ** 2))) * (A + B)
    se_maF1 = np.sqrt(max(0.0, var_maF1))

    z = norm.ppf(1.0 - alpha / 2.0)
    ci_lower = max(0.0, maF1 - z * se_maF1)
    ci_upper = min(1.0, maF1 + z * se_maF1)
    return maF1, se_maF1, (ci_lower, ci_upper)

# =========================================================================

# =========================================================================

benchmark_summary = []
roc_plot_data = {}
all_losses_history = {}
EPOCHS = 50


def load_images_from_paths(paths, target_size=(128, 128)):
    imgs = []
    for p in paths:
        img = tf.keras.preprocessing.image.load_img(p, target_size=target_size)
        arr = tf.keras.preprocessing.image.img_to_array(img) / 255.0
        imgs.append(arr)
    return np.array(imgs, dtype=np.float32)

for n_samples, path in data_paths.items():
    print("\n" + "=" * 80)
    print(f"🚀 : N = {n_samples} | 路径: {path}")
    print("=" * 80)

    
    train_paths, train_labels, val_paths, val_labels, class_names = build_stratified_split(
        path, val_ratio=0.3, seed=42
    )

    X_train_raw = load_images_from_paths(train_paths)
    y_train_raw = np.array(train_labels, dtype=int)
    X_val_raw = load_images_from_paths(val_paths)
    y_val_raw = np.array(val_labels, dtype=int)

    
    tf.keras.backend.clear_session()
    base_net = create_base_network()
    trip_model = build_triplet_model(base_net)

    batch_size = 32


    steps_per_epoch = max(1, math.ceil(len(X_train_raw) / batch_size))
    train_trip_gen = triplet_data_generator(X_train_raw, y_train_raw, batch_size=batch_size)

    print(f"⏳  (Epochs={EPOCHS}, Steps={steps_per_epoch})...")
    history = trip_model.fit(train_trip_gen, steps_per_epoch=steps_per_epoch, epochs=EPOCHS, verbose=0)
    loss_vals = history.history['loss']
    all_losses_history[n_samples] = loss_vals
    # =====================================================================
    
    # =====================================================================
    base_net_path = os.path.join(export_dir, f"base_net_N{n_samples}.h5")
    base_net.save(base_net_path)
    print(f"💾  base_net: {base_net_path}")

    
    fig_single, ax_single = plt.subplots(figsize=(6.5, 4.2))
    ax_single.plot(range(1, EPOCHS + 1), loss_vals, color='#1f77b4', lw=2.0, marker='o', markersize=3, label=f'Loss (N={n_samples})')
    ax_single.set_xlabel('Epochs', fontsize=12)
    ax_single.set_ylabel('Triplet loss', fontsize=12)
    #ax_single.set_title(f'Triplet Loss Convergence Curve (N={n_samples})', fontsize=12, fontweight='bold')
    ax_single.grid(True, linestyle='--', alpha=0.5)
    ax_single.legend(loc='upper right')
    plt.tight_layout()

    single_loss_pdf = os.path.join(export_dir, f"triplet_loss_convergence_N{n_samples}.pdf")
    single_loss_png = os.path.join(export_dir, f"triplet_loss_convergence_N{n_samples}.png")
    plt.savefig(single_loss_pdf, format='pdf', bbox_inches='tight')
    plt.savefig(single_loss_png, dpi=FIG_DPI, bbox_inches='tight')
    plt.close()

    
    X_train_feats = normalize(base_net.predict(X_train_raw, batch_size=32, verbose=0))
    X_val_feats = normalize(base_net.predict(X_val_raw, batch_size=32, verbose=0))

    
    clf = create_svm()
    clf.fit(X_train_feats, y_train_raw)

    y_pred = clf.predict(X_val_feats)
    y_proba = clf.predict_proba(X_val_feats)

    acc = accuracy_score(y_val_raw, y_pred)
    prec = precision_score(y_val_raw, y_pred, average='macro', zero_division=0)
    rec = recall_score(y_val_raw, y_pred, average='macro', zero_division=0)
    f1 = f1_score(y_val_raw, y_pred, average='macro', zero_division=0)
    maf1_val, se_val, (ci_low, ci_high) = compute_maf1_confidence_interval(y_val_raw, y_pred, alpha=0.05)

    roc_plot_data[n_samples] = {
        'y_true': y_val_raw,
        'y_proba': y_proba,
        'classes': clf.classes_
    }

    # =========================================================================
    
    # =========================================================================
    export_dir_cmp = r"D:\e\NWPU\Experiment_Plots_Triplet_RBF4"
    os.makedirs(export_dir_cmp, exist_ok=True)
    npz_save_path = os.path.join(export_dir_cmp, f"roc_data_{n_samples}_Triplet.npz")
    np.savez(
        npz_save_path,
        y_true=y_val_raw,  
        y_proba=y_proba,
        classes=clf.classes_
    )
    print(f"📦  N={n_samples} Triplet : {npz_save_path}")

    print(f"🏆 : Features={X_train_feats.shape[1]} | Acc={acc*100:.2f}% | Macro-F1={f1*100:.2f}% (SE={se_val:.4f})")
    print(f"🔒 Macro-F1 95% : [{ci_low*100:.2f}%, {ci_high*100:.2f}%]")

    benchmark_summary.append({
        "Sample Size (N)": n_samples,
        "Penalty C": 1.0,
        "Selected Features": X_train_feats.shape[1],
        "Accuracy (%)": f"{acc * 100:.2f}",
        "Macro Precision (%)": f"{prec * 100:.2f}",
        "Macro Recall (%)": f"{rec * 100:.2f}",
        "Macro F1 (%)": f"{f1 * 100:.2f}",
        "Macro F1 (95% CI)": f"{f1 * 100:.2f} [{ci_low * 100:.2f}, {ci_high * 100:.2f}]",
        "raw_f1": f1 * 100,
        "raw_ci_low": ci_low * 100,
        "raw_ci_high": ci_high * 100,
        "raw_se": se_val * 100
    })

# =========================================================================

# =========================================================================
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']


fig_loss, ax_loss = plt.subplots(figsize=(6.5, 4.5))
for idx, (n_samples, loss_curve_vals) in enumerate(all_losses_history.items()):
    ax_loss.plot(
        range(1, EPOCHS + 1), loss_curve_vals,
        color=colors[idx % len(colors)], lw=2.0,
        label=f'N = {n_samples} (Final loss: {loss_curve_vals[-1]:.4f})'
    )
ax_loss.set_xlabel('Epochs', fontsize=12)
ax_loss.set_ylabel('Triplet loss', fontsize=12)
#ax_loss.set_title('Triplet Loss Convergence Across Scales', fontsize=12, fontweight='bold')
ax_loss.grid(True, linestyle='--', alpha=0.5)
ax_loss.legend(loc='upper right', fontsize=10)
plt.tight_layout()

multi_loss_pdf = os.path.join(export_dir, "triplet_loss_convergence_all_scales.pdf")
multi_loss_png = os.path.join(export_dir, "triplet_loss_convergence_all_scales.png")
plt.savefig(multi_loss_pdf, format='pdf', bbox_inches='tight')
plt.savefig(multi_loss_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig_ci, ax_ci = plt.subplots(figsize=(6.5, 4.2))
scales = [row["Sample Size (N)"] for row in benchmark_summary]
f1_vals = [row["raw_f1"] for row in benchmark_summary]
yerr_low = [row["raw_f1"] - row["raw_ci_low"] for row in benchmark_summary]
yerr_high = [row["raw_ci_high"] - row["raw_f1"] for row in benchmark_summary]

ax_ci.errorbar(
    range(len(scales)), f1_vals, yerr=[yerr_low, yerr_high],
    fmt='-^', color='#9467bd', ecolor='#d62728', elinewidth=2, capsize=5, capthick=1.5,
    markersize=6, label='Macro-F1 with 95% CI (Triplet baseline)'
)
ax_ci.set_xticks(range(len(scales)))
ax_ci.set_xticklabels([f"N={s}" for s in scales])
ax_ci.set_xlabel('Sample scale (N)', fontsize=12)
ax_ci.set_ylabel('Macro-F1 score (%)', fontsize=12)
#ax_ci.set_title('Triplet Metric Learning Macro-F1 Across Scales with 95% CI', fontsize=12, fontweight='bold')
ax_ci.grid(True, linestyle='--', alpha=0.5)
ax_ci.legend(loc='lower right')
plt.tight_layout()

ci_plot_pdf = os.path.join(export_dir, "Triplet_MacroF1_Confidence_Interval.pdf")
ci_plot_png = os.path.join(export_dir, "Triplet_MacroF1_Confidence_Interval.png")
plt.savefig(ci_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(ci_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig_roc, ax_roc = plt.subplots(figsize=(6.5, 5))
for idx, (n_samples, data) in enumerate(roc_plot_data.items()):
    y_true_bin = label_binarize(data['y_true'], classes=data['classes'])
    y_proba = data['y_proba']
    n_classes = len(data['classes'])

    all_fpr = np.unique(np.concatenate([roc_curve(y_true_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_true_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

    ax_roc.plot(all_fpr, mean_tpr, color=colors[idx % len(colors)], lw=2,
            label=f'N = {n_samples} (Macro-AUC = {macro_auc:.4f})')

ax_roc.plot([0, 1], [0, 1], 'k--', lw=1.2, label='Random chance')
ax_roc.set_xlim([0.0, 1.0])
ax_roc.set_ylim([0.0, 1.05])
ax_roc.set_xlabel('False positive rate', fontsize=12)
ax_roc.set_ylabel('True positive rate', fontsize=12)
#ax_roc.set_title('Triplet Network One-vs-Rest ROC Curves across Scales', fontsize=12, fontweight='bold')
ax_roc.legend(loc='lower right', fontsize=10)
ax_roc.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()

roc_plot_pdf = os.path.join(export_dir, "Triplet_ROC_Curves.pdf")
roc_plot_png = os.path.join(export_dir, "Triplet_ROC_Curves.png")
plt.savefig(roc_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(roc_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


# =========================================================================
df_summary = pd.DataFrame(benchmark_summary)
print("\n" + "=" * 110)

print("=" * 110)
print(df_summary[["Sample Size (N)", "Penalty C", "Selected Features", "Accuracy (%)", "Macro Precision (%)", "Macro Recall (%)", "Macro F1 (95% CI)"]].to_string(index=False))


print(r"\begin{table}[htbp]")
print(r"  \centering")
print(r"  \small")
print(r"  \caption{Performance of deep Triplet metric learning across different sample scales ($C=1.0$) on NWPU-RESISC45}")
print(r"  \label{tab:triplet_scale_results}")
print(r"  \begin{tabular}{ccccccc}")
print(r"    \toprule")
print(r"    \textbf{Sample Size ($N$)} & \textbf{Penalty $C$} & \textbf{\# Features} & \textbf{Accuracy (\%)} & \textbf{Precision (\%)} & \textbf{Recall (\%)} & \textbf{Macro F1 (95\% CI) (\%)} \\")
print(r"    \midrule")
for row in benchmark_summary:
    print(f"    {row['Sample Size (N)']} & {row['Penalty C']} & {row['Selected Features']} & {row['Accuracy (%)']} & {row['Macro Precision (%)']} & {row['Macro Recall (%)']} & {row['Macro F1 (95% CI)']} \\\\")
print(r"    \bottomrule")
print(r"  \end{tabular}")
print(r"\end{table}")