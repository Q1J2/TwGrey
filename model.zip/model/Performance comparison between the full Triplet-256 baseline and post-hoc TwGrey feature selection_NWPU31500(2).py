import os
import random
import numpy as np
import pandas as pd
import tensorflow as tf


def build_stratified_split(root_dir, val_ratio=0.3, seed=42):
    rng = random.Random(seed)
    class_names = sorted([d for d in os.listdir(root_dir)
                          if os.path.isdir(os.path.join(root_dir, d))])
    tr_p, tr_l, va_p, va_l = [], [], [], []
    for ci, name in enumerate(class_names):
        d = os.path.join(root_dir, name)
        files = sorted([f for f in os.listdir(d)
                        if os.path.isfile(os.path.join(d, f))
                        and f.lower().endswith(('.jpg','.jpeg','.png','.bmp','.tif','.tiff'))])
        rng.shuffle(files)
        sp = int((1.0 - val_ratio) * len(files))
        for f in files[:sp]:
            tr_p.append(os.path.join(d, f)); tr_l.append(ci)
        for f in files[sp:]:
            va_p.append(os.path.join(d, f)); va_l.append(ci)
    return tr_p, tr_l, va_p, va_l, class_names


def load_or_cache_images(paths, cache_path, target_size=(128, 128)):
    if os.path.exists(cache_path):
        print(f"📂 : {cache_path}")
        return np.load(cache_path)
    print(f"🖼️ : {cache_path}")
    imgs = []
    for i, p in enumerate(paths):
        img = tf.keras.preprocessing.image.load_img(p, target_size=target_size)
        arr = tf.keras.preprocessing.image.img_to_array(img) / 255.0
        imgs.append(arr)
        if (i + 1) % 5000 == 0:
            print(f"  已读 {i+1}/{len(paths)}")
    arr = np.array(imgs, dtype=np.float32)
    np.save(cache_path, arr)
    return arr


def extract_l2_features(base_net, X_raw, batch_size=64):
    feats = base_net.predict(X_raw, batch_size=batch_size, verbose=0)
    return feats / np.clip(np.linalg.norm(feats, axis=1, keepdims=True), 1e-12, None)


# =========================================================================
# 只跑 31500
# =========================================================================
DATASET_ROOT_NWPU = r"D:\e\NWPU\NWPU-RESISC45_dataset"

data_paths = {
    31500: DATASET_ROOT_NWPU,
}

triplet_export_dir = r"D:\NWPU_Experiment\Triplet_RBF4"
bridge_export_dir = r"D:\NWPU_Experiment\BridgeFeature_256"
cache_dir = r"D:\NWPU_Experiment\image_cache"
os.makedirs(bridge_export_dir, exist_ok=True)
os.makedirs(cache_dir, exist_ok=True)

for n_samples, path in data_paths.items():
    print("\n" + "=" * 80)
    print(f"🚀 : N = {n_samples}")
    print("=" * 80)

    tr_p, tr_l, va_p, va_l, class_names = build_stratified_split(path, val_ratio=0.3, seed=42)
    print(f"📊 ={len(class_names)}, train={len(tr_p)}, val={len(va_p)}")

    X_train_raw = load_or_cache_images(tr_p, os.path.join(cache_dir, f"train_N{n_samples}.npy"))
    X_val_raw   = load_or_cache_images(va_p, os.path.join(cache_dir, f"val_N{n_samples}.npy"))
    y_train = np.array(tr_l, dtype=int)
    y_val = np.array(va_l, dtype=int)

    base_net_path = os.path.join(triplet_export_dir, f"base_net_N{n_samples}.h5")
    if not os.path.exists(base_net_path):
        print(f"⚠️  {base_net_path}。")
        continue

    base_net = tf.keras.models.load_model(base_net_path, compile=False)

    F_train = extract_l2_features(base_net, X_train_raw)
    F_val = extract_l2_features(base_net, X_val_raw)
    print(f"✅ : train={F_train.shape}, val={F_val.shape}")

    feat_cols = [f"f{i:03d}" for i in range(F_train.shape[1])]

    df_train = pd.DataFrame(F_train, columns=feat_cols); df_train["label"] = y_train
    df_val = pd.DataFrame(F_val, columns=feat_cols); df_val["label"] = y_val

    train_xlsx = os.path.join(bridge_export_dir, f"TripletFeat256_N{n_samples}_train.xlsx")
    val_xlsx = os.path.join(bridge_export_dir, f"TripletFeat256_N{n_samples}_val.xlsx")
    df_train.to_excel(train_xlsx, index=False)
    df_val.to_excel(val_xlsx, index=False)
    print(f"📦 {train_xlsx}")
    print(f"📦 {val_xlsx}")

print("\n✅ :", bridge_export_dir)