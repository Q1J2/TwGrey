import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import (
    accuracy_score,
    auc,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.svm import SVC

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}

sample_tau = {
    160: 0.120,
    400: 0.06,
    800: 0.06,
    2800: 0.06,
}

export_dir = r"D:\e\NWPU\Experiment_Plots_Comparison_RBF"
os.makedirs(export_dir, exist_ok=True)


# =========================================================================

# =========================================================================
def compute_relieff_weights(X_mat, y_vec, feature_names, k=5):
    m, n = X_mat.shape
    classes, class_counts = np.unique(y_vec, return_counts=True)
    p_c = {c: count / m for c, count in zip(classes, class_counts)}

    feat_min = np.min(X_mat, axis=0)
    feat_max = np.max(X_mat, axis=0)
    feat_span = feat_max - feat_min
    feat_span[feat_span == 0] = 1e-8

    W = np.zeros(n)

    for idx_s in range(m):
        s = X_mat[idx_s]
        cls_s = y_vec[idx_s]

        norm_diff = np.abs(X_mat - s) / feat_span
        dist_all = np.sum(norm_diff, axis=1)

        # 1. k-Nearest Hits
        same_class_mask = (y_vec == cls_s)
        same_class_indices = np.where(same_class_mask)[0]
        same_class_indices = same_class_indices[same_class_indices != idx_s]
        k_hit = min(k, len(same_class_indices))
        if k_hit == 0:
            continue
        hit_k_indices = same_class_indices[np.argsort(dist_all[same_class_indices])[:k_hit]]
        diff_hits = np.sum(np.abs(X_mat[hit_k_indices] - s) / feat_span, axis=0)

        # 2. k-Nearest Misses
        diff_misses_weighted = np.zeros(n)
        for c in classes:
            if c == cls_s:
                continue
            diff_class_indices = np.where(y_vec == c)[0]
            k_miss = min(k, len(diff_class_indices))
            if k_miss == 0:
                continue
            miss_k_indices = diff_class_indices[np.argsort(dist_all[diff_class_indices])[:k_miss]]
            diff_m_c = np.sum(np.abs(X_mat[miss_k_indices] - s) / feat_span, axis=0)

            weight_factor = p_c[c] / (1.0 - p_c[cls_s])
            diff_misses_weighted += weight_factor * (diff_m_c / k_miss)

        W = W - (diff_hits / (m * k_hit)) + (diff_misses_weighted / m)

    return dict(zip(feature_names, W))


# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )


def evaluate_model(clf, X_sub, y_true):
    y_pred = clf.predict(X_sub)
    acc = accuracy_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred, average='macro', zero_division=0)
    prec = precision_score(y_true, y_pred, average='macro', zero_division=0)
    f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    return acc, rec, prec, f1


def compute_maf1_confidence_interval(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes)
    n = len(y_true)

    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)

    p_hat = cm / n
    p_row = np.sum(p_hat, axis=1)
    p_col = np.sum(p_hat, axis=0)
    p_diag = np.diag(p_hat)

    denom = p_row + p_col
    valid_mask = denom > 0

    F1_i = np.zeros(r)
    F1_i[valid_mask] = 2.0 * p_diag[valid_mask] / denom[valid_mask]
    maF1 = np.mean(F1_i)

    diff_p = denom - 2.0 * p_diag

    A_terms = np.zeros(r)
    for i in range(r):
        if denom[i] > 0:
            term1 = (F1_i[i] * diff_p[i]) / (denom[i] ** 2)
            term2 = (diff_p[i] / denom[i]) + (F1_i[i] / 2.0)
            A_terms[i] = term1 * term2
    A = np.sum(A_terms)

    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p_hat[i, j] * F1_i[i] * F1_i[j]) / (denom[i] * denom[j])

    var_maF1 = (2.0 / (n * (r ** 2))) * (A + B)
    se_maF1 = np.sqrt(max(0.0, var_maF1))

    z = norm.ppf(1.0 - alpha / 2.0)
    ci_lower = max(0.0, maF1 - z * se_maF1)
    ci_upper = min(1.0, maF1 + z * se_maF1)

    return maF1, se_maF1, (ci_lower, ci_upper)


# =========================================================================

# =========================================================================
benchmark_summary = []
roc_plot_data = {}

for n_samples, path in data_paths.items():
    current_tau = sample_tau[n_samples]
    print("\n" + "=" * 80)
    print(f"🚀 : N = {n_samples} | tau = {current_tau:.3f} |  7:3 ")
    print(f"📂 : {path}")
    print("=" * 80)

    df = pd.read_excel(path)
    feature_names = list(df.columns[:-1])
    X_raw = df.iloc[:, :-1]
    y_raw = df.iloc[:, -1]

    
    X_train_df, X_val_df, y_train, y_val = train_test_split(
        X_raw, y_raw, test_size=0.30, random_state=42, stratify=y_raw
    )
    print(f"📊  = {len(y_train)},  = {len(y_val)}")

    
    print(f"⏳ ReliefF ( k=5)...")
    feature_importances = compute_relieff_weights(
        X_train_df.values, y_train.values, feature_names, k=5
    )

    
    selected_features = [f for f, w in feature_importances.items() if w >= current_tau]

    if len(selected_features) == 0:
        top_f = max(feature_importances, key=feature_importances.get)
        selected_features.append(top_f)
        print(f"   ⚠️ : [{top_f}]")

    print(f"📌 ReliefF : {len(selected_features)} / {len(feature_names)}")
    print(f"   : {selected_features}")

    
    X_train_selected = X_train_df[selected_features].values
    svm = create_svm()
    svm.fit(X_train_selected, y_train)

   
    X_val_selected = X_val_df[selected_features].values
    acc, rec, prec, f1 = evaluate_model(svm, X_val_selected, y_val)

    
    y_pred = svm.predict(X_val_selected)
    y_proba = svm.predict_proba(X_val_selected)

    
    y_val_bin = label_binarize(y_val, classes=svm.classes_)
    n_classes = len(svm.classes_)
    all_fpr = np.unique(np.concatenate([roc_curve(y_val_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_val_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

   
    if n_samples == 160:
        np.savez(
            os.path.join(export_dir, "roc_data_160_ReliefF5.npz"),
            y_true=y_val.values,
            y_proba=y_proba,
            classes=svm.classes_,
        )
        print(f"📦 : roc_data_160_ReliefF5.npz")

  
    maf1_val, se_val, (ci_low, ci_high) = compute_maf1_confidence_interval(y_val.values, y_pred, alpha=0.05)

    roc_plot_data[n_samples] = {
        'y_true': y_val.values,
        'y_proba': y_proba,
        'classes': svm.classes_
    }

    print(f"🏆 : Accuracy = {acc * 100:.2f}%, Macro F1 = {f1 * 100:.2f}% (SE={se_val:.4f}) | Macro-AUC = {macro_auc:.4f}")
    print(f"🔒 Macro F1 95% : [{ci_low * 100:.2f}%, {ci_high * 100:.2f}%]")

    benchmark_summary.append({
        "Sample Size (N)": n_samples,
        "tau": f"{current_tau:.3f}",
        "Penalty C": 1.0,
        "Selected Features": len(selected_features),
        "Accuracy (%)": f"{acc * 100:.2f}",
        "Macro Precision (%)": f"{prec * 100:.2f}",
        "Macro Recall (%)": f"{rec * 100:.2f}",
        "Macro F1 (%)": f"{f1 * 100:.2f}",
        "Macro F1 (95% CI)": f"{f1 * 100:.2f} [{ci_low * 100:.2f}, {ci_high * 100:.2f}]",
        "Macro-AUC": f"{macro_auc:.4f}",
        "raw_f1": f1 * 100,
        "raw_ci_low": ci_low * 100,
        "raw_ci_high": ci_high * 100,
        "raw_se": se_val * 100
    })


# =========================================================================

fig, ax = plt.subplots(figsize=(6.5, 4.2))
scales = [row["Sample Size (N)"] for row in benchmark_summary]
f1_vals = [row["raw_f1"] for row in benchmark_summary]
yerr_low = [row["raw_f1"] - row["raw_ci_low"] for row in benchmark_summary]
yerr_high = [row["raw_ci_high"] - row["raw_f1"] for row in benchmark_summary]

ax.errorbar(
    range(len(scales)), f1_vals, yerr=[yerr_low, yerr_high],
    fmt='-s', color='#2ca02c', ecolor='#d62728', elinewidth=2, capsize=5, capthick=1.5,
    markersize=6, label='Macro-F1 with 95% CI (Independent Test Set)'
)
ax.set_xticks(range(len(scales)))
ax.set_xticklabels([f"N={s}" for s in scales])
ax.set_xlabel('Sample scale (N)', fontsize=12)
ax.set_ylabel('Macro-F1 score (%)', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.5)
ax.legend(loc='lower right')
plt.tight_layout()

ci_plot_pdf = os.path.join(export_dir, "ReliefF_MacroF1_Confidence_Interval5.pdf")
ci_plot_png = os.path.join(export_dir, "ReliefF_MacroF1_Confidence_Interval5.png")
plt.savefig(ci_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(ci_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig, ax = plt.subplots(figsize=(6.5, 5))
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

for idx, (n_samples, data) in enumerate(roc_plot_data.items()):
    y_true_bin = label_binarize(data['y_true'], classes=data['classes'])
    y_proba = data['y_proba']
    n_classes = len(data['classes'])

    all_fpr = np.unique(np.concatenate([roc_curve(y_true_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_true_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

    ax.plot(all_fpr, mean_tpr, color=colors[idx % len(colors)], lw=2,
            label=f'N = {n_samples} (Macro-AUC = {macro_auc:.4f})')

ax.plot([0, 1], [0, 1], 'k--', lw=1.2, label='Random chance')
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('False positive rate', fontsize=12)
ax.set_ylabel('True positive rate', fontsize=12)
ax.legend(loc='lower right', fontsize=10)
ax.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()

roc_plot_pdf = os.path.join(export_dir, "ReliefF_ROC_Curves5.pdf")
roc_plot_png = os.path.join(export_dir, "ReliefF_ROC_Curves5.png")
plt.savefig(roc_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(roc_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()



# =========================================================================

# =========================================================================
df_summary = pd.DataFrame(benchmark_summary)
print("\n" + "=" * 120)

print("=" * 120)
print(df_summary[["Sample Size (N)", "tau", "Penalty C", "Selected Features", "Accuracy (%)", "Macro Precision (%)", "Macro Recall (%)", "Macro F1 (95% CI)", "Macro-AUC"]].to_string(index=False))


print(r"\begin{table}[htbp]")
print(r"  \centering")
print(r"  \small")
print(r"  \caption{Performance of standard ReliefF across different sample scales with adaptive $\tau$ on independent test partition ($70\%/30\%$ split) on NWPU-RESISC45}")
print(r"  \label{tab:relieff_scale_results}")
print(r"  \begin{tabular}{cccccccc}")
print(r"    \toprule")
print(r"    \textbf{Sample Size ($N$)} & $\tau$ & \textbf{Penalty $C$} & \textbf{\# Features} & \textbf{Accuracy (\%)} & \textbf{Precision (\%)} & \textbf{Recall (\%)} & \textbf{Macro F1 (95\% CI) (\%)} \\")
print(r"    \midrule")
for row in benchmark_summary:
    print(f"    {row['Sample Size (N)']} & {row['tau']} & {row['Penalty C']} & {row['Selected Features']} & {row['Accuracy (%)']} & {row['Macro Precision (%)']} & {row['Macro Recall (%)']} & {row['Macro F1 (95% CI)']} \\\\")
print(r"    \bottomrule")
print(r"  \end{tabular}")
print(r"  \vspace{1.0ex}")
print(r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont \textit{Note:} Feature weights and threshold filtering ($W \ge \tau$) are trained strictly on $70\%$ stratified training partitions. All reported metrics, 95\% confidence intervals, and Macro-AUC values are evaluated on mutually exclusive $30\%$ test sets using RBF-kernel SVM.}")
print(r"\end{table}")