import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.metrics import (
    accuracy_score,
    auc,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import label_binarize
from sklearn.svm import SVC

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}

# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
        tol=1e-3
    )

def evaluate_model(clf, X_sub, y_true):
    y_pred = clf.predict(X_sub)
    acc = accuracy_score(y_true, y_pred)
    rec = recall_score(y_true, y_pred, average='macro', zero_division=0)
    prec = precision_score(y_true, y_pred, average='macro', zero_division=0)
    f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    return acc, rec, prec, f1

def compute_maf1_confidence_interval(y_true, y_pred, alpha=0.05):
    classes = np.unique(np.concatenate([y_true, y_pred]))
    r = len(classes)
    n = len(y_true)

    cm = confusion_matrix(y_true, y_pred, labels=classes).T.astype(float)

    p_hat = cm / n
    p_row = np.sum(p_hat, axis=1)
    p_col = np.sum(p_hat, axis=0)
    p_diag = np.diag(p_hat)

    denom = p_row + p_col
    valid_mask = denom > 0

    F1_i = np.zeros(r)
    F1_i[valid_mask] = 2.0 * p_diag[valid_mask] / denom[valid_mask]
    maF1 = np.mean(F1_i)

    diff_p = denom - 2.0 * p_diag

    A_terms = np.zeros(r)
    for i in range(r):
        if denom[i] > 0:
            term1 = (F1_i[i] * diff_p[i]) / (denom[i] ** 2)
            term2 = (diff_p[i] / denom[i]) + (F1_i[i] / 2.0)
            A_terms[i] = term1 * term2
    A = np.sum(A_terms)

    B = 0.0
    for i in range(r):
        for j in range(r):
            if i != j and denom[i] > 0 and denom[j] > 0:
                B += (p_hat[i, j] * F1_i[i] * F1_i[j]) / (denom[i] * denom[j])

    var_maF1 = (2.0 / (n * (r ** 2))) * (A + B)
    se_maF1 = np.sqrt(max(0.0, var_maF1))

    z = norm.ppf(1.0 - alpha / 2.0)
    ci_lower = max(0.0, maF1 - z * se_maF1)
    ci_upper = min(1.0, maF1 + z * se_maF1)

    return maF1, se_maF1, (ci_lower, ci_upper)

# =========================================================================

# =========================================================================
benchmark_summary = []
roc_plot_data = {}

for n_samples, path in data_paths.items():
    print("\n" + "=" * 80)
    print(f"🚀 : N = {n_samples} |  (C = 1.0)")
    print(f"📂 : {path}")
    print("=" * 80)

    df = pd.read_excel(path)
    X_raw = df.iloc[:, :-1].values
    y_raw = df.iloc[:, -1].values

    num_total_features = X_raw.shape[1]

    
    X_train_feats, X_val_feats, y_train, y_val = train_test_split(
        X_raw, y_raw, test_size=0.30, random_state=42, stratify=y_raw
    )
    print(f"📊 = {len(y_train)},  = {len(y_val)},  = {num_total_features}")

    
    svm = create_svm()
    svm.fit(X_train_feats, y_train)

    
    acc, rec, prec, f1 = evaluate_model(svm, X_val_feats, y_val)
    y_pred = svm.predict(X_val_feats)
    y_proba = svm.predict_proba(X_val_feats)

    
    maf1_val, se_val, (ci_low, ci_high) = compute_maf1_confidence_interval(y_val, y_pred, alpha=0.05)

    
    y_val_bin = label_binarize(y_val, classes=svm.classes_)
    n_classes = len(svm.classes_)
    all_fpr = np.unique(np.concatenate([roc_curve(y_val_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_val_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

  
    if n_samples == 160:
        export_npz_dir = r"D:\e\NWPU\Experiment_Plots_Comparison"
        os.makedirs(export_npz_dir, exist_ok=True)
        npz_save_path = os.path.join(export_npz_dir, "roc_data_160_RawSVM.npz")
        np.savez(
            npz_save_path,
            y_true=y_val,
            y_proba=y_proba,
            classes=svm.classes_
        )
        

    roc_plot_data[n_samples] = {
        'y_true': y_val,
        'y_proba': y_proba,
        'classes': svm.classes_
    }

    print(f"🏆 : Accuracy = {acc * 100:.2f}%, Macro F1 = {f1 * 100:.2f}% (SE={se_val:.4f}) | Macro-AUC = {macro_auc:.4f}")
    print(f"🔒  Macro F1 95%: [{ci_low * 100:.2f}%, {ci_high * 100:.2f}%]")

    benchmark_summary.append({
        "Sample Size (N)": n_samples,
        "Penalty C": 1.0,
        "Total Features": num_total_features,
        "Accuracy (%)": f"{acc * 100:.2f}",
        "Macro Precision (%)": f"{prec * 100:.2f}",
        "Macro Recall (%)": f"{rec * 100:.2f}",
        "Macro F1 (%)": f"{f1 * 100:.2f}",
        "Macro F1 (95% CI)": f"{f1 * 100:.2f} [{ci_low * 100:.2f}, {ci_high * 100:.2f}]",
        "Macro-AUC": f"{macro_auc:.4f}",
        "raw_f1": f1 * 100,
        "raw_ci_low": ci_low * 100,
        "raw_ci_high": ci_high * 100,
        "raw_se": se_val * 100
    })

# =========================================================================

# =========================================================================
export_dir = r"D:\e\NWPU\Experiment_Plots_RawSVM"
os.makedirs(export_dir, exist_ok=True)


fig, ax = plt.subplots(figsize=(6.5, 4.2))
scales = [row["Sample Size (N)"] for row in benchmark_summary]
f1_vals = [row["raw_f1"] for row in benchmark_summary]
yerr_low = [row["raw_f1"] - row["raw_ci_low"] for row in benchmark_summary]
yerr_high = [row["raw_ci_high"] - row["raw_f1"] for row in benchmark_summary]

ax.errorbar(
    range(len(scales)), f1_vals, yerr=[yerr_low, yerr_high],
    fmt='-o', color='#333333', ecolor='#d62728', elinewidth=2, capsize=5, capthick=1.5,
    markersize=6, label='Macro-F1 with 95% CI (SVM, Independent test set)'
)
ax.set_xticks(range(len(scales)))
ax.set_xticklabels([f"N={s}" for s in scales])
ax.set_xlabel('Sample scale (N)', fontsize=12)
ax.set_ylabel('Macro-F1 score (%)', fontsize=12)
ax.grid(True, linestyle='--', alpha=0.5)
ax.legend(loc='lower right')
plt.tight_layout()

ci_plot_pdf = os.path.join(export_dir, "RawSVM_MacroF1_Confidence_Interval.pdf")
ci_plot_png = os.path.join(export_dir, "RawSVM_MacroF1_Confidence_Interval.png")
plt.savefig(ci_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(ci_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


fig, ax = plt.subplots(figsize=(6.5, 5))
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

for idx, (n_samples, data) in enumerate(roc_plot_data.items()):
    y_true_bin = label_binarize(data['y_true'], classes=data['classes'])
    y_proba = data['y_proba']
    n_classes = len(data['classes'])

    all_fpr = np.unique(np.concatenate([roc_curve(y_true_bin[:, i], y_proba[:, i])[0] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr_i, tpr_i, _ = roc_curve(y_true_bin[:, i], y_proba[:, i])
        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)
    mean_tpr /= n_classes
    macro_auc = auc(all_fpr, mean_tpr)

    ax.plot(all_fpr, mean_tpr, color=colors[idx % len(colors)], lw=2,
            label=f'N = {n_samples} (Macro-AUC = {macro_auc:.4f})')

ax.plot([0, 1], [0, 1], 'k--', lw=1.2, label='Random chance')
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('False positive rate', fontsize=12)
ax.set_ylabel('True positive rate', fontsize=12)
ax.legend(loc='lower right', fontsize=10)
ax.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()

roc_plot_pdf = os.path.join(export_dir, "RawSVM_ROC_Curves.pdf")
roc_plot_png = os.path.join(export_dir, "RawSVM_ROC_Curves.png")
plt.savefig(roc_plot_pdf, format='pdf', bbox_inches='tight')
plt.savefig(roc_plot_png, dpi=FIG_DPI, bbox_inches='tight')
plt.close()


# =========================================================================
df_summary = pd.DataFrame(benchmark_summary)
print("\n" + "=" * 120)
print("=" * 120)
print(df_summary[["Sample Size (N)", "Penalty C", "Total Features", "Accuracy (%)", "Macro Precision (%)", "Macro Recall (%)", "Macro F1 (95% CI)", "Macro-AUC"]].to_string(index=False))


print(r"\begin{table}[htbp]")
print(r"  \centering")
print(r"  \small")
print(r"  \caption{Classification performance of raw full features using SVM across different sample scales ($C=1.0$) on independent test partition ($70\%/30\%$ split) on NWPU-RESISC45}")
print(r"  \label{tab:raw_svm_scale_results}")
print(r"  \begin{tabular}{cccccccc}")
print(r"    \toprule")
print(r"    \textbf{Sample Size ($N$)} & \textbf{Penalty $C$} & \textbf{Total Features} & \textbf{Accuracy (\%)} & \textbf{Precision (\%)} & \textbf{Recall (\%)} & \textbf{Macro F1 (95\% CI) (\%)} & \textbf{Macro-AUC} \\")
print(r"    \midrule")
for row in benchmark_summary:
    print(f"    {row['Sample Size (N)']} & {row['Penalty C']} & {row['Total Features']} & {row['Accuracy (%)']} & {row['Macro Precision (%)']} & {row['Macro Recall (%)']} & {row['Macro F1 (95% CI)']} & {row['Macro-AUC']} \\\\")
print(r"    \bottomrule")
print(r"  \end{tabular}")
print(r"  \vspace{1.0ex}")
print(r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont \textit{Note:} SVM is fitted strictly on $70\%$ stratified training partitions. All reported metrics, 95\% confidence intervals, and Macro-AUC values are evaluated on mutually exclusive $30\%$ test partitions.}")
print(r"\end{table}")