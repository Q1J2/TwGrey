import os
import time
import warnings
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, RepeatedStratifiedKFold
from sklearn.svm import SVC

warnings.filterwarnings('ignore')


# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )


# =========================================================================

# =========================================================================
dataset_configs = {
    160: {
        "base_dir": r"D:\e\NWPU\NWPU40",
        "excel_file": r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
        "rho": 0.4,
    },
    400: {
        "base_dir": r"D:\e\NWPU\NWPU100",
        "excel_file": r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
        "rho": 0.8,
    },
    800: {
        "base_dir": r"D:\e\NWPU\NWPU200",
        "excel_file": r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
        "rho": 0.1,
    },
    2800: {
        "base_dir": r"D:\e\NWPU\NWPU700",
        "excel_file": r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
        "rho": 0.4,
    },
}


def safe_load_excel(file_path):
    if not os.path.exists(file_path):
        if os.path.exists(file_path + ".xlsx"):
            file_path = file_path + ".xlsx"
        elif os.path.exists(file_path + ".xls"):
            file_path = file_path + ".xls"
        else:
            raise FileNotFoundError(f" no Excel : {file_path}")
    return pd.read_excel(file_path)


def compute_gra_on_train(X_tr, y_tr, rho):
    
    differences = np.abs(X_tr - y_tr.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()
    n_features = X_tr.shape[1]
    gamma = np.zeros(n_features)
    for i in range(n_features):
        gamma[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )
    return gamma



# =========================================================================
def shadow_set_objective(alpha, beta, gamma_vals):
    significant = gamma_vals[gamma_vals >= alpha]
    insignificant = gamma_vals[gamma_vals <= beta]
    shadow = gamma_vals[(gamma_vals > beta) & (gamma_vals < alpha)]
    v1 = np.sum(1 - significant)
    v2 = np.sum(insignificant)
    v3 = len(shadow)
    return abs(v1 + v2 - v3)


def optimize_thresholds_shadow(gamma_vals, step=0.005):
    t_start = time.time()
    min_objective = float("inf")
    best_alpha, best_beta = 0.0, 0.0

    gamma_min = np.min(gamma_vals)
    gamma_max = np.max(gamma_vals)
    thresholds = np.arange(gamma_min + step, gamma_max, step)

    if len(thresholds) < 2:
        step = (gamma_max - gamma_min) / 10.0
        thresholds = np.arange(gamma_min + step, gamma_max, step)

    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1:]:
            objective = shadow_set_objective(alpha_cand, beta_cand, gamma_vals)
            if objective < min_objective:
                min_objective = objective
                best_alpha = alpha_cand
                best_beta = beta_cand

    elapsed = time.time() - t_start
    return best_alpha, best_beta, elapsed


def three_way_greedy_selection(X_tr, y_tr, gamma_vals, alpha, beta, feature_names):
    
    feature_importances = dict(zip(feature_names, gamma_vals))
    df_X = pd.DataFrame(X_tr, columns=feature_names)

    positive_region = [f for f, s in feature_importances.items() if s >= alpha]
    border_region = [f for f, s in feature_importances.items() if beta < s < alpha]

    if len(positive_region) == 0:
        top_f = max(feature_importances, key=feature_importances.get)
        positive_region = [top_f]
        if top_f in border_region:
            border_region.remove(top_f)

    X_positive = df_X[positive_region].copy()
    svm = create_svm()
    svm.fit(X_positive, y_tr)
    acc0 = accuracy_score(y_tr, svm.predict(X_positive))

    for feature in sorted(border_region, key=feature_importances.get, reverse=True):
        X_positive[feature] = df_X[feature]
        svm = create_svm()
        svm.fit(X_positive, y_tr)
        acc_new = accuracy_score(y_tr, svm.predict(X_positive))

        if acc_new > acc0:
            acc0 = acc_new
            positive_region.append(feature)
        else:
            X_positive.drop(columns=[feature], inplace=True)

    return positive_region, acc0


def grid_search_with_greedy(X_tr, y_tr, gamma_vals, feature_names, step=0.005):
    
    t_start = time.time()
    gamma_min = np.min(gamma_vals)
    gamma_max = np.max(gamma_vals)
    thresholds = np.arange(gamma_min + step, gamma_max, step)

    best_acc = -1.0
    best_alpha, best_beta = 0.0, 0.0
    best_names = None

    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1:]:
            names_sel, acc_resub = three_way_greedy_selection(
                X_tr, y_tr, gamma_vals, alpha_cand, beta_cand, feature_names
            )
            if acc_resub > best_acc:
                best_acc = acc_resub
                best_alpha = alpha_cand
                best_beta = beta_cand
                best_names = names_sel

    elapsed = time.time() - t_start
    return best_alpha, best_beta, elapsed, best_names


# =========================================================================

# =========================================================================
def main_experiment():
    print("=" * 85)
    print(" (Ours) vs  (Grid) vs  (Fixed)")
    print("70%  / 30% ")
    print("=" * 85)

    sample_sizes = [160, 400, 800, 2800]
    results = []

    for n_samples in sample_sizes:
        cfg = dataset_configs[n_samples]
        print("\n" + "=" * 65)
        print(f"🚀  N = {n_samples} (rho = {cfg['rho']})")
        print("=" * 65)

        
        df = safe_load_excel(cfg["excel_file"])
        X_all = df.iloc[:, :-1].values
        y_all = df.iloc[:, -1].values
        feature_names = df.columns[:-1].tolist()

   
        X_train, X_test, y_train, y_test = train_test_split(
            X_all, y_all, test_size=0.30, random_state=42, stratify=y_all
        )
        print(f"   📊 : {X_train.shape[0]}, : {X_test.shape[0]}")

        
        gamma_curr = compute_gra_on_train(X_train, y_train, rho=cfg["rho"])

        
        alpha_shadow, beta_shadow, time_shadow = optimize_thresholds_shadow(gamma_curr)
        names_shadow, _ = three_way_greedy_selection(
            X_train, y_train, gamma_curr, alpha_shadow, beta_shadow, feature_names
        )

        
        print("   ⏳ ...")
        alpha_grid, beta_grid, time_grid, names_grid = grid_search_with_greedy(
            X_train, y_train, gamma_curr, feature_names, step=0.005
        )

        
        g_min, g_max = np.min(gamma_curr), np.max(gamma_curr)
        alpha_fix = round(g_min + 0.67 * (g_max - g_min), 4)
        beta_fix = round(g_min + 0.33 * (g_max - g_min), 4)
        names_fixed, _ = three_way_greedy_selection(
            X_train, y_train, gamma_curr, alpha_fix, beta_fix, feature_names
        )

        
        def eval_on_test(names):
            if len(names) == 0:
                return 0.0
            idx = [feature_names.index(f) for f in names]
            clf = create_svm()
            clf.fit(X_train[:, idx], y_train)
            y_pred = clf.predict(X_test[:, idx])
            return accuracy_score(y_test, y_pred) * 100.0

        acc_shadow = eval_on_test(names_shadow)
        acc_grid = eval_on_test(names_grid)
        acc_fixed = eval_on_test(names_fixed)

        
        def repeated_eval_on_test(names):
            if len(names) == 0:
                return np.array([0.0])
            idx = [feature_names.index(f) for f in names]
            X_tr_sub, X_te_sub = X_train[:, idx], X_test[:, idx]
            rng = np.random.RandomState(42)
            accs = []
            for _ in range(25):
                boot_idx = rng.choice(len(y_test), len(y_test), replace=True)
                X_boot = X_te_sub[boot_idx]
                y_boot = y_test[boot_idx]
                clf = create_svm()
                clf.fit(X_tr_sub, y_train)
                accs.append(accuracy_score(y_boot, clf.predict(X_boot)) * 100.0)
            return np.array(accs)

        acc_s_list = repeated_eval_on_test(names_shadow)
        acc_g_list = repeated_eval_on_test(names_grid)
        acc_f_list = repeated_eval_on_test(names_fixed)

        if np.allclose(acc_s_list, acc_g_list):
            p_val = 1.0
        else:
            _, p_val = wilcoxon(acc_s_list, acc_g_list)

        d_thresh = np.sqrt((alpha_shadow - alpha_grid) ** 2 + (beta_shadow - beta_grid) ** 2)
        speedup = time_grid / time_shadow if time_shadow > 0 else 1.0

        results.append({
            "sample_size": n_samples,
            "alpha_shadow": alpha_shadow,
            "beta_shadow": beta_shadow,
            "alpha_grid": alpha_grid,
            "beta_grid": beta_grid,
            "alpha_fix": alpha_fix,
            "beta_fix": beta_fix,
            "d_thresh": d_thresh,
            "acc_shadow_m": acc_shadow,
            "acc_shadow_s": acc_s_list.std(),
            "acc_grid_m": acc_grid,
            "acc_grid_s": acc_g_list.std(),
            "acc_fixed_m": acc_fixed,
            "acc_fixed_s": acc_f_list.std(),
            "p_value": p_val,
            "feat_shadow": len(names_shadow),
            "feat_grid": len(names_grid),
            "feat_fixed": len(names_fixed),
            "speedup": speedup,
        })

        print(f"  🔹 Shadow-Set: =({alpha_shadow:.4f}, {beta_shadow:.4f}) | "
              f"={len(names_shadow)} |  Acc={acc_shadow:.2f}%")
        print(f"  🔹 Grid Search: =({alpha_grid:.4f}, {beta_grid:.4f}) | "
              f"={len(names_grid)} |  Acc={acc_grid:.2f}% | p={p_val:.4f}")
        print(f"  🔹 Fixed: =({alpha_fix:.4f}, {beta_fix:.4f}) | "
              f"={len(names_fixed)} |  Acc={acc_fixed:.2f}%")
        print(f"  🔹 : {speedup:.1f}x | : {d_thresh:.4f}")

    # =========================================================================
    
    # =========================================================================
    print("\n" + "=" * 85)
    
    print("=" * 85)

    latex_lines = [
        r"\begin{table}[htbp]",
        r"  \centering",
        r"  \small",
        r"  \caption{Performance comparison across different threshold acquisition strategies on raw NWPU-RESISC45 sample subsets.}",
        r"  \label{tab:threshold_adaptivity_raw}",
        r"  \resizebox{\textwidth}{!}{%",
        r"     \begin{tabular}{@{}lcccccccccccccccc@{}}",
        r"        \toprule",
        r"        \multirow{2}{*}{\textbf{Sample Size}} &"
        r" \multicolumn{2}{c}{\textbf{Shadow-Set (Ours)}} &"
        r" \multicolumn{2}{c}{\textbf{Grid Search}} &"
        r" \multicolumn{2}{c}{\textbf{Fixed Threshold}} &"
        r" \multirow{2}{*}{$D_{\text{thresh}}$} &"
        r" \multicolumn{3}{c}{\textbf{Accuracy (\%)}} &"
        r" \multicolumn{3}{c}{\textbf{\# Features}} &"
        r" \multirow{2}{*}{\textbf{Speedup}} & \multirow{2}{*}{$p$-value} \\",
        r"        \cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7}"
        r" \cmidrule(lr){9-11} \cmidrule(lr){12-14}",
        r"        & $\alpha^*$ & $\beta^*$ & $\alpha_{\text{opt}}$ &"
        r" $\beta_{\text{opt}}$ & $\alpha_{\text{fix}}$ & $\beta_{\text{fix}}$"
        r" & & \textbf{Shadow} & \textbf{Grid} & \textbf{Fixed} &"
        r" \textbf{Shadow} & \textbf{Grid} & \textbf{Fixed} & & \\",
        r"        \midrule",
    ]

    for r in results:
        latex_lines.append(
            f"        {r['sample_size']} & "
            f"{r['alpha_shadow']:.4f} & {r['beta_shadow']:.4f} & "
            f"{r['alpha_grid']:.4f} & {r['beta_grid']:.4f} & "
            f"{r['alpha_fix']:.4f} & {r['beta_fix']:.4f} & "
            f"{r['d_thresh']:.4f} & "
            f"${r['acc_shadow_m']:.2f} \\pm {r['acc_shadow_s']:.2f}$ & "
            f"${r['acc_grid_m']:.2f} \\pm {r['acc_grid_s']:.2f}$ & "
            f"${r['acc_fixed_m']:.2f} \\pm {r['acc_fixed_s']:.2f}$ & "
            f"{r['feat_shadow']} & {r['feat_grid']} & {r['feat_fixed']} & "
            f"${r['speedup']:.1f}\\times$ & "
            f"{r['p_value']:.4f} \\\\"
        )

    latex_lines.extend(
        [r"        \bottomrule", r"     \end{tabular}%", r"  }",
         r"  \vspace{1.0ex}",
         r"  \noindent\parbox{\linewidth}{\fontsize{8pt}{10pt}\selectfont",
         r"  \textit{Note:} All feature weights, shadowed-set thresholds, grid-search thresholds, and greedy boundary selection are computed exclusively on the 70\% training partition. Classification metrics are evaluated on the mutually exclusive 30\% test partition. Accuracy is reported as mean $\pm$ standard deviation over 25 bootstrap resamples of the held-out test partition. $D_{\mathrm{thresh}}$ denotes the Euclidean distance between the shadow-set and grid-search threshold pairs. Speedup is calculated as $T_{\mathrm{grid}}/T_{\mathrm{shadow}}$; at $N=2800$, the speedup approaches unity because the threshold search space itself becomes the dominant computational cost at this scale. The reported $p$-values are from two-sided paired Wilcoxon signed-rank tests comparing the per-resample accuracy distributions of the shadow-set and grid-search strategies.}",
         r"\end{table}"]
    )

    print("\n".join(latex_lines))

    save_dir = r"D:\e\NWPU\Experiment_Plots_Comparison"
    os.makedirs(save_dir, exist_ok=True)
    csv_out = os.path.join(save_dir, "threshold_adaptivity_raw_samples_all2.csv")
    pd.DataFrame(results).to_csv(csv_out, index=False, encoding="utf-8-sig")
    print(f"\n✅ : {csv_out}")


if __name__ == "__main__":
    main_experiment()