import os
import warnings
import numpy as np
import pandas as pd
from scipy.stats import ttest_rel, wilcoxon
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.svm import SVC

warnings.filterwarnings('ignore')


# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )


# =========================================================================

# =========================================================================
dataset_configs = {
    160: {
        "file": r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
        "rho": 0.4,
        "tau_relief": 0.120,
        "alpha_beta_twrelief": (0.0900, 0.0300),
        "alpha_beta_twgrey": (0.5810, 0.5660),
    },
    400: {
        "file": r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
        "rho": 0.8,
        "tau_relief": 0.060,
        "alpha_beta_twrelief": (0.0900, 0.0300),
        "alpha_beta_twgrey": (0.7428, 0.7378),
    },
    800: {
        "file": r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
        "rho": 0.1,
        "tau_relief": 0.060,
        "alpha_beta_twrelief": (0.0900, 0.0300),
        "alpha_beta_twgrey": (0.3844, 0.3694),
    },
    2800: {
        "file": r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
        "rho": 0.4,
        "tau_relief": 0.060,
        "alpha_beta_twrelief": (0.0900, 0.0300),
        "alpha_beta_twgrey": (0.7630, 0.7580),
    },
}


# =========================================================================

# =========================================================================
def compute_gra_weights(X_mat, y_vec, rho):
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()
    gamma = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        gamma[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )
    return gamma


def compute_relieff_weights(X_mat, y_vec, feature_names=None, r=100, k=5):
  
    m, n = X_mat.shape
    classes, class_counts = np.unique(y_vec, return_counts=True)
    p_c = {c: count / m for c, count in zip(classes, class_counts)}

    feat_min = np.min(X_mat, axis=0)
    feat_max = np.max(X_mat, axis=0)
    feat_span = feat_max - feat_min
    feat_span[feat_span == 0] = 1e-8

    W = np.zeros(n)
    np.random.seed(42)

    actual_r = min(r, m)

    for _ in range(actual_r):
        idx_s = np.random.randint(0, m)
        s = X_mat[idx_s]
        cls_s = y_vec[idx_s]

        norm_diff = np.abs(X_mat - s) / feat_span
        dist_all = np.sum(norm_diff, axis=1)

        # 1. k-Near Hits
        same_class_mask = (y_vec == cls_s)
        same_class_indices = np.where(same_class_mask)[0]
        same_class_indices = same_class_indices[same_class_indices != idx_s]
        k_hit = min(k, len(same_class_indices))
        if k_hit == 0:
            continue
        hit_k_indices = same_class_indices[np.argsort(dist_all[same_class_indices])[:k_hit]]
        diff_hits = np.sum(np.abs(X_mat[hit_k_indices] - s) / feat_span, axis=0)

        # 2. k-Near Misses
        diff_misses_weighted = np.zeros(n)
        for c in classes:
            if c == cls_s:
                continue
            diff_class_indices = np.where(y_vec == c)[0]
            k_miss = min(k, len(diff_class_indices))
            if k_miss == 0:
                continue
            miss_k_indices = diff_class_indices[np.argsort(dist_all[diff_class_indices])[:k_miss]]
            diff_m_c = np.sum(np.abs(X_mat[miss_k_indices] - s) / feat_span, axis=0)
            diff_misses_weighted += (p_c[c] / (1.0 - p_c[cls_s])) * (diff_m_c / k_miss)

        W = W - (diff_hits / (actual_r * k_hit)) + (diff_misses_weighted / actual_r)

    if feature_names is not None:
        return dict(zip(feature_names, W))
    return W


def three_way_greedy_selection(X_mat, y_vec, weights, alpha, beta):
    pos_region = [i for i, w in enumerate(weights) if w >= alpha]
    border_region = [i for i, w in enumerate(weights) if beta < w < alpha]

    if len(pos_region) == 0:
        top_f = int(np.argmax(weights))
        pos_region.append(top_f)
        if top_f in border_region:
            border_region.remove(top_f)

    svm = create_svm()
    svm.fit(X_mat[:, pos_region], y_vec)
    acc0 = accuracy_score(y_vec, svm.predict(X_mat[:, pos_region]))

    for feature in sorted(border_region, key=lambda idx: weights[idx], reverse=True):
        cand_region = pos_region + [feature]
        temp_svm = create_svm()
        temp_svm.fit(X_mat[:, cand_region], y_vec)
        acc_cand = accuracy_score(y_vec, temp_svm.predict(X_mat[:, cand_region]))
        if acc_cand > acc0:
            acc0 = acc_cand
            pos_region.append(feature)

    return pos_region


# =========================================================================

# =========================================================================
def run_significance_evaluation(cfg, K=10, verbose=True):
    df = pd.read_excel(cfg["file"])
    X_all = df.iloc[:, :-1].values
    y_all = df.iloc[:, -1].values
    n_features = X_all.shape[1]

    X_train, X_test, y_train, y_test = train_test_split(
        X_all, y_all, test_size=0.30, random_state=42, stratify=y_all
    )

    
    w_rf_train = compute_relieff_weights(X_train, y_train, r=100, k=5)
    w_gra_train = compute_gra_weights(X_train, y_train, rho=cfg["rho"])

    feats_nosel = list(range(n_features))

    feats_rf = [i for i, w in enumerate(w_rf_train) if w >= cfg["tau_relief"]]
    if not feats_rf:
        feats_rf = [int(np.argmax(w_rf_train))]

    a_rf, b_rf = cfg["alpha_beta_twrelief"]
    feats_twrf = three_way_greedy_selection(X_train, y_train, w_rf_train, a_rf, b_rf)

    a_g, b_g = cfg["alpha_beta_twgrey"]
    feats_twgrey = three_way_greedy_selection(X_train, y_train, w_gra_train, a_g, b_g)

    def eval_on_test_bootstrap(feats, seed):
        rng = np.random.RandomState(seed)
        boot_idx = rng.choice(len(y_test), len(y_test), replace=True)
        X_boot = X_test[boot_idx][:, feats]
        y_boot = y_test[boot_idx]
        clf = create_svm()
        clf.fit(X_train[:, feats], y_train)
        return accuracy_score(y_boot, clf.predict(X_boot)) * 100.0

    seeds = [42 + k * 107 for k in range(K)]

    scores = {"TwGrey": [], "TwReliefF": [], "ReliefF": [], "No_Selection": []}
    for s in seeds:
        scores["TwGrey"].append(eval_on_test_bootstrap(feats_twgrey, s))
        scores["TwReliefF"].append(eval_on_test_bootstrap(feats_twrf, s))
        scores["ReliefF"].append(eval_on_test_bootstrap(feats_rf, s))
        scores["No_Selection"].append(eval_on_test_bootstrap(feats_nosel, s))

    twgrey_acc = np.array(scores["TwGrey"])
    baselines = ["TwReliefF", "ReliefF", "No_Selection"]

    raw_t_p, raw_w_p = {}, {}
    for b in baselines:
        base_acc = np.array(scores[b])
        diff = twgrey_acc - base_acc

        _, p_t = ttest_rel(twgrey_acc, base_acc)
        raw_t_p[b] = 1.0 if np.isnan(p_t) else p_t

        if np.allclose(diff, 0):
            raw_w_p[b] = 1.0
        else:
            _, p_w = wilcoxon(twgrey_acc, base_acc, alternative='two-sided')
            raw_w_p[b] = 1.0 if np.isnan(p_w) else p_w

    adj_t_p = adjust_p_values_holm(raw_t_p)
    adj_w_p = adjust_p_values_holm(raw_w_p)

    results = {}
    for b in baselines:
        results[b] = {"t_adj": adj_t_p[b], "w_adj": adj_w_p[b]}

    if verbose:
        print(f"    [特征数] TwGrey={len(feats_twgrey)}, TwReliefF={len(feats_twrf)}, "
              f"ReliefF={len(feats_rf)}, NoSel={len(feats_nosel)}")
        for name in ["TwGrey", "TwReliefF", "ReliefF", "No_Selection"]:
            arr = np.array(scores[name])
            print(f"      {name:14s}: mean={arr.mean():.2f}%, std={arr.std(ddof=1):.2f}")

    return results




# =========================================================================

# =========================================================================
def adjust_p_values_holm(p_dict):
    sorted_items = sorted(p_dict.items(), key=lambda x: x[1])
    m = len(sorted_items)
    adj_dict = {}
    running_max = 0.0
    for i, (key, p_val) in enumerate(sorted_items):
        adjusted = min(1.0, p_val * (m - i))
        adjusted = max(adjusted, running_max)
        running_max = adjusted
        adj_dict[key] = adjusted
    return adj_dict


# =========================================================================

# =========================================================================
if __name__ == "__main__":
    final_table = []
    for scale, cfg in dataset_configs.items():
        print(f"\n N = {scale} ...")
        res = run_significance_evaluation(cfg, K=10, verbose=True)

        fmt = lambda p: "<0.001" if p < 0.001 else f"{p:.3f}"
        final_table.append({
            "Sample Size": scale,
            "vs_TwReliefF_t": fmt(res["TwReliefF"]["t_adj"]),
            "vs_TwReliefF_w": fmt(res["TwReliefF"]["w_adj"]),
            "vs_ReliefF_t": fmt(res["ReliefF"]["t_adj"]),
            "vs_ReliefF_w": fmt(res["ReliefF"]["w_adj"]),
            "vs_NoSel_t": fmt(res["No_Selection"]["t_adj"]),
            "vs_NoSel_w": fmt(res["No_Selection"]["w_adj"]),
        })

    df_res = pd.DataFrame(final_table)
    print("\n" + "=" * 70)
    print("Table tab:significance_tests  (Holm-Bonferroni Adjusted):")
    print("=" * 70)
    print(df_res.to_string(index=False))