# -*- coding: utf-8 -*-


import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

import time
import gc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300


path_2800 = r"D:\e\NWPU\NWPU700\NWPU700.xlsx"
output_dir = r"D:\e\Feature\Feature (2)"
os.makedirs(output_dir, exist_ok=True)


N_BATCH_ROUNDS = 30   
INNER_LOOPS    = 20   
COOLING_TIME   = 1.5  


def compute_gra_weights(X_mat, y_vec, feature_names, rho):
    X_mat = np.asarray(X_mat, dtype=np.float64)
    y_vec = np.asarray(y_vec)
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min = differences.min()
    delta_max = differences.max()
    grey_relation_degrees = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        grey_relation_degrees[i] = np.mean(
            (delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max)
        )
    return grey_relation_degrees, dict(zip(feature_names, grey_relation_degrees))


def get_trimmed_stats(times_list, trim_ratio=0.1):
    
    arr = np.sort(times_list)
    n = len(arr)
    k = int(n * trim_ratio)
    valid_arr = arr[k:-k] if k > 0 else arr
    return float(np.mean(valid_arr)), float(np.std(valid_arr))


def run_clean_scalability():
    print("\n" + "=" * 90)
    print("🚀 Stage 1 GRA ")
    print(f"    {N_BATCH_ROUNDS} |  {COOLING_TIME}s")
    print("=" * 90)

    sample_sizes = [160, 400, 800, 2800]
    dimensions_test = [5, 10, 15, 20, 25]

    df = pd.read_excel(path_2800)
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values

    
    for _ in range(20):
        _ = compute_gra_weights(X[:400], y[:400], [f"f{i}" for i in range(X.shape[1])], rho=0.4)

    # ---------------------------------------------------------------------
    
    # ---------------------------------------------------------------------
    print("\n  [1/2] test (N) ...")
    time_vs_n, std_vs_n = [], []

    for n in sample_sizes:
        gc.collect()
        time.sleep(COOLING_TIME)  
        sub_X, sub_y = X[:n], y[:n]
        fnames = [f"f{i}" for i in range(sub_X.shape[1])]

        batch_times = []
        for _ in range(N_BATCH_ROUNDS):
            t0 = time.perf_counter()
            for _ in range(INNER_LOOPS):
                _ = compute_gra_weights(sub_X, sub_y, fnames, rho=0.4)
            t_batch = (time.perf_counter() - t0) / INNER_LOOPS
            batch_times.append(t_batch)

        mean_val, std_val = get_trimmed_stats(batch_times, trim_ratio=0.1)
        time_vs_n.append(mean_val)
        std_vs_n.append(std_val)
        print(f"       N = {n:<6} | {mean_val*1000:.3f} ms (±{std_val*1000:.3f})")

    # ---------------------------------------------------------------------
    
    # ---------------------------------------------------------------------
    print("\n  [2/2] test (D) ...")
    time_vs_d, std_vs_d = [], []
    sub_X_fixed, sub_y_fixed = X[:800], y[:800]

    for d in dimensions_test:
        gc.collect()
        time.sleep(COOLING_TIME)  
        sub_X = sub_X_fixed[:, :d]
        fnames = [f"f{i}" for i in range(d)]

        batch_times = []
        for _ in range(N_BATCH_ROUNDS):
            t0 = time.perf_counter()
            for _ in range(INNER_LOOPS):
                _ = compute_gra_weights(sub_X, sub_y_fixed, fnames, rho=0.4)
            t_batch = (time.perf_counter() - t0) / INNER_LOOPS
            batch_times.append(t_batch)

        mean_val, std_val = get_trimmed_stats(batch_times, trim_ratio=0.1)
        time_vs_d.append(mean_val)
        std_vs_d.append(std_val)
        print(f"       D = {d:<6} | {mean_val*1000:.3f} ms (±{std_val*1000:.3f})")

    # ---------------------------------------------------------------------
    
    # ---------------------------------------------------------------------
    time_vs_n_ms = [t * 1000 for t in time_vs_n]
    time_vs_d_ms = [t * 1000 for t in time_vs_d]
    std_vs_n_ms  = [s * 1000 for s in std_vs_n]
    std_vs_d_ms  = [s * 1000 for s in std_vs_d]

    z1 = np.polyfit(sample_sizes, time_vs_n_ms, 1)
    p1 = np.poly1d(z1)
    r2_n = r2_score(time_vs_n_ms, p1(sample_sizes))

    z2 = np.polyfit(dimensions_test, time_vs_d_ms, 1)
    p2 = np.poly1d(z2)
    r2_d = r2_score(time_vs_d_ms, p2(dimensions_test))

    print("\n" + "=" * 90)
    print("📈 []")
    print(f"  ▶ N-fit (): k = {z1[0]:.5f} ms/sample | R² = {r2_n:.4f}")
    print(f"  ▶ D-fit (): k = {z2[0]:.5f} ms/feature | R² = {r2_d:.4f}")
    print("=" * 90)

    # ---------------------------------------------------------------------

    # ---------------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.5, 4.2))

    
    ax1.errorbar(sample_sizes, time_vs_n_ms, yerr=std_vs_n_ms, marker='o',
                 color='#1f77b4', linewidth=2.0, markersize=7, capsize=4,
                 label='TwGrey stage 1 runtime')
    ax1.plot(sample_sizes, p1(sample_sizes), linestyle='--', color='#d62728',
             alpha=0.8, label=fr'Linear fit: $\mathcal{{O}}(N)$, $R^2$={r2_n:.3f}')
    ax1.set_xlabel('Sample size ($N$)', fontsize=11, fontweight='bold')
    ax1.set_ylabel('Execution time (ms)', fontsize=11, fontweight='bold')
    ax1.grid(True, linestyle='--', alpha=0.4)
    ax1.set_ylim(bottom=0)
    ax1.legend(loc='upper left', frameon=True)

    
    ax2.errorbar(dimensions_test, time_vs_d_ms, yerr=std_vs_d_ms, marker='s',
                 color='#2ca02c', linewidth=2.0, markersize=7, capsize=4,
                 label='TwGrey stage 1 runtime')
    ax2.plot(dimensions_test, p2(dimensions_test), linestyle='--', color='#d62728',
             alpha=0.8, label=fr'Linear fit: $\mathcal{{O}}(D)$, $R^2$={r2_d:.3f}')
    ax2.set_xlabel('Feature dimensionality ($D$)', fontsize=11, fontweight='bold')
    ax2.set_ylabel('Execution time (ms)', fontsize=11, fontweight='bold')
    ax2.grid(True, linestyle='--', alpha=0.4)
    ax2.set_ylim(bottom=0)
    ax2.legend(loc='upper left', frameon=True)

    plt.tight_layout()
    fig_pdf = os.path.join(output_dir, "fig_scalability7.pdf")
    fig_png = os.path.join(output_dir, "fig_scalability7.png")
    plt.savefig(fig_png, dpi=FIG_DPI, bbox_inches='tight')
    plt.savefig(fig_pdf, format='pdf', bbox_inches='tight')
    plt.close()

    print(f"\n📊 out: {fig_pdf} 与 {fig_png}")
    if r2_n >= 0.99 and r2_d >= 0.98:
        print("★ good")
    elif r2_n >= 0.98 and r2_d >= 0.95:
        print("★ ok")
    else:
        print("★ bad")

if __name__ == "__main__":
    run_clean_scalability()