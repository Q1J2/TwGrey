import os
import warnings
from itertools import combinations
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.utils import resample

warnings.filterwarnings("ignore")

# =========================================================================

# =========================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.size'] = 11
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
FIG_DPI = 300

# =========================================================================

# =========================================================================
data_paths = {
    160:  r"D:\e\NWPU\NWPU40\TotalFG.xlsx",
    400:  r"D:\e\NWPU\NWPU100\NWPU100.xlsx",
    800:  r"D:\e\NWPU\NWPU200\NWPU200.xlsx",
    2800: r"D:\e\NWPU\NWPU700\NWPU700.xlsx",
}


RHO_PER_SCALE = {
    160: 0.4,
    400: 0.8,
    800: 0.4,
    2800: 0.4,
}

output_dir = r"D:\e\Feature\Feature (2)"
os.makedirs(output_dir, exist_ok=True)


# =========================================================================

# =========================================================================
def compute_pairwise_jaccard(subsets):
    b = len(subsets)
    if b < 2:
        return 1.0, 0.0
    pairs = list(combinations(range(b), 2))
    jaccards = []
    for i, j in pairs:
        s_i = set(subsets[i])
        s_j = set(subsets[j])
        union_len = len(s_i.union(s_j))
        jaccards.append(len(s_i.intersection(s_j)) / union_len if union_len > 0 else 1.0)
    return np.mean(jaccards), np.std(jaccards) / np.sqrt(len(jaccards))


def compute_pairwise_kuncheva(subsets, total_d):
    b = len(subsets)
    if b < 2:
        return 1.0, 0.0
    pairs = list(combinations(range(b), 2))
    kunchevas = []
    for i, j in pairs:
        s_i = set(subsets[i])
        s_j = set(subsets[j])
        r = len(s_i.intersection(s_j))
        k_i, k_j = len(s_i), len(s_j)
        num = r * total_d - k_i * k_j
        den = total_d * min(k_i, k_j) - k_i * k_j
        kunchevas.append(num / den if den != 0 else (1.0 if num == 0 else 0.0))
    return np.mean(kunchevas), np.std(kunchevas) / np.sqrt(len(kunchevas))


# =========================================================================

# =========================================================================
def create_svm():
    return SVC(
        C=1.0,
        kernel='rbf',
        gamma='scale',
        decision_function_shape='ovr',
        probability=True,
        random_state=42,
    )


def evaluate_model(model, x_curr, y_true):
    y_pred = model.predict(x_curr)
    acc = accuracy_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred, average="macro", zero_division=0)
    precision = precision_score(y_true, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    return acc, precision, recall, f1


# =========================================================================

# =========================================================================
def selector_variance_threshold(X, y, top_ratio=0.4):
    variances = np.var(X, axis=0)
    top_k = max(2, int(len(variances) * top_ratio))
    return np.argsort(variances)[::-1][:top_k].tolist()


def compute_relieff_weights(X_mat, y_vec, feature_names=None, r=100, k=5):
    
    m, n = X_mat.shape
    classes, class_counts = np.unique(y_vec, return_counts=True)
    p_c = {c: count / m for c, count in zip(classes, class_counts)}

    feat_min = np.min(X_mat, axis=0)
    feat_max = np.max(X_mat, axis=0)
    feat_span = feat_max - feat_min
    feat_span[feat_span == 0] = 1e-8

    W = np.zeros(n)
    np.random.seed(42)

    actual_r = min(r, m)

    for _ in range(actual_r):
        idx_s = np.random.randint(0, m)
        s = X_mat[idx_s]
        cls_s = y_vec[idx_s]

        norm_diff = np.abs(X_mat - s) / feat_span
        dist_all = np.sum(norm_diff, axis=1)

        # 1. k-Near Hits
        same_class_mask = (y_vec == cls_s)
        same_class_indices = np.where(same_class_mask)[0]
        same_class_indices = same_class_indices[same_class_indices != idx_s]
        k_hit = min(k, len(same_class_indices))
        if k_hit == 0:
            continue
        hit_k_indices = same_class_indices[np.argsort(dist_all[same_class_indices])[:k_hit]]
        diff_hits = np.sum(np.abs(X_mat[hit_k_indices] - s) / feat_span, axis=0)

        # 2. k-Near Misses
        diff_misses_weighted = np.zeros(n)
        for c in classes:
            if c == cls_s:
                continue
            diff_class_indices = np.where(y_vec == c)[0]
            k_miss = min(k, len(diff_class_indices))
            if k_miss == 0:
                continue
            miss_k_indices = diff_class_indices[np.argsort(dist_all[diff_class_indices])[:k_miss]]
            diff_m_c = np.sum(np.abs(X_mat[miss_k_indices] - s) / feat_span, axis=0)
            diff_misses_weighted += (p_c[c] / (1.0 - p_c[cls_s])) * (diff_m_c / k_miss)

        W = W - (diff_hits / (actual_r * k_hit)) + (diff_misses_weighted / actual_r)

    if feature_names is not None:
        return dict(zip(feature_names, W))
    return W


def selector_relieff(X, y, tau_relief=0.06):
    
    w = compute_relieff_weights(X, y, r=100, k=5)
    feats = [i for i, wi in enumerate(w) if wi >= tau_relief]
    if not feats:
        feats = [int(np.argmax(w))]
    return feats



TWRELIEF_FIXED_ALPHA = 0.0900
TWRELIEF_FIXED_BETA = 0.0300


def selector_twrelieff(X, y):
    
    w = compute_relieff_weights(X, y, r=100, k=5)
    f_dict = {i: w[i] for i in range(len(w))}

    alpha = TWRELIEF_FIXED_ALPHA
    beta = TWRELIEF_FIXED_BETA

    pos = [f for f, s in f_dict.items() if s >= alpha]
    bnd = [f for f, s in f_dict.items() if beta < s < alpha]

    if len(pos) == 0:
        top_f = max(f_dict, key=f_dict.get)
        pos = [top_f]
        if top_f in bnd:
            bnd.remove(top_f)

    
    x_curr = X[:, pos].copy()
    svm = create_svm()
    svm.fit(x_curr, y)
    best_acc, _, _, _ = evaluate_model(svm, x_curr, y)

    for feature in sorted(bnd, key=lambda f: f_dict[f], reverse=True):
        cand_x = np.column_stack([x_curr, X[:, feature]])
        temp_svm = create_svm()
        temp_svm.fit(cand_x, y)
        acc_cand, _, _, _ = evaluate_model(temp_svm, cand_x, y)

        if acc_cand > best_acc:
            best_acc = acc_cand
            pos.append(feature)
            x_curr = cand_x

    return pos



def compute_gra_importance(X_mat, y_vec, rho):
    
    differences = np.abs(X_mat - y_vec.reshape(-1, 1))
    delta_min, delta_max = differences.min(), differences.max()
    gamma = np.zeros(X_mat.shape[1])
    for i in range(X_mat.shape[1]):
        gamma[i] = np.mean((delta_min + rho * delta_max) / (differences[:, i] + rho * delta_max))
    return gamma


def optimize_thresholds_shadow_gra(gamma_vals, step=0.005):
    
    min_objective = float('inf')
    best_alpha, best_beta = 0.0, 0.0
    gamma_min, gamma_max = np.min(gamma_vals), np.max(gamma_vals)
    thresholds = np.arange(gamma_min + step, gamma_max, step)

    if len(thresholds) < 2:
        return (gamma_min + 0.67 * (gamma_max - gamma_min),
                gamma_min + 0.33 * (gamma_max - gamma_min))

    for i, beta_cand in enumerate(thresholds):
        for alpha_cand in thresholds[i + 1:]:
            significant = gamma_vals[gamma_vals >= alpha_cand]
            insignificant = gamma_vals[gamma_vals <= beta_cand]
            shadow = gamma_vals[(gamma_vals > beta_cand) & (gamma_vals < alpha_cand)]
            obj = abs(np.sum(1 - significant) + np.sum(insignificant) - len(shadow))
            if obj < min_objective:
                min_objective = obj
                best_alpha, best_beta = alpha_cand, beta_cand
    return best_alpha, best_beta


def selector_twgrey(X, y, rho):
    
    feature_importances = compute_gra_importance(X, y, rho=rho)
    alpha, beta = optimize_thresholds_shadow_gra(feature_importances, step=0.005)

    positive_region = [f for f, s in enumerate(feature_importances) if s >= alpha]
    border_region = [f for f, s in enumerate(feature_importances) if beta < s < alpha]

    if len(positive_region) == 0:
        top_f = int(np.argmax(feature_importances))
        positive_region.append(top_f)
        if top_f in border_region:
            border_region.remove(top_f)

    
    x_curr = X[:, positive_region].copy()
    svm = create_svm()
    svm.fit(x_curr, y)
    best_acc, _, _, _ = evaluate_model(svm, x_curr, y)

    for feature in sorted(border_region, key=lambda f: feature_importances[f], reverse=True):
        cand_x = np.column_stack([x_curr, X[:, feature]])
        temp_svm = create_svm()
        temp_svm.fit(cand_x, y)
        acc_cand, _, _, _ = evaluate_model(temp_svm, cand_x, y)

        if acc_cand > best_acc:
            best_acc = acc_cand
            positive_region.append(feature)
            x_curr = cand_x

    return positive_region


# =========================================================================
# =========================================================================
def evaluate_stability_on_scale(scale=2800, B=50):
    file_path = data_paths[scale]
    print(f"\n📂  n = {scale} -> : {file_path}")
    df = pd.read_excel(file_path)
    X_full = df.iloc[:, :-1].values
    y_full = df.iloc[:, -1].values
    n_features_d = X_full.shape[1]

    
    rho_scale = RHO_PER_SCALE[scale]
    print(f"🎯  rho = {rho_scale}")

    
    X_train_pool, X_test, y_train_pool, y_test = train_test_split(
        X_full, y_full, test_size=0.30, stratify=y_full, random_state=42
    )
    print(f"📊  = {len(y_train_pool)},  = {len(y_test)}")

    methods = ["Variance Threshold", "ReliefF", "TwReliefF", "TwGrey"]
    subsets_hist = {m: [] for m in methods}
    acc_hist = {m: [] for m in methods}

    
    for b in range(B):
        X_boot, y_boot = resample(
            X_train_pool, y_train_pool, replace=True, random_state=1000 + b * 17
        )

        for m in methods:
            if m == "Variance Threshold":
                feats = selector_variance_threshold(X_boot, y_boot)
            elif m == "ReliefF":
                feats = selector_relieff(X_boot, y_boot, tau_relief=0.06)
            elif m == "TwReliefF":
                feats = selector_twrelieff(X_boot, y_boot)
            elif m == "TwGrey":
                feats = selector_twgrey(X_boot, y_boot, rho=rho_scale)

            subsets_hist[m].append(feats)

            
            clf = create_svm()
            clf.fit(X_boot[:, feats], y_boot)
            acc_hist[m].append(
                accuracy_score(y_test, clf.predict(X_test[:, feats])) * 100.0
            )

    
    summary_rows = []
    for m in methods:
        j_mean, j_err = compute_pairwise_jaccard(subsets_hist[m])
        k_mean, k_err = compute_pairwise_kuncheva(subsets_hist[m], n_features_d)
        sizes = [len(s) for s in subsets_hist[m]]
        summary_rows.append({
            "Method": m,
            "Jaccard": f"${j_mean:.3f} \\pm {j_err:.3f}$",
            "Kuncheva": f"${k_mean:.3f} \\pm {k_err:.3f}$",
            "Subset_Size": f"${np.mean(sizes):.1f} \\pm {np.std(sizes):.1f}$",
            "Accuracy": f"{np.mean(acc_hist[m]):.2f}",
            "Accuracy_Std": f"{np.std(acc_hist[m]):.2f}"
        })

    print("\n" + "=" * 80)
    print(pd.DataFrame(summary_rows).to_string(index=False))
    print("=" * 80)

    
    freq_matrix = []
    for m in methods:
        counts = np.zeros(n_features_d)
        for s in subsets_hist[m]:
            counts[s] += 1
        freq_matrix.append(counts / B)
    freq_matrix = np.array(freq_matrix)

    twgrey_order = np.argsort(freq_matrix[3])[::-1]
    plot_data = freq_matrix[:, twgrey_order]

    fig, ax = plt.subplots(figsize=(9, 4.2))
    cax = ax.imshow(
        plot_data, aspect='auto', cmap='YlGnBu',
        interpolation='nearest', vmin=0.0, vmax=1.0
    )
    ax.set_yticks(range(len(methods)))
    ax.set_yticklabels(
        ["Variance Thresh.", "ReliefF", "TwReliefF", "TwGrey"], fontsize=11
    )
    ax.set_xlabel(
        f'Feature indices (Ranked by TwGrey, Total $D={n_features_d}$)',
        fontsize=11, fontweight='bold'
    )

    cbar = fig.colorbar(cax, ax=ax, orientation='horizontal', pad=0.25, shrink=0.6)
    cbar.set_label('Selection retention frequency', fontsize=10.5)
    plt.tight_layout()

    fig_png = os.path.join(output_dir, f"image_stability_heatmap_n{scale}_you1.png")
    fig_pdf = os.path.join(output_dir, f"image_stability_heatmap_n{scale}_you1.pdf")
    plt.savefig(fig_png, dpi=FIG_DPI, bbox_inches='tight')
    plt.savefig(fig_pdf, format='pdf', bbox_inches='tight')
    print(f"✅ : {fig_png}")
    plt.show()


if __name__ == "__main__":
    for s in [160, 400, 800, 2800]:
        print(f"\n==================== Scale: n = {s} ====================")
        evaluate_stability_on_scale(scale=s, B=50)